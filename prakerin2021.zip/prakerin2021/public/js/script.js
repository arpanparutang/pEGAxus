//const mulai1 = document.getElementById("tombolmulai");
//mulai1.addEventListener("click", function (ulang) {
window.addEventListener('load', function () {
	document.getElementById('pg').style.display = 'none';
	document.getElementById('soalmenjodohkan').style.display = 'none';
	document.getElementById('benarsalah').style.display = 'none';
	var waktu = document.getElementById('waktu').value;


});
var waktu = document.getElementById('waktu').value;
function waktuujian() {
	let detik = waktu;
	document.getElementById('tampilwaktu').innerHTML = detik + ' MENIT ';
	const hitung = setInterval(() => {
		detik--;
		document.getElementById('tampilwaktu').innerHTML = detik + ' MENIT ';
		if (detik < 0) {
			document.getElementById('tampilwaktu').innerHTML = 'waktu Habis';
			window.location.replace('/ujian/public/utama/keluar');
		}
	}, 60000);



}

var datasoal2 = [];
var datasoal3 = [];
var datasoalbs = [];
function mulai() {
	document.getElementById('pembukapg').style.display = 'none';
	document.getElementById('soalmenjodohkan').style.display = 'none';
	waktuujian();
	//ambil soal PG//
	$.ajax({
		url: "/ujian/public / utama / ambilsoalutama",
		dataType: "json",
		success: function (data) {
			const a = data.length;
			document.getElementById('namates').innerHTML = data[0].namaujian;
			document.getElementById('namapeserta').innerHTML = data[0].nama + ' , Kelas ' + data[0].kelas;
			for (b = 1; b <= a; b++) {
				const menu = document.querySelector(".menusoal1");
				const menu1 = document.createElement('button');
				menu1.className = 'item1';
				menu1.setAttribute("id", "item" + b);
				menu1.setAttribute("onClick", "ambilsoal(this.id)");
				menu1.setAttribute("value", data[b - 1].no);
				menu1.textContent = b;
				if (data[b - 1].jawaban != "") {
					menu1.style.backgroundColor = "blue";

				}
				menu.appendChild(menu1);
			}
		}
	});
	//ambil soal menjodohkan//
	$.ajax({
		url: "/ujian/public / utama / ambilsoalmenjodohkan",
		dataType: "json",
		success: function (data) {
			const ljodoh = data.length;
			datasoal2 = data;
			datasoal3 = data.slice();
			for (bjodoh = 1; bjodoh <= ljodoh; bjodoh++) {
				const menu = document.querySelector(".menusoal2");
				const menu2 = document.createElement('button');
				menu2.className = 'item1';
				menu2.setAttribute("id", "itemjodoh" + bjodoh);
				menu2.setAttribute("onClick", "ambilsoal2(this.id)");
				menu2.setAttribute("value", data[bjodoh - 1].no);
				menu2.textContent = bjodoh;
				if (data[bjodoh - 1].jawaban != "") {
					menu2.style.backgroundColor = "blue";

				}
				menu.appendChild(menu2);
			}
		}
	});
	//ammbil soal benar salah
	$.ajax({
		url: "/ujian/public / utama / ambilsoalbs",
		dataType: "json",
		success: function (data) {
			datasoalbs = data;

			let a = data.length;
			for (let b = 1; b <= a; b++) {
				const menubs = document.querySelector(".menusoal3");
				const menu1bs = document.createElement('button');
				menu1bs.className = 'item1';
				menu1bs.setAttribute("id", "itembs" + b);
				menu1bs.setAttribute("onClick", "ambilsoal3(this.id)");
				menu1bs.setAttribute("value", data[b - 1].no);
				menu1bs.textContent = b;
				if (data[b - 1].jawab != "") {
					menu1bs.style.backgroundColor = "blue";
				}
				menubs.appendChild(menu1bs);
			}
		}
	});
};

//soal pilihan ganda
var kunci = "";
var menuitem = "";
function ambilsoal(b) {
	document.getElementById('pg').style.display = 'unset';
	document.getElementById('soalmenjodohkan').style.display = 'none';
	document.getElementById('benarsalah').style.display = 'none';
	const nomor = document.getElementById(b).value;
	const idtes = parseInt(nomor);
	menuitem = b;
	document.getElementById('pilihan').value = idtes;
	const label1 = document.getElementById(b).innerHTML;
	document.getElementById('nomorsoal').innerHTML = label1 + '.';
	$.ajax({
		url: "/ujian/public/utama/ambilsoal",
		method: 'POST',
		data: { idtes: idtes },
		dataType: 'json',
		success: function (data) {
			if (data[0].img_soal == "") {
				const gambar = document.querySelector('.gambarsoal');
				gambar.style.display = 'none';
			} else {
				const hapusimg = document.getElementById('gambarsoal');
				const hapusimg1 = hapusimg.getElementsByTagName('img')[0];
				hapusimg1.remove();
				const gambar = document.querySelector('.gambarsoal');
				gambar.style.display = 'block';
				const img1 = document.createElement('img');
				img1.setAttribute("src", "../img/soal/" + data[0].img_soal);
				gambar.appendChild(img1);
			}
			document.getElementById('butirsoal').innerHTML = data[0].soal;
			document.getElementById('tombolradio1').innerHTML = 'A. ' + data[0].pila;
			document.getElementById('radio_1').value = data[0].pila;
			document.getElementById('tombolradio2').innerHTML = 'B. ' + data[0].pilb;
			document.getElementById('radio_2').value = data[0].pilb;
			document.getElementById('tombolradio3').innerHTML = 'C. ' + data[0].pilc;
			document.getElementById('radio_3').value = data[0].pilc;
			document.getElementById('tombolradio4').innerHTML = 'D. ' + data[0].pild;
			document.getElementById('radio_4').value = data[0].pild;
			document.getElementById('tombolradio5').innerHTML = 'E. ' + data[0].pile;
			document.getElementById('radio_5').value = data[0].pile;
			kunci = data[0].kunci;
			var jawaban = data[0].jawaban;
			var radios = document.getElementsByName('radio');
			if (jawaban == "") {
				for (var i = 0; i < radios.length; i++) {
					radios[i].checked = false;
				}
			} else {
				for (var i = 0; i < radios.length; i++) {
					if (radios[i].value == jawaban)
						radios[i].checked = true;
				}
			}
		}

	});

}

function pilihjawaban() {
	const radios = document.getElementsByName('radio');
	for (var i = 0; i < radios.length; i++) {
		if (radios[i].checked) {

			var pilihan = radios[i].value;
			var idtes = document.getElementById('pilihan').value;
			var benar = kunci;
			$.ajax({
				url: "/ujian/public/utama/updatejawaban",
				method: "POST",
				data: { idtes: idtes, pilihan: pilihan, benar: benar },
				success: function () {
					document.getElementById(menuitem).style.backgroundColor = 'blue';
				}

			});
		}
	}

}


//soal menjodohkan
var menuitemjodoh = ""
function ambilsoal2(itemjodoh) {
	document.getElementById('pg').style.display = 'none';
	document.getElementById('benarsalah').style.display = 'none';
	document.getElementById('soalmenjodohkan').style.display = 'unset';
	const tempatsoal = document.querySelector('.isipilihan');
	const templatesoal = document.querySelectorAll('.itempilihan');
	menuitemjodoh = itemjodoh;
	if (templatesoal.length) {
		templatesoal.forEach(el => el.remove());
	}

	var sapi = datasoal2.sort((a, b) => 0.5 - Math.random());

	sapi.forEach((itemsoal) => {
		const menupilihan = document.createElement('div');
		menupilihan.className = 'itempilihan';
		menupilihan.setAttribute('draggable', 'true');
		menupilihan.setAttribute('id', 'pilihanKe-' + itemsoal.no);
		menupilihan.setAttribute('ondragstart', 'dragStart(event)');
		menupilihan.innerHTML = itemsoal.kunci;
		tempatsoal.appendChild(menupilihan);
	});

	const tempatsoal2 = document.querySelector('.isipernyataan');
	tempatsoal2.innerHTML = "";
	var isitext = "";
	const abjodoh = document.getElementById(itemjodoh).value;
	$.ajax({
		url: "/ujian/public / utama / ambilsoalmenjodohkan2",
		dataType: "json",
		method: "POST",
		data: { abjodoh: abjodoh },
		success: function (data) {
			if (data[0].gambarsoal) {
				isitext = data[0].soal + ' <br> ' + '<img class="gambarsoal" src="../img/soal/' + data[0].gambarsoal + '" width="100%" height="150">' + "<BR>" + " <div class='kotakisian' id='" + data[0].no + "' ondragover='dragOver(event)' ondrop='drop(event)' ></div> ";
				tempatsoal2.innerHTML = isitext;
			} else {
				isitext = data[0].soal + ' <br>' + " <div class='kotakisian' id='" + data[0].no + "' ondragover='dragOver(event)' ondrop='drop(event)' ></div> ";
				tempatsoal2.innerHTML = isitext;
			}
			if (data[0].jawaban) {
				document.getElementById(data[0].no).innerHTML = data[0].jawaban
				document.getElementById(itemjodoh).style.backgroundColor = "blue";
			} else {
				document.getElementById(data[0].no).innerHTML = ""
			}
			jawabenarjodoh = data[0].kunci;
			nosoaljodoh = data[0].no;

		}
	});

	//tempatsoal2.innerHTML = isitext;

}

function dragStart(event) {
	event.dataTransfer.setData("text", event.target.innerHTML);
}

function dragOver(event) {
	event.preventDefault();
}

function drop(event) {
	event.preventDefault();
	var sapi3 = event.dataTransfer.getData("text");
	event.target.innerHTML = sapi3;

	const nomorsoal1 = document.getElementById(nosoaljodoh);
	const nosoal = nosoaljodoh;
	const pilihjawab = nomorsoal1.innerHTML;
	const jodohbenar = jawabenarjodoh;
	$.ajax({
		url: '/ujian/public/utama/hasilsoalmenjodohkan',
		method: 'POST',
		data: {
			id: nosoal,
			jawab: pilihjawab,
			benar: jodohbenar,
		},
		success: function (data) {
			document.getElementById(menuitemjodoh).style.backgroundColor = "blue";
		}
	});
}



function ambilsoal3(bs) {
	document.getElementById('pg').style.display = 'none';
	document.getElementById('soalmenjodohkan').style.display = 'none';
	document.getElementById('benarsalah').style.display = 'block';
	menuitembs = bs;
	const idtesbs = parseInt(document.getElementById(bs).value);
	$.ajax({
		url: '/ujian/public/utama/ambilbutirsoalbs',
		dataType: 'json',
		method: 'POST',
		data: { idtesbs: idtesbs },
		success: function (data) {
			if (data[0].gambarsoal == "") {
				const gambarbsa = document.querySelector('.gambarsoalbs');
				gambarbsa.style.display = 'none';
			} else {
				const hapusimgbs = document.getElementById('gambarsoalbs');
				const hapusimgbs1 = hapusimgbs.getElementsByTagName('img')[0];
				hapusimgbs1.remove();
				const gambarbs = document.querySelector('.gambarsoalbs');
				gambarbs.style.display = 'block';
				const img1 = document.createElement('img');
				img1.setAttribute("src", "../img/soal/" + data[0].gambarsoal);
				img1.setAttribute('width', '100%');
				img1.setAttribute('height', '100%');
				img1.className = 'tampilgambarbs';
				gambarbs.appendChild(img1);
			}
			document.getElementById('butirsoalbs').innerHTML = data[0].soal;
			document.getElementById('tombolradio1bs').innerHTML = 'BENAR'
			document.getElementById('tombolradio2bs').innerHTML = 'SALAH'
			kuncibs = data[0].kunci;
			document.getElementById('nomorbs').value = data[0].no;
			var radiobs = document.getElementsByName('radiobs');
			var jawabanbs1 = data[0].jawab;
			if (jawabanbs1 == "") {
				radiobs[0].checked = false;
				radiobs[1].checked = false;
			} else if (jawabanbs1 == 0) {
				radiobs[1].checked = true;
			} else {
				radiobs[0].checked = true;
			}
		}

	})
}

function pilihjawabanbs(id) {
	const jawabanbs = document.querySelector('input[name="radiobs"]:checked').value;
	const idsoal = document.getElementById('nomorbs').value;
	if (jawabanbs == kuncibs) {
		var nilaibs = 1;
	} else {
		var nilaibs = 0;
	}
	$.ajax({
		url: '/ujian/public/utama/updatejawabanbs',
		data: { jawabanbs: jawabanbs, idsoal: idsoal, nilaibs: nilaibs },
		method: 'POST',
		success: function () {
			document.getElementById(menuitembs).style.backgroundColor = 'blue';
		}
	})

}

