<?php
//url utama
define('BASEURL', 'http://localhost/prakerin2021/public');
//db
define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_NAME', 'dbprakerin');
define('owner', 'pEGAxus LMS v.1.0 <br> dibuat oleh : Sir Arpan');
