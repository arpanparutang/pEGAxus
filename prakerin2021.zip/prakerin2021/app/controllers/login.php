<?php
class login extends Controller
{
    public function index()
    {
        $this->view('login/index');
    }
    public function ceklogin()
    {
        header('Content-Type: application/json');
        $kuda = json_decode($_POST['sapi'], false);
        $nis = $kuda->nis;
        $nis1 = preg_replace('/[=\@\" "\.\;\<\>]+/', "", $nis);
        $pass = $kuda->pass;
        $pass1 = preg_replace('/[=\@\" "\.\;\<\>]+/', "", $pass);
        echo json_encode($this->model('model_admin')->ceklogin($nis1, $pass1));
    }

    public function validasilogin()
    {
        $nis1 = preg_replace('/[=\@\" "\.\;\<\>\"\']+/', "", $_POST['nis']);
        $pass1 = preg_replace('/[=\@\" "\.\;\<\>\"\']+/', "", $_POST['pass']);
        $cek['userdata'] = $this->model('model_admin')->ceklogin($nis1, $pass1);
        $countlenght = count($cek['userdata']);
        if ($countlenght > 0) {
            foreach ($cek['userdata'] as $user) {
                $nama1 = $user['namauser'];
            }
            session_start();
            $_SESSION['namauser'] = $nama1;
            $_SESSION['validasi'] = 1;
            header("Location:" . BASEURL . "/admin/haladmin");
        }
    }
}
