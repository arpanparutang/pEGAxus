<?php

class admin extends Controller
{
    public function __construct()
    {
        session_start();
        if ((isset($_SESSION['namauser'])) && ($_SESSION['validasi'] == 1)) {
            $_SESSION['ok'] = "JADI";
        } else {
            header("Location:" . BASEURL . "/login");
        }
    }
    public function index()
    {
        $this->view('admin/kepalaadmin');
        $this->view('admin/haladmin');
        $this->view('admin/kakiadmin');
    }

    public function haladmin()
    {
        $this->view('admin/kepalaadmin');
        $this->view('admin/haladmin');
        $this->view('admin/kakiadmin');
    }

    public function inputdudika()
    {
        $data['kompetensi'] = $this->model('model_admin')->ambildatajurusan();
        $this->view('admin/kepalaadmin');
        $this->view('admin/inputdudika', $data);
        $this->view('admin/kakiadmin');
    }

    public function inputdatadudika()
    {
        $this->model('model_admin')->inputdatadudika($_POST);
        header('location:inputdudika');
    }
    public function editdatadudika()
    {
        $data['dudika'] = $this->model('model_admin')->ambilsemuadudika();
        $this->view('admin/kepalaadmin');
        $this->view('admin/editdatadudika', $data);
        $this->view('admin/kakiadmin');
    }
    public function ambildatadudika()
    {

        header('Content-Type: application/json');
        $nama = json_decode($_POST['sapi'], false);
        $nama1 = $nama->nama;
        echo json_encode($this->model('model_admin')->ambildatadudika($nama1));
    }
    public function ambilnomordudika()
    {

        // header('Content-Type: application/json');
        // $no = json_decode($_POST['sapi'], false);
        // $no = $_POST['sapi'];
        $jsondata = file_get_contents('php://input');
        $no = json_decode($jsondata, true);
        // if (!empty($no)) {
        //     echo json_encode($no);
        // } else {
        //     echo json_encode(["sapi", "kuda"]);
        // }
        $nodudika = $no['sapi'];
        // $nodudika = $no->nodudika;
        echo json_encode($this->model('model_admin')->ambilnomordudik($nodudika));
    }

    public function proseseditdatadudika()
    {
        $this->model('model_admin')->proseseditdatadudika($_POST);
        header('location:editdatadudika');
    }
    public function pendaftaran()
    {
        $data['kompetensi'] = $this->model('model_admin')->ambildatajurusan();
        $this->view('admin/kepalaadmin');
        $this->view('admin/pendaftaran', $data);
        $this->view('admin/kakiadmin');
    }

    public function ambildatakuota()
    {
        header('Content-Type: application/json');
        $jurusan = json_decode($_POST['sapi'], false);
        $jurusan1 = $jurusan->jurusan;
        echo json_encode($this->model('model_admin')->ambildatakuota($jurusan1));
    }

    public function ambilsisakuota()
    {
        header('Content-Type: application/json');
        $jurusan = json_decode($_POST['sapi'], false);
        $jurusan1 = $jurusan->jurusan;
        $dudika = $jurusan->dudika;
        echo json_encode($this->model('model_admin')->ambilsisakuota($jurusan1, $dudika));
    }

    public function pembimbing()
    {
        $data['pembimbing'] = $this->model('model_admin')->ambildatapembimbing();
        $data['kompetensi'] = $this->model('model_admin')->ambildatajurusan();
        $this->view('admin/kepalaadmin');
        $this->view('admin/pembimbing', $data);
        $this->view('admin/kakiadmin');
    }

    public function ambilnamapembimbing()
    {
        header('Content-Type: application/json');
        $jurusan = json_decode($_POST['sapi2'], false);
        $jurusan1 = $jurusan->jurusan;
        echo json_encode($this->model('model_admin')->ambilnamapembimbing($jurusan1));
    }

    public function tambahpembimbing()
    {
        header('Content-Type: application/json');
        $data1 = json_decode($_POST['sapi'], false);
        $nama = htmlspecialchars($data1->nama);
        $jur = htmlspecialchars($data1->jurusan);
        $this->model('model_admin')->tambahpembimbing($nama, $jur);
        echo "DATA BERHASIL MASUK";
    }
    public function ambilkuotajurusan()
    {
        header('Content-Type: application/json');
        $id = json_decode($_POST['sapi'], false);
        $idjur = $id->id;
        echo json_encode($this->model('model_admin')->ambilkuotajurusan($idjur));
    }

    public function hapuspembimbing()
    {
        header('Content-Type: application/json');
        $id = json_decode($_POST['sapi'], false);
        $idjur = $id->id;
        $this->model('model_admin')->hapuspembimbing($idjur);
        echo "DATA BERHASIL DIHAPUS";
    }

    public function ambildatasiswa()
    {
        header('Content-Type: application/json');
        $id = json_decode($_POST['sapi'], false);
        $nis = $id->nis;
        echo json_encode($this->model('model_admin')->ambildatasiswa($nis));
    }

    public function validasidatasiswa()
    {
        header('Content-Type: application/json');
        $nosiswa = json_decode($_POST['sapi'], false);
        $idsiswa = $nosiswa->nosiswa;
        echo json_encode($this->model('model_admin')->validasidatasiswa($idsiswa));
    }

    public function inputpenempatan()
    {
        header('Content-Type: application/json');
        $data = json_decode($_POST['sapi'], false);
        $nosiswa = $data->nosiswa;
        $idjur = $data->idjur;
        $iddudika = $data->iddudika;
        $idpembimbing = $data->idpembimbing;
        $this->model('model_admin')->inputpenempatan($idjur, $nosiswa, $iddudika, $idpembimbing);
        echo "DATA BERHASIL DIINPUT";
    }

    public function rekappenempatan()
    {
        $data['kompetensi'] = $this->model('model_admin')->ambildatajurusan();
        $this->view('admin/kepalaadmin');
        $this->view('admin/rekappenempatan', $data);
        $this->view('admin/kakiadmin');
    }

    public function ambilrekappenempatan()
    {
        header('Content-Type: application/json');
        $idjur = json_decode($_POST['sapi'], false);
        $idjur = $idjur->jur;
        echo json_encode($this->model('model_admin')->ambilrekappenempatan($idjur));
    }
    public function hapuspenempatan()
    {
        header('Content-Type: application/json');
        $noid = json_decode($_POST['sapi'], false);
        $id = $noid->noid;
        $this->model('model_admin')->hapuspenempatan($id);
        echo "DATA PENEMPATAN SUDAH DIHAPUS";
    }
    public function downloaddatapenempatan()
    {
        $file_name = "datapenempatan.xls";
        header("Content-type: application/vnd.ms-excel");
        header("Content-Disposition: attachment; filename=$file_name");
        $data['penempatan'] = $this->model('model_admin')->downloadpenempatan();
        $this->view('admin/downloaddatapenempatan', $data);
    }

    public function materiajar()
    {
        $data['mapel'] = $this->model('model_user')->mediapembelajaran();
        $this->view('admin/kepalaadmin');
        $this->view('admin/materiajar', $data);
        $this->view('admin/kakiadmin');
    }

    public function inputbahanajar()
    {
        /*  header('Content-Type: application/json');
        $data1 = json_decode($_POST['sapi'], false);
        $mapel1 = $data1->mapel;
        $kelas1 = $data1->kelas;
        $link1 = $data1->link2;
        $materike1 = $data1->materike;
        $tipe1 = $data1->tipe;*/

        $this->model('model_admin')->inputbahanajar($_POST);
        header("Location:" . BASEURL . "/admin/materiajar");
        //echo "DATA BAHAN AJAR BERHASIL DIINPUT";
    }

    public function rekapbahanajar()
    {
        $data['mapel'] = $this->model('model_user')->mediapembelajaran();
        $this->view('admin/kepalaadmin');
        $this->view('admin/rekapbahanajar', $data);
        $this->view('admin/kakiadmin');
    }

    public function ambilrekapbahanajar()
    {
        header('Content-Type: application/json');
        $data1 = json_decode($_POST['sapi'], false);
        $mapel = $data1->mapel;
        echo json_encode($this->model('model_admin')->ambilrekapbahanajar($mapel));
    }

    public function hapusbahanajar()
    {
        header('Content-Type: application/json');
        $noid = json_decode($_POST['sapi'], false);
        $id = $noid->noid;
        $this->model('model_admin')->hapusbahanajar($id);
        echo "DATA MATERI BAHAN AJAR SUDAH DIHAPUS";
    }
    public function logout()
    {
        session_destroy();
        header("Location:" . BASEURL . "/login");
    }
}
