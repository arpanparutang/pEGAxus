<?php
class user extends Controller
{
    public function __construct()
    {
        session_start();
        if ((isset($_SESSION['namasiswa'])) && ($_SESSION['validasi'] == 1)) {
            $_SESSION['ok'] = "JADI";
        } else {
            header("Location:" . BASEURL . "/loginuser");
        }
    }

    public function index()
    {
        $this->view('user/index');
    }

    public function absen()
    {
        $this->view('user/absen');
    }
    public function statusabsensi()
    {
        $this->view('user/statusabsensi');
    }
    public function inputabsen()
    {
        header('Content-Type: application/json');
        $data1 = json_decode($_POST['sapi'], false);
        $status1 = htmlspecialchars($data1->status);
        $gambar = htmlspecialchars($data1->gambar);
        $lat = htmlspecialchars($data1->lat);
        $lng = htmlspecialchars($data1->lng);
        $this->model('model_user')->inputabsen($status1, $gambar, $lat, $lng);
        echo "OK";
    }

    public function gantipassword()
    {
        $this->view('user/gantipassword');
    }
    public function gantipass()
    {
        header('Content-Type: application/json');
        $data1 = json_decode($_POST['sapi'], false);
        $passlama = htmlspecialchars($data1->passlama);
        $passbaru = htmlspecialchars($data1->passbaru);
        $this->model('model_user')->gantipass($passlama, $passbaru);
        echo "OK";
    }

    public function kinerja()
    {
        $this->view('user/kinerja');
    }

    public function mediapembelajaran()
    {
        $data['mapel'] = $this->model('model_user')->mediapembelajaran();
        $this->view('user/mediapembelajaran', $data);
    }

    public function ambilbahanajar()
    {
        header('Content-Type: application/json');
        $data1 = json_decode($_POST['sapi'], false);
        $idmapel = htmlspecialchars($data1->mapel);
        echo json_encode($this->model('model_user')->ambilbahanajar($idmapel));
    }
    public function keluar()
    {
        session_destroy();
        header("Location:" . BASEURL . "/loginuser");
    }
}
