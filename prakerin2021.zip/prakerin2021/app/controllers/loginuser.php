<?php
class loginuser extends Controller
{
    public function index()
    {
        $this->view('loginuser/index');
    }
    public function ceklogin()
    {
        header('Content-Type: application/json');
        $kuda = json_decode($_POST['sapi'], false);
        $nis = $kuda->nis;
        $nis1 = preg_replace('/[=\@\" "\.\;\<\>]+/', "", $nis);
        $pass = $kuda->pass;
        $pass1 = preg_replace('/[=\@\" "\.\;\<\>]+/', "", $pass);
        echo json_encode($this->model('model_user')->ceklogin($nis1, $pass1));
    }
    public function validasilogin()
    {
        $nis1 = preg_replace('/[=\@\" "\.\;\<\>\"\']+/', "", $_POST['nis']);
        $pass1 = preg_replace('/[=\@\" "\.\;\<\>\"\']+/', "", $_POST['pass']);
        $cek['datasiswa'] = $this->model('model_user')->datalogin($nis1, $pass1);
        // var_dump($cek['datasiswa']);
        $countlenght = count($cek['datasiswa']);
        if ($countlenght > 0) {
            foreach ($cek['datasiswa'] as $siswa) {
                $nama = $siswa['namasiswa'];
                $nis = $siswa['nis'];
                $kelas = $siswa['kelas'];
                $kantor = $siswa['nama'];
            }
            session_start();
            $_SESSION['namasiswa'] = $nama;
            $_SESSION['nissiswa'] = $nis;
            $_SESSION['kelassiswa'] = $kelas;
            $_SESSION['kantor'] = $kantor;
            $_SESSION['validasi'] = 1;

            header("Location:" . BASEURL . "/user/index");
        } else {
            header("Location:" . BASEURL . "/loginuser/index");
        }
    }
}
