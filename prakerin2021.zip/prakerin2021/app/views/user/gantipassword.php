<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User</title>
    <link rel="stylesheet" href="<?= BASEURL; ?>/css/absen.css" type="text/css">
</head>

<body>
    <div class="kontainer-utama">
        <div class="kontainer-kepala">
            <div class="judul-aplikasi">
                <span>GANTI PASSWORD</span>
            </div>
            <div class="nama-pengguna">
                <span><?= $_SESSION['namasiswa']; ?></span>
            </div>
            <div class="kelas-nis">
                <span><?= $_SESSION['kelassiswa']; ?> (NIS : <?= $_SESSION['nissiswa']; ?>)</span>
            </div>
            <div class="tempat-prakerin">
                <span> <?= $_SESSION['kantor']; ?> </span>
            </div>
            <div class="tempat-prakerin">
                <a href="<?= BASEURL; ?>/user/keluar"><button type="button" class="tombol-logout">LOGOUT</button> </a>
            </div>
        </div>
        <div class="kontainer-badan">
            <div class="abensi">
                <div class="status">
                    <span> PASSWORD LAMA </span>
                </div>
                <div class="status">
                    <input type="number" id="passlama"></input>
                </div>
                <div class="status">
                    <span> PASSWORD BARU </span>
                </div>
                <div class="status">
                    <input type="number" id="passbaru"></input>
                </div>
            </div>
            <div class="tombol-absen">
                <button type="button" id="tombolkirim" onclick="gantipass()">GANTI PASSWORD</button>
            </div>
        </div>
        <div class="kontainer-kaki">
            <?= owner; ?>
        </div>
    </div>

    </div>

    <script>
        function gantipass() {
            let passlama = document.getElementById('passlama').value;
            let passbaru = document.getElementById('passbaru').value;
            let xhr = new XMLHttpRequest();
            console.log(passlama, passbaru);
            xhr.onload = function() {
                let hasil = xhr.responseText;
                if (hasil === "OK") {
                    console.log(hasil);
                    window.location.replace("<?= BASEURL; ?>/user/statusabsensi");
                } else {
                    window.location.replace("<?= BASEURL; ?>/user/statusabsensi");
                }
            }
            let data = JSON.stringify({
                'passlama': passlama,
                'passbaru': passbaru
            })
            xhr.open('POST', '<?= BASEURL; ?>/user/gantipass', true);
            xhr.setRequestHeader('Content-type', 'application/x-www-form-urlencoded');
            xhr.send("sapi=" + data);
        }
    </script>
</body>

</html>