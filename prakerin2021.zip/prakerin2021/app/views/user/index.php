<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User</title>
    <link rel="stylesheet" href="<?= BASEURL; ?>/css/absen.css" type="text/css">
</head>

<body>
    <div class="kontainer-utama">
        <div class="kontainer-kepala">
            <div class="judul-aplikasi">
                <span>APLIKASI PRAKERIN ONLINE</span>
            </div>
            <div class="nama-pengguna">
                <span><?= $_SESSION['namasiswa']; ?></span>
            </div>
            <div class="kelas-nis">
                <span><?= $_SESSION['kelassiswa']; ?> (NIS : <?= $_SESSION['nissiswa']; ?>)</span>
            </div>
            <div class="tempat-prakerin">
                <span> <?= $_SESSION['kantor']; ?> </span>
            </div>
            <div class="tempat-prakerin">
                <div class="tempat-tombol">
                    <a href="<?= BASEURL; ?>/user/keluar"><button type="button" class="tombol-logout">LOGOUT</button> </a>
                    <a href="<?= BASEURL; ?>/user/gantipassword"><button type="button" class="tombol-logout">GANTI PASSWORD</button> </a>
                </div>
            </div>
        </div>
        <div class="kontainer-badan">
            <div class="abensi">
                <div class="tempat-kartu">

                    <div class="kartu-menu">
                        <div class="icon-kartu"><img src="<?= BASEURL; ?>/img/tasks.png"> </div>
                        <div class="isi-kartu"><a href="<?= BASEURL; ?>/user/absen"> ABSENSI PESERTA</a></div>

                    </div>


                    <div class="kartu-menu">
                        <div class="icon-kartu"><img src="<?= BASEURL; ?>/img/work.png"> </div>
                        <div class="isi-kartu"> <a href="<?= BASEURL; ?>/user/kinerja">INPUT KINERJA</a></div>
                    </div>


                    <div class="kartu-menu">
                        <div class="icon-kartu"><img src="<?= BASEURL; ?>/img/books.png"> </div>
                        <div class="isi-kartu"><a href="<?= BASEURL; ?>/user/mediapembelajaran"> Media Pembelajaran</a></div>
                    </div>

                </div>
            </div>
        </div>
        <div class="kontainer-kaki">
            <?= owner; ?>
        </div>
    </div>


    <!-- MODAL USER -->
    <div class="tempat-modal" id="modal-prakerin">
        <div class="modal-infoprakerin">
            <div class="kepala-modal">
                <div class="judul-kepala-modal">Info Prakerin</div>
            </div>
            <div class="isi-modal">
                <div class="item-isi-modal">
                    Disampaikan kepada siswa klas XI bahwa PRAKERIN dilaksanakan 24 Oktober 2022 - 20 April 2023, Oleh Karena itu, setiap peserta prakerin diharuskan untuk melakukan absensi pada aplikasi ini, Mengisi format laporan yang ada pada buku panduan (lembar laporan tersebut dapat digandakan sesuai kebutuhan) Membuat daftar hadir cetak di lokasi masing-masing, dan melakukan pembimbingan belajar sesuai jadwal yang ditetapkan oleh Program Keahlian masing-masing
                </div>

                <div class="item-isi-modal">
                    Silakan di simak kegiatan belajar pada video pembelajaran dan kirimkan tugas sesuai dengan instruksi pada Video tersebut
                </div>

            </div>
            <div class="kaki-modal"><button type="button" class="tutup-modal" onclick="tutupmodal()"> TUTUP</button>
            </div>
        </div>
    </div>

    <script>
        function tutupmodal() {
            let modal = document.getElementById("modal-prakerin");
            modal.style.display = "none";
        }
    </script>
</body>

</html>