<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User</title>
    <link rel="stylesheet" href="<?= BASEURL; ?>/css/absen.css" type="text/css">
</head>

<body>
    <div class="kontainer-utama">
        <div class="kontainer-kepala">
            <div class="judul-aplikasi">
                <span>BAHAN BELAJAR</span>
            </div>
            <div class="nama-pengguna">
                <span><?= $_SESSION['namasiswa']; ?></span>
            </div>
            <div class="kelas-nis">
                <span><?= $_SESSION['kelassiswa']; ?> (NIS : <?= $_SESSION['nissiswa']; ?>)</span>
            </div>
            <div class="tempat-prakerin">
                <span> <?= $_SESSION['kantor']; ?> </span>
            </div>
            <div class="tempat-prakerin">
                <div class="tempat-tombol">
                    <a href="<?= BASEURL; ?>/user/keluar"><button type="button" class="tombol-logout">LOGOUT</button> </a>

                </div>
            </div>
        </div>
        <div class="kontainer-badan">
            <div class="abensi">
                <div class="status">
                    <span> Pilih Nama Mapel </span>
                </div>
                <div class="status">
                    <select id="mapel">
                        <option value="">-</option>
                        <?php foreach ($data['mapel'] as $mapel) { ?>
                            <option value="<?= $mapel['id_mapel']; ?>"><?= $mapel['namamapel']; ?></option>
                        <?php } ?>
                    </select>
                </div>
                <div class="status">
                    <button type="button" class="tombol-foto" id="ambilfoto" onclick="ambilbahanajar()">Lihat Bahan Ajar</button>
                </div>
                <div class="status">
                    <div class="table-mapel" id="table-mapel">
                        <table id="tabel">
                            <tr>
                                <th>Materi ke-</th>
                            </tr>
                        </table>
                    </div>
                </div>
            </div>
        </div>
        <div class="kontainer-kaki">
            <?= owner; ?>
        </div>
    </div>

    <script>
        function ambilbahanajar() {
            document.getElementById("table-mapel").style.display = "flex";
            let mapel = document.getElementById("mapel").value;
            let tabel = document.getElementById("tabel");
            let rowCount = tabel.rows.length;
            for (var x = rowCount - 1; x > 0; x--) {
                tabel.deleteRow(x);
            }
            console.log(mapel);
            let xhr = new XMLHttpRequest();
            xhr.onload = function() {
                let hasil = JSON.parse(xhr.responseText);
                console.log(hasil);
                if (hasil.length > 0) {
                    for (let a = 0; a < hasil.length; a++) {
                        let row = tabel.insertRow(-1);
                        let cel1 = row.insertCell(0);
                        cel1.innerHTML = " <a href='" + hasil[a].link + "'>Klik/Tap materi ke-" + (a + 1) + " ( " + hasil[a].tipe + " )</a>";

                    }
                }

            }
            let data = JSON.stringify({
                'mapel': mapel
            });
            xhr.open('POST', '<?= BASEURL; ?>/user/ambilbahanajar', true);
            xhr.setRequestHeader('Content-type', 'application/x-www-form-urlencoded');
            xhr.send("sapi=" + data);
        }
    </script>

</body>

</html>