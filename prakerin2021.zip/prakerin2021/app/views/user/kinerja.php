<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User</title>
    <link rel="stylesheet" href="<?= BASEURL; ?>/css/absen.css" type="text/css">
</head>

<body>
    <div class="kontainer-utama">
        <div class="kontainer-kepala">
            <div class="judul-aplikasi">
                <span>ISI KINERJA</span>
            </div>
            <div class="nama-pengguna">
                <span><?= $_SESSION['namasiswa']; ?></span>
            </div>
            <div class="kelas-nis">
                <span><?= $_SESSION['kelassiswa']; ?> (NIS : <?= $_SESSION['nissiswa']; ?>)</span>
            </div>
            <div class="tempat-prakerin">
                <span> <?= $_SESSION['kantor']; ?> </span>
            </div>
            <div class="tempat-prakerin">
                <div class="tempat-tombol">
                    <a href="<?= BASEURL; ?>/user/keluar"><button type="button" class="tombol-logout">LOGOUT</button> </a>

                </div>
            </div>
        </div>
        <div class="kontainer-badan">
            <div class="kinerja">
                <h1> Halaman Ini belum diupdate</h1>

            </div>
        </div>
        <div class="kontainer-kaki">
            <?= owner; ?>
        </div>
    </div>



</body>

</html>