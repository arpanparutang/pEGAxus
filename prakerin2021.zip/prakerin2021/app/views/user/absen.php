<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User</title>
    <link rel="stylesheet" href="<?= BASEURL; ?>/css/absen.css" type="text/css">
</head>

<body>
    <div class="kontainer-utama">
        <div class="kontainer-kepala">
            <div class="judul-aplikasi">
                <span>ABSENSI ONLINE PESERTA PRAKERIN</span>
            </div>
            <div class="nama-pengguna">
                <span><?= $_SESSION['namasiswa']; ?></span>
            </div>
            <div class="kelas-nis">
                <span><?= $_SESSION['kelassiswa']; ?> (NIS : <?= $_SESSION['nissiswa']; ?>)</span>
            </div>
            <div class="tempat-prakerin">
                <span> <?= $_SESSION['kantor']; ?> </span>
            </div>
            <div class="tempat-prakerin">
                <a href="<?= BASEURL; ?>/user/keluar"><button type="button" class="tombol-logout">LOGOUT</button> </a>
            </div>
        </div>
        <div class="kontainer-badan">
            <div class="abensi">
                <div class="status">
                    <span> STATUS </span>
                </div>
                <div class="status">
                    <select id="status">
                        <option value="">-</option>
                        <option value="1">HADIR</option>
                        <option value="-1">SAKIT</option>
                        <option value="0">IZIN</option>
                    </select>
                </div>
                <div class="status">
                    <button type="button" class="tombol-lokasi" onclick="ambillokasi()">AMBIL LOKASI</button>
                </div>
                <div class="status">
                    Koordinat Latitude : <span id="latitude"></span>
                </div>
                <div class="status">
                    Koordinat Longitude : <span id="longitude"></span>
                </div>
                <div class="lokasi">
                    <div id="map"></div>

                </div>
                <div class="status">
                    <button type="button" onclick="ambilfoto()" class="tombol-foto" id="ambilfoto">Ambil Foto</button>
                </div>
                <div class="foto">
                    <div class="video">
                        <video id="video" width="640" height="480" autoplay></video>
                    </div>
                </div>
                <div class="status">
                    <button id="snap" onclick="ambilgambar()" class="tombol-foto">Snap Photo</button>
                </div>
                <div class="canvas">
                    <canvas id="canvas" width="640" height="480"></canvas>
                </div>
            </div>
            <div class="tombol-absen">
                <button type="button" id="tombolkirim" onclick="kirimdata()">KIRIM</button>
            </div>
        </div>
        <div class="kontainer-kaki">
            <?= owner; ?>
        </div>
    </div>

    </div>

    <script>
        let x = document.getElementById('latitude');
        let y = document.getElementById('longitude');
        let lat = 0.1;
        let long = 0.1;

        function ambillokasi() {

            if (navigator.geolocation) {
                navigator.geolocation.getCurrentPosition(showposition);

            } else {
                x.innerHTML = "LOKASI TIDAK DITEMUKAN";
                y.innerHTML = "LOKASI TIDAK DITEMUKAN";
            }
        }

        function showposition(posisi) {
            x.innerHTML = " " + posisi.coords.latitude;
            y.innerHTML = " " + posisi.coords.longitude;
            lat = posisi.coords.latitude;
            long = posisi.coords.longitude;
            let latlon = lat + "," + long;
            document.getElementsByClassName('lokasi')[0].style.display = "flex";
            document.getElementById('map').innerHTML = "<iframe height='100%' width='100%' src='https://maps.google.com/maps?q=" + lat + "," + long + "&output=embed'></iframe>";

        }


        function ambilfoto() {
            let video = document.getElementById('video');
            video.style.display = "unset";
            document.getElementById('ambilfoto').style.display = "none";
            document.getElementById('snap').style.display = "unset";
            document.getElementById("canvas").style.display = "none";

            // Get access to the camera!
            if (navigator.mediaDevices && navigator.mediaDevices.getUserMedia) {
                // Not adding `{ audio: true }` since we only want video now
                navigator.mediaDevices.getUserMedia({
                    video: true
                }).then(function(stream) {
                    //video.src = window.URL.createObjectURL(stream);
                    video.srcObject = stream;
                    video.play();
                });
            }

            /* Legacy code below: getUserMedia 
            else if(navigator.getUserMedia) { // Standard
                navigator.getUserMedia({ video: true }, function(stream) {
                    video.src = stream;
                    video.play();
                }, errBack);
            } else if(navigator.webkitGetUserMedia) { // WebKit-prefixed
                navigator.webkitGetUserMedia({ video: true }, function(stream){
                    video.src = window.webkitURL.createObjectURL(stream);
                    video.play();
                }, errBack);
            } else if(navigator.mozGetUserMedia) { // Mozilla-prefixed
                navigator.mozGetUserMedia({ video: true }, function(stream){
                    video.srcObject = stream;
                    video.play();
                }, errBack);
            }
            */
        }
        let gambar = 0;

        function ambilgambar() {
            var canvas = document.getElementById('canvas');
            canvas.style.display = 'unset';
            var context = canvas.getContext('2d');
            var video = document.getElementById('video');

            document.getElementById("snap").addEventListener("click", function() {
                context.drawImage(video, 0, 0, 640, 480);
                gambar = 1;
                video.style.display = "none";
                document.getElementById("snap").style.display = "none";
                document.getElementById("ambilfoto").style.display = "unset";
            });
        }

        function kirimdata() {
            let status = document.getElementById("status").value;
            let canvas = document.getElementById('canvas');
            console.log(gambar, lat, long, status);
            if ((gambar != 1) || (lat === 0) || (long === 0) || (status == "")) {
                console.log("ba FOTO dulu ");
            } else {
                let xhr = new XMLHttpRequest();
                xhr.onload = function() {
                    let hasil = xhr.responseText;
                    if (hasil === "OK") {
                        window.location.replace("<?= BASEURL; ?>/user/statusabsensi");
                    } else {
                        window.location.replace("<?= BASEURL; ?>/user/statusabsensi");
                    }
                }
                let data = JSON.stringify({
                    'status': status,
                    'gambar': gambar,
                    'lat': lat,
                    'lng': long
                })
                xhr.open('POST', '<?= BASEURL; ?>/user/inputabsen', true);
                xhr.setRequestHeader('Content-type', 'application/x-www-form-urlencoded');
                xhr.send("sapi=" + data);
            }

        }
    </script>
</body>

</html>