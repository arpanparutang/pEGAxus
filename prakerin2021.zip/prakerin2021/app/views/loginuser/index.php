<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="<?= BASEURL; ?>/css/login.css">
    <link rel="stylesheet" href="<?= BASEURL; ?>/css/loginhp.css">
    <title>Prakerin SMKN 1 Kotamobagu</title>
</head>

<body>
    <div class="kontainer-utama">

        <div class="kontainer-isi">
            <div class="isi-badan">
                <div class="isi-badan-gambar">
                    <img src="<?= BASEURL; ?>/img/bg1.png">
                </div>
                <div class="isi-badan-tulisan">
                    <div class="judul-tulisan">
                        <h2> SMK NEGERI 1 KOTAMOBAGU </h2>
                    </div>
                    <div class="isi-tulisan">
                        Panitia Pelaksana Prakerin <br>
                        Tahun Pelajaran 2022/2023
                    </div>
                </div>
            </div>
        </div>
        <div class="kontainer-login">
            <div class="badan-login">
                <div class="kepala-login">
                    Aplikasi e-Prakerin
                </div>
                <div class="isi-login">
                    <form method="post" action="<?= BASEURL; ?>/loginuser/validasilogin" id="formceklogin">
                        <div class="isi-login-item">
                            NIS
                        </div>
                        <div class="isi-login-item">
                            <input type="number" name="nis" id="nis">
                        </div>
                        <div class="isi-login-item">
                            PASSWORD
                        </div>
                        <div class="isi-login-item">
                            <input type="password" name="pass" id="pass">
                        </div>
                        <div class="isi-login-item">
                            TULISKAN
                        </div>
                        <div class="isi-login-item">
                            <b>SMK BISA</b>
                        </div>
                        <div class="isi-login-item">
                            <input type="text" name="kunci" id="kunci">
                        </div>
                    </form>
                </div>
                <div class="kaki-login">
                    <button type="button" class="tombol" id="ceklogin">LOGIN</button>
                </div>
            </div>
        </div>

    </div>
</body>
<script>
    document.getElementById("ceklogin").addEventListener("click", function() {
        let nis = document.getElementById("nis").value;
        let pass = document.getElementById("pass").value;
        let kunci = document.getElementById("kunci").value;
        if ((kunci == "SMK BISA") || (kunci != "")) {
            if ((nis != "") && (pass != "")) {
                kunci = kunci.replace(/</g, "").replace(/>/g, "-");
                pass = pass.replace(/</g, "").replace(/>/g, "-");
                let xhr = new XMLHttpRequest();
                xhr.onload = function() {
                    let hasil = JSON.parse(xhr.responseText);
                    if (hasil.length > 0) {
                        document.getElementById("formceklogin").submit();

                    } else {
                        alert("TIDAK ADA HAK AKSES");
                        location.reload();

                    }

                }
                let data = JSON.stringify({
                    'nis': nis,
                    'pass': pass
                })
                xhr.open('POST', '<?= BASEURL; ?>/loginuser/ceklogin', true);
                xhr.setRequestHeader('Content-type', 'application/x-www-form-urlencoded');
                xhr.send("sapi=" + data);
            } else {
                alert("DATA KOSONG");


            }
        } else {
            alert("tulis kunci");
        }

    })
</script>

</html>