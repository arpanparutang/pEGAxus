<div class="input-nis">
    <span> Masukkan Nis </span>
    <input type="number" id="nis">
</div>
<div class="tombol"> <button type="button" class="tombol" onclick="carinis()"> Cari </button>
</div>
<div class="daftar-siswa">
    <div class="foto-siswa">
        <img src="<?= BASEURL; ?>/img/logo3.gif">
    </div>
    <div class="data-diri">
        <div class="data-siswa">
            <span> Nama </span>
        </div>
        <div class="data-siswa">
            <span> Tempat dan Tanggal Lahir </span>
        </div>
        <div class="data-siswa">
            <span> Kelas </span>
        </div>
        <div class="data-siswa">
            <span> Kompetensi Keahlian </span>
        </div>
        <div class="data-siswa">
            <span> Lokasi </span>
        </div>
        <div class="data-siswa">
            <span>Pembimbing Sekolah</span>
        </div>
    </div>
    <div class="isi-data-diri">
        <div class="data-siswa">
            <span> : </span>
            <span id="nama"> </span>
        </div>
        <div class="data-siswa">
            <span> : </span>
            <span id="ttl"> </span>
        </div>
        <div class="data-siswa">
            <span> : </span>
            <span id="kelas"></span>
        </div>
        <div class="data-siswa">
            <span> : </span>
            <select id="kompetensi" name="kompetensi" onchange="pilihdudika()">
                <option value="">--</option>
                <?php foreach ($data['kompetensi'] as $kmp) { ?>
                    <option value="<?php echo $kmp['no'] ?>"><?php echo $kmp['namajurusan'] ?></option>
                <?php } ?>
            </select>

        </div>
        <div class="data-siswa">
            <span> : </span>
            <select id="dudika" name="dudika" onchange="sisakuota()">
                <option value="">--</option>
            </select>
            <span> Sisa Kuota </span>
            <span id="sisakuota"> </span>
        </div>
        <div class="data-siswa">
            <span> : </span>
            <span><select id="pembimbing" name="pembimbing">
                    <option value="">--</option>
                </select>
            </span>
            <span> </span>
        </div>
    </div>
</div>
<div class="record-siswa">
    <fieldset class="data-record-siswa">
        <legend>Catatan Prakerin </legend>
        <div class="isi-keterangan">
            <span id="isi-keterangan"> </span>
        </div>
    </fieldset>
</div>
<div class="daftarkan">
    <button type="button" class="tombol" id="daftarkan" onclick="daftarkan()">DAFTARKAN</button>
</div>
<script>
    function pilihdudika() {
        let jurusan = document.getElementById("kompetensi").value;
        const pilihdudika = document.getElementById("dudika");
        const pilihnamapembimbing = document.getElementById("pembimbing")
        for (let a = pilihdudika.length - 1; a >= 1; a--) {
            pilihdudika.remove(a);
        }
        for (let b = pilihnamapembimbing.length - 1; b >= 1; b--) {
            pilihnamapembimbing.remove(b);
        }
        let xhr = new XMLHttpRequest();
        xhr.onload = function() {
            let hasil = JSON.parse(xhr.responseText);
            for (let x = 0; x < hasil.length; x++) {
                let option = document.createElement('option');
                option.text = hasil[x].nama;
                option.value = hasil[x].no;
                pilihdudika.add(option);
            }



        }
        let data1 = JSON.stringify({
            'jurusan': jurusan
        })
        xhr.open('POST', '<?= BASEURL; ?>/admin/ambildatakuota', true);
        xhr.setRequestHeader('Content-type', 'application/x-www-form-urlencoded');
        xhr.send('sapi=' + data1);


        //pilih nama pembimbing

        let shr = new XMLHttpRequest();
        shr.onload = function() {
            let hasil2 = JSON.parse(shr.responseText);
            console.log(hasil2);
            for (let a = 0; a < hasil2.length; a++) {
                let option = document.createElement('option');
                option.text = hasil2[a].namapembimbing;
                option.value = hasil2[a].id_pembimbing;
                pilihnamapembimbing.add(option);
            }
        }
        let data2 = JSON.stringify({
            'jurusan': jurusan
        })
        shr.open('POST', '<?= BASEURL; ?>/admin/ambilnamapembimbing', true);
        shr.setRequestHeader('Content-type', 'application/x-www-form-urlencoded');
        shr.send('sapi2=' + data2);
        //habis pilih pembimbing
    }



    function sisakuota() {
        let dudika = document.getElementById('dudika').value;
        let jurusan = document.getElementById("kompetensi").value;
        let xhr = new XMLHttpRequest();
        xhr.onload = function() {
            let hasil = JSON.parse(xhr.responseText);

            document.getElementById("isi-keterangan").innerHTML = hasil[0].ket;
            document.getElementById("sisakuota").innerHTML = hasil[0].sisa_kuota;
        }
        let data1 = JSON.stringify({
            'jurusan': jurusan,
            'dudika': dudika
        })
        xhr.open('POST', '<?= BASEURL; ?>/admin/ambilsisakuota', true);
        xhr.setRequestHeader('Content-type', 'application/x-www-form-urlencoded');
        xhr.send('sapi=' + data1);
    }

    let nosiswa = 0;

    function carinis() {
        let nis = document.getElementById('nis').value;
        let shr = new XMLHttpRequest();
        shr.onload = function() {
            let hasil = JSON.parse(shr.responseText);

            nosiswa = hasil[0].no;
            document.getElementById("nama").innerHTML = hasil[0].namasiswa;
            document.getElementById("ttl").innerHTML = hasil[0].tempat_lahir + " " + hasil[0].tanggal + " " + hasil[0].bulan_lahir + " " + hasil[0].tahun;
            document.getElementById("kelas").innerHTML = hasil[0].kelas;
            //validate siswa 
            let xhr = new XMLHttpRequest();
            xhr.onload = function() {
                let hasil2 = JSON.parse(xhr.responseText);
                console.log(hasil2);
                if (hasil2.length > 0) {
                    alert("siswa telah ditempatkan");
                    location.reload();

                }
            }
            let data2 = JSON.stringify({
                'nosiswa': nosiswa
            })
            xhr.open('POST', '<?= BASEURL; ?>/admin/validasidatasiswa', true);
            xhr.setRequestHeader('Content-type', 'application/x-www-form-urlencoded');
            xhr.send('sapi=' + data2);
        }
        let data = JSON.stringify({
            'nis': nis
        })
        shr.open('POST', '<?= BASEURL; ?>/admin/ambildatasiswa', true);
        shr.setRequestHeader('Content-type', 'application/x-www-form-urlencoded');
        shr.send('sapi=' + data);
    }

    function daftarkan() {

        let idjur = document.getElementById("kompetensi").value;
        let iddudika = document.getElementById("dudika").value;
        let idpembimbing = document.getElementById("pembimbing").value;
        if ((idjur != "") && (iddudika != "") && (idpembimbing != "") && (nosiswa != 0)) {
            let xhr = new XMLHttpRequest();
            xhr.onload = function() {
                let hasil = xhr.responseText;
                alert(hasil);
                location.reload();

            }
            let data = JSON.stringify({
                'nosiswa': nosiswa,
                'idjur': idjur,
                'iddudika': iddudika,
                'idpembimbing': idpembimbing
            })
            xhr.open('POST', '<?= BASEURL; ?>/admin/inputpenempatan', true);
            xhr.setRequestHeader('Content-type', 'application/x-www-form-urlencoded');
            xhr.send('sapi=' + data);
        } else {
            alert("DATA ADA YANG KOSONG");
            location.reload();
        }
    }
</script>