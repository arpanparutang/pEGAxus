<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="<?= BASEURL; ?>/css/haladmin.css">
    <title>Halaman Admin</title>
    <script>
        let a = 0;

        function tampilkanmenu() {
            if (a == 0) {
                document.getElementById('menu').style.marginLeft = '-20vw';
                document.getElementById('tombolMenu').innerHTML = "Buka Menu";
                a = 1;
            } else {
                document.getElementById('menu').style.marginLeft = '0';
                document.getElementById('tombolMenu').innerHTML = "tutup Menu";
                a = 0;
            }
        }
    </script>
</head>

<body>
    <div class="kontainer-grid">
        <div class="menu-grid" id="menu">
            <div class="logo"> <img src="<?= BASEURL; ?>/img/logo3.gif"></div>
            <div class="namaapp">Aplikasi Pengontrol Prakerin</div>
            <div class="daftar-menu">
                <UL>
                    <li><a href="#">PENGUMUMAN</a></li>
                    <li><a href="#">INPUT DUDIKA</a></li>
                    <li><a href="#">PENDAFTARAN PESERTA</a></li>
                    <li><a href="#">REKAP PENEMPATAN</a></li>
                    <li><a href="#">LOGOUT</a></li>
                </UL>
            </div>
            <div class="logout-menu">
                <span> <?= owner; ?></span>
            </div>
        </div>
        <div class="content-grid">
            <div class="tombol-menu">
                <button type="button" class="tombol" onclick="tampilkanmenu()" id="tombolMenu">Tutup Menu</button>
            </div>
            <div class="judul-app">
                <span>Selamat Datang di Aplikasi Prakerin SMKN 1 KOTAMOBAGU</span>
            </div>
            <div class="isi-content">
                <div class="berita">
                    <div class="judul-berita"><span> INFORMASI PENDATAAN PRAKERIN</span>
                    </div>
                    <div class="isi-berita">
                        <UL>
                            <LI> Lorem ipsum, dolor sit amet consectetur adipisicing elit. Distinctio veniam eaque earum architecto eligendi a delectus ex? Id deserunt voluptatum, officiis temporibus ad quam, natus, quaerat placeat est optio perspiciatis? </LI>
                            <LI> BERITA 1 </LI>
                            <LI> BERITA 1 </LI>
                        </UL>
                    </div>
                </div>
                <div class="berita">
                    <div class="judul-berita"><span> INFORMASI PENDATAAN PRAKERIN</span>
                    </div>
                    <div class="isi-berita">
                        <UL>
                            <LI> Lorem ipsum, dolor sit amet consectetur adipisicing elit. Distinctio veniam eaque earum architecto eligendi a delectus ex? Id deserunt voluptatum, officiis temporibus ad quam, natus, quaerat placeat est optio perspiciatis? </LI>
                            <LI> BERITA 1 </LI>
                            <LI> BERITA 1 </LI>
                        </UL>
                    </div>
                </div>
                <div class="berita">
                    <div class="judul-berita"><span> INFORMASI PENDATAAN PRAKERIN</span>
                    </div>
                    <div class="isi-berita">
                        <UL>
                            <LI> Lorem ipsum, dolor sit amet consectetur adipisicing elit. Distinctio veniam eaque earum architecto eligendi a delectus ex? Id deserunt voluptatum, officiis temporibus ad quam, natus, quaerat placeat est optio perspiciatis? </LI>
                            <LI> BERITA 1 </LI>
                            <LI> BERITA 1 </LI>
                        </UL>
                    </div>
                </div>
            </div>

        </div>

    </div>
</body>

</html>