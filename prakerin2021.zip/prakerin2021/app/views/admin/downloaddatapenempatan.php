<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Data Penempatan</title>
</head>

<body>

    <table border=1>
        <tr align=center>
            <th> No </th>
            <th> NIS </th>
            <th> Nama</th>
            <th> Kelas </th>
            <th> Kompetensi </th>
            <th> Lokasi </th>
            <th> Pembimbing </th>
            <th> Ket. </th>
        </tr>
        <?php
        $a = 1;
        foreach ($data['penempatan'] as $tmp) { ?>


            <tr>
                <td> <?= $a; ?> </td>
                <td> <?= $tmp['nis']; ?> </td>
                <td> <?= $tmp['namasiswa']; ?> </td>
                <td> <?= $tmp['kelas']; ?> </td>
                <td> <?= $tmp['namajurusan']; ?> </td>
                <td> <?= $tmp['nama']; ?> </td>
                <td> <?= $tmp['namapembimbing']; ?> </td>
                <td> </td>
            </tr>
        <?php $a++;
        }; ?>

    </table>
</body>

</html>