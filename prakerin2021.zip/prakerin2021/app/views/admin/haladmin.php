<div class="berita">
    <div class="judul-berita"><span> CARA INPUT DATA DUDIKA</span>
    </div>
    <div class="isi-berita">
        <UL>
            <LI> Input Dulu Data dudika oleh Tim Pokja Humas</LI>
            <LI> Jika ada perubahan nama maka silakan di Edit</LI>
            <LI> Pokja Humas Dilarang Untuk Menghapus atau menambahkan Data Penempatan</LI>
        </UL>
    </div>
</div>
<div class="berita">
    <div class="judul-berita"><span> CARA INPUT DATA PENEMPATAN</span>
    </div>
    <div class="isi-berita">
        <UL>
            <LI> Masing-masing Kepala Program Keahlian Silakan Menginput data Penempatan Ketika Peserta didik telah memenuhi syarat pada saat mendaftar</LI>
            <LI> DATA PEMBIMBING SEKOLAH WAJIB DIISI OLEH PRODI</LI>
            <LI> Jika ada Perubahan Lokasi atau penempatan peserta, maka silakan dihapus dulu data penempatan peserta yang bersangkutan lalu diinput kembali </LI>
            <LI> Pembagian ATK dan Atribut dilaksanakan oleh Prodi pada saat pendaftaran </LI>
            <LI> Silakan Berkoordinasi dengan Sek. Prakerin jika mengalami kesulitan </LI>
        </UL>
    </div>
</div>
<div class="berita">
    <div class="judul-berita"><span> WAKTU DAN TANGGAL KEGIATAN</span>
    </div>
    <div class="isi-berita">
        <UL>
            <LI> Input Dudikan oleh Tim Humas sesuai laporan (Senin, 17 - 18 Oktober 2022) </LI>
            <LI> Input Penempatan Oleh Kompetensi Keahlian (18 - 21 Oktober 2022) </LI>
            <LI> Pelepasan Peserta (Kamis 20 Oktober 2022 ) </LI>
            <LI> Pembagian Lokasi dan Surat Pengantar (24 Oktober 2022) </LI>
            <LI> Turun ke lapangan (24 - 25 Oktober 2022) </LI>
            <LI> Prakerin Berakhir tanggal 20 April 2022 </LI>
        </UL>
    </div>
</div>