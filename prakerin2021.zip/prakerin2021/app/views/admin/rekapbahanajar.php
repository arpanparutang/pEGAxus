<div class="pilih-daftar-dudika">
    <div> <span> PILIH MATA PELAJARAN </span></div>
    <div> <select id="mapel" name="mapel">
            <option value="">--</option>
            <?php foreach ($data['mapel'] as $mapel) { ?>
                <option value="<?= $mapel['id_mapel']; ?>"><?= $mapel['namamapel']; ?></option>
            <?php } ?>
        </select>
    </div>
    <div> <button type="button" class="tombol" onclick="lihatrekap()">Lihat Rekap</button></div>

</div>
<div class=" data-penempatan">
    <fieldset>
        <legend> DATA BAHAN AJAR </legend>
        <div class="table-penempatan">
            <table id="table-penempatan">
                <tr>
                    <th>NO </th>
                    <th>KELAS</th>
                    <th>MATERI KE-</th>
                    <th>LINK</th>
                    <th>TIPE</th>
                    <th>TINDAKAN</th>
                </tr>

            </table>
        </div>
    </fieldset>
</div>
<script>
    function lihatrekap() {
        let mapel = document.getElementById("mapel").value;
        let tb = document.getElementById("table-penempatan");
        let rowcount = tb.rows.length;
        for (let x = rowcount - 1; x > 0; x--) {
            tb.deleteRow(x);
        }
        if (mapel != "") {
            let xhr = new XMLHttpRequest();
            xhr.onload = function() {
                let hasil = JSON.parse(xhr.responseText);
                console.log(hasil);
                for (let a = 0; a < hasil.length; a++) {
                    let row = tb.insertRow(-1);
                    let cel0 = row.insertCell(0);
                    let cel1 = row.insertCell(1);
                    let cel2 = row.insertCell(2);
                    let cel3 = row.insertCell(3);
                    let cel4 = row.insertCell(4);
                    let cel5 = row.insertCell(5);
                    cel0.innerHTML = a + 1;
                    cel1.innerHTML = hasil[a].kelas;
                    cel2.innerHTML = hasil[a].materike;
                    cel3.innerHTML = hasil[a].link;
                    cel4.innerHTML = hasil[a].tipe;
                    cel5.innerHTML = "<button type='button' class='tombol' id='" + hasil[a].id_materi + "' onclick='hapusbahanajar(id)'>HAPUS</button>";
                }
            }
            data = JSON.stringify({
                'mapel': mapel
            })
            xhr.open('POST', "<?= BASEURL; ?>/admin/ambilrekapbahanajar", true);
            xhr.setRequestHeader('Content-type', 'application/x-www-form-urlencoded')
            xhr.send("sapi=" + data);
        } else {
            alert("pilih Mapel dulu bos");
        }
    }

    function hapusbahanajar(id) {
        let noid = id;
        let xhr = new XMLHttpRequest();
        xhr.onload = function() {
            let hasil = xhr.responseText;
            alert(hasil);
            location.reload();
        }
        data = JSON.stringify({
            'noid': noid
        })
        xhr.open('POST', "<?= BASEURL; ?>/admin/hapusbahanajar", true);
        xhr.setRequestHeader('Content-type', 'application/x-www-form-urlencoded')
        xhr.send("sapi=" + data);
    }

    /*  function downloadrekap() {
          let xhr = new XMLHttpRequest();
          xhr.onload = function() {
              let hasil = JSON.parse(xhr.responseText);
              console.log(hasil);
          }
          xhr.open('POST', "<?= BASEURL; ?>/admin/downloadpenempatan", true);
          xhr.setRequestHeader('Content-type', 'application/x-www-form-urlencoded')
          xhr.send();
      }*/
</script>