<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="<?= BASEURL; ?>/css/haladmin.css">
    <link rel="stylesheet" href="<?= BASEURL; ?>/css/adminhp.css">
    <title>Halaman Admin</title>

    <script>
        let a = 0;

        function tampilkanmenu() {
            if (a == 0) {

                document.getElementById('menu').style.marginLeft = '-20vw';
                document.getElementById('tombolMenu').innerHTML = "Buka Menu";
                a = 1;
            } else {
                document.getElementById('menu').style.marginLeft = '0';
                document.getElementById('tombolMenu').innerHTML = "tutup Menu";
                a = 0;
            }
        }
    </script>
</head>

<body>
    <div class="kontainer-grid">
        <div class="menu-grid" id="menu">
            <div class="logo"> <img src="<?= BASEURL; ?>/img/logo3.gif"></div>
            <div class="namaapp">Aplikasi Pengontrol Prakerin</div>
            <div class="daftar-menu">
                <UL>
                    <li><a href="<?= BASEURL; ?>/admin/haladmin">PENGUMUMAN</a></li>
                    <li><a href="<?= BASEURL; ?>/admin/inputdudika">INPUT DUDIKA</a></li>
                    <li><a href="<?= BASEURL; ?>/admin/editdatadudika">EDIT DUDIKA</a></li>
                    <li><a href="<?= BASEURL; ?>/admin/pembimbing">INPUT PEMBIMBING</a></li>
                    <li><a href="<?= BASEURL; ?>/admin/pendaftaran">PENDAFTARAN PESERTA</a></li>
                    <li><a href="<?= BASEURL; ?>/admin/rekappenempatan">REKAP PENEMPATAN</a></li>
                    <li><a href="<?= BASEURL; ?>/admin/materiajar">INPUT BAHAN AJAR</a></li>
                    <li><a href="<?= BASEURL; ?>/admin/rekapbahanajar">REKAP BAHAN AJAR</a></li>
                    <li><a href="<?= BASEURL; ?>/admin/logout">LOGOUT</a></li>
                </UL>
            </div>
            <div class="logout-menu">
                <span> <?= owner; ?></span>
            </div>
        </div>
        <div class="content-grid" id="content-grid">
            <div class="tombol-menu">
                <button type="button" class="tombol" onclick="tampilkanmenu()" id="tombolMenu">Tutup Menu</button>
            </div>
            <div class="judul-app">
                <span>Selamat Datang di Aplikasi Prakerin SMKN 1 KOTAMOBAGU</span>
            </div>
            <div class="isi-content">