<div class="judul-pembimbing">
    Input Data Pembimbing
</div>
<div class="data-pembimbing">
    <div class="nama-pembimbing"><span> Nama </span></div>
    <div class="input-nama"><input type="text" name="nama" id="nama"></div>
</div>
<div class="data-pembimbing">
    <div class="nama-pembimbing"><span> Kompetensi Keahlian </span></div>
    <div class="input-nama">
        <select id="jurusan">
            <option value="">--</option>
            <?php foreach ($data['kompetensi'] as $kmp) { ?>
                <option value="<?php echo $kmp['no'] ?>"><?php echo $kmp['namajurusan'] ?></option>
            <?php } ?>
        </select>
    </div>
</div>
<div class="tambah-pembimbing">
    <button class="tombol" id="tambah-pembimbing" onclick="tambahPembimbing()">TAMBAH</button>
</div>
<fieldset class="daftar-pembimbing">
    <legend> Daftar Nama Pembimbing</legend>
    <div class="table-pembimbing">
        <table>
            <tr>
                <th>NO </th>
                <th>Nama</th>
                <th>Kompetensi Keahlian</th>
                <th>Hapus</th>
            <tr>
                <?php
                $a = 1;
                foreach ($data['pembimbing'] as $bimbing) { ?>
            <tr>
                <td><?= $a; ?></td>
                <td><?= $bimbing['namapembimbing']; ?></td>
                <td><?= $bimbing['namajurusan']; ?></td>
                <td><button type="button" id="<?= $bimbing['id_pembimbing']; ?>" onclick="hapusPembimbing(id)" class="tombol">HAPUS</button>
            </tr>
        <?php $a++;
                } ?>
        </table>
    </div>
</fieldset>

<script>
    function tambahPembimbing() {
        let nama = document.getElementById('nama').value;
        let jurusan = document.getElementById('jurusan').value;
        if ((nama != "") && (jurusan != "")) {
            let xhr = new XMLHttpRequest();
            xhr.onload = function() {
                let hasil = xhr.responseText;
                alert(hasil);
                location.reload();
            }
            let data1 = JSON.stringify({
                'nama': nama,
                'jurusan': jurusan
            })
            xhr.open('POST', "<?= BASEURL; ?>/admin/tambahpembimbing", true);
            xhr.setRequestHeader('Content-type', 'application/x-www-form-urlencoded')
            xhr.send("sapi=" + data1);
        } else {
            alert("NAMA ATAU JURUSAN KOSONG");
        }
    }

    function hapusPembimbing(id) {
        let xhr = new XMLHttpRequest();
        xhr.onload = function() {
            let hasil = xhr.responseText;
            alert(hasil);
            location.reload();
        }
        let data1 = JSON.stringify({
            'id': id,
        })
        xhr.open('POST', "<?= BASEURL; ?>/admin/hapuspembimbing", true);
        xhr.setRequestHeader('Content-type', 'application/x-www-form-urlencoded')
        xhr.send("sapi=" + data1);

    }
</script>