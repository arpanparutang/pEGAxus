</div>
</div>

</div>
<div class="modal-dudika" id="modal-dudika">
    <div class="isi-modal-dudika">
        <div class="kepala-modal">
            <div class="judul-modal"> <span id="judul-modal"></span>
            </div>
            <div class="tutup-modal" id="tutup-modal" onclick="tutupmodal()">X</div>
        </div>
        <div class="badan-modal">

            <table id="tabel-kuota-dudika" class="tabel-kuota-dudika">
                <tr>
                    <th> No </th>
                    <th> Nama Dudika </th>
                    <th> Kuota </th>
                    <th> Sisa Kuota </th>
                </tr>
            </table>

        </div>
        <div class="kaki-modal"> ini bagian kaki</div>
    </div>
</div>
</body>

</html>