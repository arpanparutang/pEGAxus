<div class="pilih-daftar-dudika">
    <div> <span> PILIH KOMPETENSI KEAHLIAN </span></div>
    <div> <select id="kompetensi" name="kompetensi">
            <option value="">--</option>
            <?php foreach ($data['kompetensi'] as $kmp) { ?>
                <option value="<?php echo $kmp['no'] ?>"><?php echo $kmp['namajurusan'] ?></option>
            <?php } ?>
        </select>
    </div>
    <div> <button type="button" class="tombol" onclick="tampilmodaldudika()">Lihat Daftar Dudika</button></div>
</div>
<form method="post" action="<?= BASEURL; ?>/admin/inputdatadudika" id="formDudika">
    <div class="input-dudika">
        <div class="judul-dudika">

        </div>
        <div class="baris-input">
            <div class="judul-baris-input">
                Nama Dudika
            </div>
            <div class="input-data" maxlength="200">
                <input type="text" name="namaDudika" id="namaDudika">
            </div>
            <div class="judul-baris-input">
                Lokasi
            </div>
            <div class="input-data" maxlength="200">
                <input type="text" name="lokasiDudika">
            </div>
            <div class="judul-baris-input">
                Nama Pimpinan
            </div>
            <div class="input-data" maxlength="200">
                <input type="text" name="pimpinanDudika">
            </div>
            <div class="judul-baris-input">
                Keterangan
            </div>
            <div class="input-data" maxlength="200">
                <input type="text" name="ket">
            </div>


            <div class="fieldset1" id="fieldset1">
                <fieldset class="fieldset-dudika">
                    <legend> Kuota Jurusan </legend>
                    <div class="isi-fieldset">
                        <div class="fieldset-kanan">
                            <div class="kompetensi">Akuntansi dan keuangan Lembaga</div>
                            <div class="jatah"><input type="number" name="kuotaAkl"></div>
                            <div class="kompetensi">Perbankan dan Keungan Mikro</div>
                            <div class="jatah"><input type="number" name="kuotaPbk"></div>
                            <div class="kompetensi">Otomatisasi dan Tata Kelola Perkantoran</div>
                            <div class="jatah"><input type="number" name="kuotaOtkp"></div>
                            <div class="kompetensi">Asisten Keperawatan</div>
                            <div class="jatah"><input type="number" name="kuotaAskep"></div>
                        </div>
                        <div class="fieldset-kiri">
                            <div class="kompetensi">Multimedia</div>
                            <div class="jatah"><input type="number" name="kuotaMm"></div>
                            <div class="kompetensi">Rekayasa Perangkat Lunak</div>
                            <div class="jatah"><input type="number" name="kuotaRpl"></div>
                            <div class="kompetensi">Teknik Komputer dan Jaringan</div>
                            <div class="jatah"><input type="number" name="kuotaTkj"></div>
                            <div class="kompetensi">Teknik Energi Biomassa</div>
                            <div class="jatah"><input type="number" name="kuotaTeb"></div>
                        </div>
                    </div>
                </fieldset>

            </div>
            <div class="tempat-tombol">
                <button type="button" class="tombol" onclick="inputdatadudika()">Input</button>
                <input type="reset" class="tombol" value="reset">
            </div>
</form>
</div>


<script>
    function inputdatadudika() {
        let hasil2 = {};
        let data = document.getElementById('namaDudika').value;
        if (data === "") {
            alert('data kosong');
        } else {
            let xhr = new XMLHttpRequest();
            xhr.onreadystatechange = function() {
                if (xhr.readyState === 4) {
                    let hasil = JSON.parse(xhr.responseText);
                    if (hasil.length > 0) {
                        hasil2 = hasil;
                        alert("data sudah ada");

                    } else {

                        document.getElementById("formDudika").submit();
                        document.getElementById('namaDudika').value = "";
                        alert("data sudah masuk");

                        //document.getElementById("fieldset1").style.display = 'unset';
                    }
                }
            }

            let data1 = JSON.stringify({
                'nama': data
            });
            xhr.open('POST', '<?= BASEURL; ?>/admin/ambildatadudika', true);
            xhr.setRequestHeader('Content-type', 'application/x-www-form-urlencoded');
            xhr.send('sapi=' + data1);
        }

    }

    function tampilmodaldudika() {
        document.getElementById('modal-dudika').style.display = 'flex';
        let idjurusan = document.getElementById('kompetensi').value;
        let tabeldudika = document.getElementById('tabel-kuota-dudika');
        console.log(idjurusan);
        let xhr = new XMLHttpRequest();
        xhr.onload = function() {
            let hasil = JSON.parse(xhr.responseText);
            console.log(hasil);
            for (let a = 0; a < hasil.length; a++) {
                let row = tabeldudika.insertRow(-1);
                let cel0 = row.insertCell(0);
                let cel1 = row.insertCell(1);
                let cel2 = row.insertCell(2);
                let cel3 = row.insertCell(3);
                cel0.innerHTML = a + 1;
                cel1.innerHTML = hasil[a].nama;
                cel2.innerHTML = hasil[a].kuota;
                cel3.innerHTML = hasil[a].sisa_kuota;
            }
            document.getElementById("judul-modal").innerHTML = 'Nama Dudik ' + hasil[0].namajurusan;
        }
        let data = JSON.stringify({
            'id': idjurusan
        });
        xhr.open('POST', '<?= BASEURL; ?>/admin/ambilkuotajurusan', true);
        xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
        xhr.send('sapi=' + data);
    }

    function tutupmodal() {
        document.getElementById('modal-dudika').style.display = 'none';
        location.reload();

    }
</script>