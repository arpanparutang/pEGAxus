<div class="pilih-daftar-dudika">
    <div> <span> PILIH KOMPETENSI KEAHLIAN </span></div>
    <div> <select id="kompetensi" name="kompetensi">
            <option value="">--</option>
            <?php foreach ($data['kompetensi'] as $kmp) { ?>
                <option value="<?php echo $kmp['no'] ?>"><?php echo $kmp['namajurusan'] ?></option>
            <?php } ?>
        </select>
    </div>
    <div> <button type="button" class="tombol" onclick="lihatrekap()">Lihat Rekap</button></div>
    <div> <a href="<?= BASEURL; ?>/admin/downloaddatapenempatan"><button type=" button" class="tombol">Download Excel</button><a></div>
</div>
<div class=" data-penempatan">
    <fieldset>
        <legend> DATA PENEMPATAN </legend>
        <div class="table-penempatan">
            <table id="table-penempatan">
                <tr>
                    <th>NO </th>
                    <th>NIS </th>
                    <th>Nama</th>
                    <th>Nama Pembimbing</th>
                    <th>Penempatan</th>
                    <th>Hapus</th>
                </tr>

            </table>
        </div>
    </fieldset>
</div>
<script>
    function lihatrekap() {
        let jur = document.getElementById("kompetensi").value;
        let tb = document.getElementById("table-penempatan");
        let rowcount = tb.rows.length;
        for (let x = rowcount - 1; x > 0; x--) {
            tb.deleteRow(x);
        }
        if (jur != "") {
            let xhr = new XMLHttpRequest();
            xhr.onload = function() {
                let hasil = JSON.parse(xhr.responseText);
                console.log(hasil);
                for (let a = 0; a < hasil.length; a++) {
                    let row = tb.insertRow(-1);
                    let cel0 = row.insertCell(0);
                    let cel1 = row.insertCell(1);
                    let cel2 = row.insertCell(2);
                    let cel3 = row.insertCell(3);
                    let cel4 = row.insertCell(4);
                    let cel5 = row.insertCell(5);
                    cel0.innerHTML = a + 1;
                    cel1.innerHTML = hasil[a].nis;
                    cel2.innerHTML = hasil[a].namasiswa;
                    cel3.innerHTML = hasil[a].namapembimbing;
                    cel4.innerHTML = hasil[a].nama;
                    cel5.innerHTML = "<button type='button' class='tombol' id='" + hasil[a].no + "' onclick='hapuspenempatan(id)'>HAPUS</button>";
                }
            }
            data = JSON.stringify({
                'jur': jur
            })
            xhr.open('POST', "<?= BASEURL; ?>/admin/ambilrekappenempatan", true);
            xhr.setRequestHeader('Content-type', 'application/x-www-form-urlencoded')
            xhr.send("sapi=" + data);
        } else {
            alert("pilih jurusan dulu bos");
        }
    }

    function hapuspenempatan(id) {
        let noid = id;
        let xhr = new XMLHttpRequest();
        xhr.onload = function() {
            let hasil = xhr.responseText;
            alert(hasil);
            location.reload();
        }
        data = JSON.stringify({
            'noid': noid
        })
        xhr.open('POST', "<?= BASEURL; ?>/admin/hapuspenempatan", true);
        xhr.setRequestHeader('Content-type', 'application/x-www-form-urlencoded')
        xhr.send("sapi=" + data);
    }

    function downloadrekap() {
        let xhr = new XMLHttpRequest();
        xhr.onload = function() {
            let hasil = JSON.parse(xhr.responseText);
            console.log(hasil);
        }
        xhr.open('POST', "<?= BASEURL; ?>/admin/downloadpenempatan", true);
        xhr.setRequestHeader('Content-type', 'application/x-www-form-urlencoded')
        xhr.send();
    }
</script>