<div class="pilih-daftar-dudika">
    <div> <span> INPUT BAHAN AJAR </span></div>

</div>
<form method="post" action="<?= BASEURL; ?>/admin/inputbahanajar" id="formBahanajar">
    <div class="input-dudika">
        <div class="judul-dudika">

        </div>
        <div class="baris-input">
            <div class="judul-baris-input">
                Pilih Mata Pelajaran
            </div>
            <div class="input-data">
                <div class="data-siswa">
                    <div> <select id="mapel" name="mapel">
                            <option value="">--</option>
                            <?php foreach ($data['mapel'] as $kmp) { ?>
                                <option value="<?php echo $kmp['id_mapel'] ?>"><?php echo $kmp['namamapel'] ?></option>
                            <?php } ?>
                        </select>
                    </div>
                </div>
            </div>
            <div class="judul-baris-input">
                kelas
            </div>
            <div class="input-data" maxlength="200">
                <input type="text" name="kelas" id="kelas">
            </div>
            <div class="judul-baris-input">
                Link
            </div>
            <div class="input-data">
                <input type="text" name="link" id="link">
            </div>
            <div class="judul-baris-input">
                Materi Ke-
            </div>
            <div class="input-data" maxlength="200">
                <div class="data-siswa">
                    <div> <select id="materike" name="materike">
                            <option value="">--</option>
                            <?php for ($a = 1; $a <= 20; $a++) { ?>
                                <option value="<?php echo $a; ?>"><?php echo $a; ?></option>
                            <?php } ?>
                        </select>
                    </div>
                </div>
            </div>
            <div class="judul-baris-input">
                Tipe Materi
            </div>
            <div class="input-data" maxlength="200">
                <div class="data-siswa">
                    <div> <select id="tipe" name="tipe">
                            <option value="">--</option>
                            <option value="video">video</option>
                            <option value="modul">modul</option>
                            <option value="presentasi">presentasi</option>
                            <option value="tugas">tugas</option>
                            <option value="lain-lain">lain-lain</option>
                        </select>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="tempat-tombol">
        <button type="button" class="tombol" onclick="inputdatamapel()">Input</button>
        <input type="reset" class="tombol" value="reset">
    </div>
</form>
</div>

<script>
    function inputdatamapel() {
        let mapel = document.getElementById("mapel").value;
        let kelas = document.getElementById("kelas").value;
        let link = document.getElementById("link").value;
        let materike = document.getElementById("materike").value;
        let tipe = document.getElementById("tipe").value;
        let link2 = "";
        link2 = link;
        console.log(mapel, kelas, link, materike, tipe);
        if ((mapel != "") && (link != "") && (materike != "") && (tipe != "")) {
            /*  let xhr = new XMLHttpRequest();
              xhr.onload = function() {
                  let hasil = xhr.responseText;
                  alert(hasil);
                  location.reload();

              }
              let data1 = JSON.stringify({
                  'mapel': mapel,
                  'kelas': kelas,
                  'link2': link2,
                  'materike': materike,
                  'tipe': tipe
              })
              xhr.open('POST', '<?= BASEURL; ?>/admin/inputbahanajar', true);
              xhr.setRequestHeader('Content-type', 'application/x-www-form-urlencoded');
              xhr.send('sapi=' + data1);*/
            document.getElementById('formBahanajar').submit();

        }
    }
</script>