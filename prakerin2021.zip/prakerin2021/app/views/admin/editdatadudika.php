<form method="post" action="<?= BASEURL; ?>/admin/proseseditdatadudika" id="formDudika">
    <div class="pilih-daftar-dudika">
        <div> <span> PILIH NAMA DUDIKA </span></div>
        <div> <select id="dudika" name="nodudika">
                <option value="">--</option>
                <?php foreach ($data['dudika'] as $kmp) { ?>
                    <option value="<?php echo $kmp['no'] ?>"><?php echo $kmp['nama'] ?></option>
                <?php } ?>
            </select>
        </div>
        <div> <button type="button" class="tombol" onclick="tampilkandudika()">Tampilkan data</button></div>
    </div>

    <div class="input-dudika">
        <div class="judul-dudika">

        </div>
        <div class="baris-input">
            <div class="judul-baris-input">
                Nama Dudika
            </div>
            <div class="input-data" maxlength="200">
                <input type="text" name="namaDudika" id="namaDudika">
            </div>
            <div class="judul-baris-input">
                Lokasi
            </div>
            <div class="input-data" maxlength="200">
                <input type="text" name="lokasiDudika" id="lokasiDudika">
            </div>
            <div class="judul-baris-input">
                Nama Pimpinan
            </div>
            <div class="input-data" maxlength="200">
                <input type="text" name="pimpinanDudika" id="pimpinanDudika">
            </div>
            <div class="judul-baris-input">
                Keterangan
            </div>
            <div class="input-data" maxlength="200">
                <input type="text" name="ket" id="ket">
            </div>


            <div class="fieldset1" id="fieldset1">
                <fieldset class="fieldset-dudika">
                    <legend> Kuota Jurusan </legend>
                    <div class="isi-fieldset">
                        <div class="fieldset-kanan">
                            <div class="kompetensi">Akuntansi dan keuangan Lembaga</div>
                            <div class="jatah"><input type="number" name="kuotaAkl" id="kuotaAkl"></div>
                            <div class="kompetensi">Perbankan dan Keungan Mikro</div>
                            <div class="jatah"><input type="number" name="kuotaPbk" id="kuotaPbk"></div>
                            <div class="kompetensi">Otomatisasi dan Tata Kelola Perkantoran</div>
                            <div class="jatah"><input type="number" name="kuotaOtkp" id="kuotaOtkp"></div>
                            <div class="kompetensi">Asisten Keperawatan</div>
                            <div class="jatah"><input type="number" name="kuotaAskep" id="kuotaAskep"></div>
                        </div>
                        <div class="fieldset-kiri">
                            <div class="kompetensi">Multimedia</div>
                            <div class="jatah"><input type="number" name="kuotaMm" id="kuotaMm"></div>
                            <div class="kompetensi">Rekayasa Perangkat Lunak</div>
                            <div class="jatah"><input type="number" name="kuotaRpl" id="kuotaRpl"></div>
                            <div class="kompetensi">Teknik Komputer dan Jaringan</div>
                            <div class="jatah"><input type="number" name="kuotaTkj" id="kuotaTkj"></div>
                            <div class="kompetensi">Teknik Energi Biomassa</div>
                            <div class="jatah"><input type="number" name="kuotaTeb" id="kuotaTeb"></div>
                        </div>
                    </div>
                </fieldset>

            </div>
            <div class="tempat-tombol">
                <button type="button" class="tombol" onclick="prosesedit()" id="gantidudika">ganti</button>

            </div>
</form>
</div>

<script>
    let id_dudika = 0;

    /*  function tampilkandudika() {
        let nodudika = document.getElementById("dudika").value;
        let xhr = new XMLHttpRequest();
        xhr.onload = function() {
            let hasil = JSON.parse(xhr.responseText);
            console.log(hasil);
            document.getElementById("namaDudika").value = hasil[0].nama;
            document.getElementById("lokasiDudika").value = hasil[0].alamat;
            document.getElementById("pimpinanDudika").value = hasil[0].pimpinan;
            document.getElementById("ket").value = hasil[0].ket;
            document.getElementById("kuotaAkl").value = hasil[0].kuota;
            document.getElementById("kuotaPbk").value = hasil[1].kuota;
            document.getElementById("kuotaOtkp").value = hasil[2].kuota;
            document.getElementById("kuotaAskep").value = hasil[3].kuota;
            document.getElementById("kuotaMm").value = hasil[4].kuota;
            document.getElementById("kuotaRpl").value = hasil[5].kuota;
            document.getElementById("kuotaTkj").value = hasil[6].kuota;
            document.getElementById("kuotaTeb").value = hasil[7].kuota;
            document.getElementById("gantidudika").style.display = "unset";

        }
        let data = JSON.stringify({
            'nodudika': nodudika
        })
        xhr.open('POST', '<?= BASEURL; ?>/admin/ambilnomordudika', true);
        xhr.setRequestHeader('Content-type', 'application/x-www-form-urlencoded');
        xhr.send('sapi=' + data);
    }
*/
    async function tampilkandudika() {
        let nodudika = document.getElementById("dudika").value;
        console.log(nodudika)
        let url = '<?= BASEURL; ?>/admin/ambilnomordudika'
        let isi = {
            method: 'POST',
            body: JSON.stringify({
                'sapi': nodudika
            }),
            headers: {
                "Content-type": "application/json"
            }
        }
        fetch(url, isi)
            .then(res => res.json())
            .then(json => cetak(json))
    }

    function cetak(json) {
        let hasil = json;
        document.getElementById("namaDudika").value = hasil[0].nama;
        document.getElementById("lokasiDudika").value = hasil[0].alamat;
        document.getElementById("pimpinanDudika").value = hasil[0].pimpinan;
        document.getElementById("ket").value = hasil[0].ket;
        document.getElementById("kuotaAkl").value = hasil[0].kuota;
        document.getElementById("kuotaPbk").value = hasil[1].kuota;
        document.getElementById("kuotaOtkp").value = hasil[2].kuota;
        document.getElementById("kuotaAskep").value = hasil[3].kuota;
        document.getElementById("kuotaMm").value = hasil[4].kuota;
        document.getElementById("kuotaRpl").value = hasil[5].kuota;
        document.getElementById("kuotaTkj").value = hasil[6].kuota;
        document.getElementById("kuotaTeb").value = hasil[7].kuota;
        document.getElementById("gantidudika").style.display = "unset";
    }

    function prosesedit() {
        document.getElementById("formDudika").submit();
    }
</script>