<?php

class model_admin
{

	private $db;

	public function __construct()
	{
		$this->db = new Database;
	}

	public function inputdatadudika()
	{
		$namaDudika = $_POST['namaDudika'];
		$lokasiDudika = $_POST['lokasiDudika'];
		$pimpinanDudika = $_POST['pimpinanDudika'];
		$ket = $_POST['ket'];
		$kuotaAkl = $_POST['kuotaAkl'];
		$kuotaPbk = $_POST['kuotaPbk'];
		$kuotaOtkp = $_POST['kuotaOtkp'];
		$kuotaAskep = $_POST['kuotaAskep'];
		$kuotaMm = $_POST['kuotaMm'];
		$kuotaRpl = $_POST['kuotaRpl'];
		$kuotaTkj = $_POST['kuotaTkj'];
		$kuotaTeb = $_POST['kuotaTeb'];
		$query = "INSERT INTO datadudika (nama,alamat,pimpinan,ket) VALUES (:namaDudika,:lokasiDudika,:pimpinanDudika,:ket)";
		$sapi = $this->db->query($query);
		$this->db->bind('namaDudika', $namaDudika);
		$this->db->bind('lokasiDudika', $lokasiDudika);
		$this->db->bind('pimpinanDudika', $pimpinanDudika);
		$this->db->bind('ket', $ket);
		$this->db->execute($sapi);
		$namaDudika2 = $namaDudika;
		$query2 = "SELECT no from datadudika where nama=:namaDudika ";
		$sapi2 = $this->db->query($query2);
		$this->db->bind('namaDudika', $namaDudika2);
		$hasil = $this->db->resultSet($sapi2);
		foreach ($hasil as $hsl) {
			$hasil1 = $hsl['no'];
		}
		$hasil12 = $hasil1;
		$queryAkl = "INSERT into kuota (kodejurusan,kodedudika,kuota,sisa_kuota) VALUES(1,:hasil12,:kuotaAkl,:kuotaAkl)";
		$sapiAkl = $this->db->query($queryAkl);
		$this->db->bind('hasil12', $hasil12);
		$this->db->bind('kuotaAkl', $kuotaAkl);
		$this->db->execute($sapiAkl);

		$queryPbk = "INSERT into kuota (kodejurusan,kodedudika,kuota,sisa_kuota) VALUES(2,:hasil12,:kuotaPbk,:kuotaPbk)";
		$sapiPbk = $this->db->query($queryPbk);
		$this->db->bind('hasil12', $hasil12);
		$this->db->bind('kuotaPbk', $kuotaPbk);
		$this->db->execute($sapiPbk);

		$queryOtkp = "INSERT into kuota (kodejurusan,kodedudika,kuota,sisa_kuota) VALUES(3,:hasil12,:kuotaOtkp,:kuotaOtkp)";
		$sapiOtkp = $this->db->query($queryOtkp);
		$this->db->bind('hasil12', $hasil12);
		$this->db->bind('kuotaOtkp', $kuotaOtkp);
		$this->db->execute($sapiOtkp);

		$queryAskep = "INSERT into kuota (kodejurusan,kodedudika,kuota,sisa_kuota) VALUES(4,:hasil12,:kuotaAskep,:kuotaAskep)";
		$sapiAskep = $this->db->query($queryAskep);
		$this->db->bind('hasil12', $hasil12);
		$this->db->bind('kuotaAskep', $kuotaAskep);
		$this->db->execute($sapiAskep);

		$queryMm = "INSERT into kuota (kodejurusan,kodedudika,kuota,sisa_kuota) VALUES(5,:hasil12,:kuotaMm,:kuotaMm)";
		$sapiMm = $this->db->query($queryMm);
		$this->db->bind('hasil12', $hasil12);
		$this->db->bind('kuotaMm', $kuotaMm);
		$this->db->execute($sapiMm);

		$queryRpl = "INSERT into kuota (kodejurusan,kodedudika,kuota,sisa_kuota) VALUES(6,:hasil12,:kuotaRpl,:kuotaRpl)";
		$sapiRpl = $this->db->query($queryRpl);
		$this->db->bind('hasil12', $hasil12);
		$this->db->bind('kuotaRpl', $kuotaRpl);
		$this->db->execute($sapiRpl);

		$queryTkj = "INSERT into kuota (kodejurusan,kodedudika,kuota,sisa_kuota) VALUES(7,:hasil12,:kuotaTkj,:kuotaTkj)";
		$sapiTkj = $this->db->query($queryTkj);
		$this->db->bind('hasil12', $hasil12);
		$this->db->bind('kuotaTkj', $kuotaTkj);
		$this->db->execute($sapiTkj);

		$queryTeb = "INSERT into kuota (kodejurusan,kodedudika,kuota,sisa_kuota) VALUES(8,:hasil12,:kuotaTeb,:kuotaTeb)";
		$sapiTeb = $this->db->query($queryTeb);
		$this->db->bind('hasil12', $hasil12);
		$this->db->bind('kuotaTeb', $kuotaTeb);
		$this->db->execute($sapiTeb);
	}
	public function proseseditdatadudika()
	{
		$nodudika = $_POST['nodudika'];
		$namaDudika = $_POST['namaDudika'];
		$lokasiDudika = $_POST['lokasiDudika'];
		$pimpinanDudika = $_POST['pimpinanDudika'];
		$ket = $_POST['ket'];
		$kuotaAkl = $_POST['kuotaAkl'];
		$kuotaPbk = $_POST['kuotaPbk'];
		$kuotaOtkp = $_POST['kuotaOtkp'];
		$kuotaAskep = $_POST['kuotaAskep'];
		$kuotaMm = $_POST['kuotaMm'];
		$kuotaRpl = $_POST['kuotaRpl'];
		$kuotaTkj = $_POST['kuotaTkj'];
		$kuotaTeb = $_POST['kuotaTeb'];
		$query = "UPDATE datadudika set nama=:namaDudika,alamat=:lokasiDudika,pimpinan=:pimpinanDudika,ket=:ket WHERE no=:nodudika";
		$querydudika = $this->db->query($query);
		$this->db->bind('namaDudika', $namaDudika);
		$this->db->bind('lokasiDudika', $lokasiDudika);
		$this->db->bind('pimpinanDudika', $pimpinanDudika);
		$this->db->bind('nodudika', $nodudika);
		$this->db->bind('ket', $ket);
		$this->db->execute($querydudika);

		$queryAkl = "UPDATE kuota set kuota=:kuotaAkl, sisa_kuota=:kuotaAkl-sisa_kuota where kodedudika=:nodudika AND kodejurusan=1";
		$sapiAkl = $this->db->query($queryAkl);
		$this->db->bind('kuotaAkl', $kuotaAkl);
		$this->db->bind('nodudika', $nodudika);
		$this->db->execute($sapiAkl);

		$queryPbk = "UPDATE kuota set kuota=:kuotaPbk, sisa_kuota=:kuotaPbk-sisa_kuota where kodedudika=:nodudika AND kodejurusan=2";
		$sapiPbk = $this->db->query($queryPbk);
		$this->db->bind('kuotaPbk', $kuotaPbk);
		$this->db->bind('nodudika', $nodudika);
		$this->db->execute($sapiPbk);

		$queryOtkp = "UPDATE kuota set kuota=:kuotaOtkp, sisa_kuota=:kuotaOtkp-sisa_kuota where kodedudika=:nodudika AND kodejurusan=3";
		$sapiOtkp = $this->db->query($queryOtkp);
		$this->db->bind('kuotaOtkp', $kuotaOtkp);
		$this->db->bind('nodudika', $nodudika);
		$this->db->execute($sapiOtkp);

		$queryAskep = "UPDATE kuota set kuota=:kuotaAskep, sisa_kuota=:kuotaAskep-sisa_kuota where kodedudika=:nodudika AND kodejurusan=4";
		$sapiAskep = $this->db->query($queryAskep);
		$this->db->bind('kuotaAskep', $kuotaAskep);
		$this->db->bind('nodudika', $nodudika);
		$this->db->execute($sapiAskep);

		$queryMm = "UPDATE kuota set kuota=:kuotaMm, sisa_kuota=:kuotaMm-sisa_kuota where kodedudika=:nodudika AND kodejurusan=5";
		$sapiMm = $this->db->query($queryMm);
		$this->db->bind('kuotaMm', $kuotaMm);
		$this->db->bind('nodudika', $nodudika);
		$this->db->execute($sapiMm);

		$queryRpl = "UPDATE kuota set kuota=:kuotaRpl, sisa_kuota=:kuotaRpl-sisa_kuota where kodedudika=:nodudika AND kodejurusan=6";
		$sapiRpl = $this->db->query($queryRpl);
		$this->db->bind('kuotaRpl', $kuotaRpl);
		$this->db->bind('nodudika', $nodudika);
		$this->db->execute($sapiRpl);

		$queryTkj = "UPDATE kuota set kuota=:kuotaTkj, sisa_kuota=:kuotaTkj-sisa_kuota where kodedudika=:nodudika AND kodejurusan=7";
		$sapiTkj = $this->db->query($queryTkj);
		$this->db->bind('kuotaTkj', $kuotaTkj);
		$this->db->bind('nodudika', $nodudika);
		$this->db->execute($sapiTkj);

		$queryTeb = "UPDATE kuota set kuota=:kuotaTeb, sisa_kuota=:kuotaTeb-sisa_kuota where kodedudika=:nodudika AND kodejurusan=8";
		$sapiTeb = $this->db->query($queryTeb);
		$this->db->bind('kuotaTeb', $kuotaTeb);
		$this->db->bind('nodudika', $nodudika);
		$this->db->execute($sapiTeb);
	}
	public function ambildatadudika($nama1)
	{

		$query = "SELECT * from datadudika WHERE nama=:nama";
		$this->db->query($query);
		$this->db->bind('nama', $nama1);
		return $this->db->resultSet();
	}
	public function ambilnomordudik($nodudika)
	{

		$query = "SELECT datadudika.*,kuota.* from datadudika JOIN kuota on datadudika.no=kuota.kodedudika WHERE datadudika.no=:nomor";
		$this->db->query($query);
		$this->db->bind('nomor', $nodudika);
		return $this->db->resultSet();
	}

	public function ambilsemuadudika()
	{
		$query = "SELECT * from datadudika ";
		$this->db->query($query);
		return $this->db->resultSet();
	}

	public function ambildatajurusan()
	{

		$query = "SELECT * from jurusan";
		$this->db->query($query);
		return $this->db->resultSet();
	}

	public function ambildatasemuadudika()
	{
		$query = "SELECT * from datadudika";
		$this->db->query($query);
		return $this->db->resultSet();
	}

	public function ambildatakuota($jurusan1)
	{
		$query = "SELECT datadudika.nama,datadudika.no from datadudika inner join kuota on kuota.kodedudika=datadudika.no WHERE kuota.kodejurusan=:jurusan1 AND kuota.kuota<>0";
		// $query = "SELECT kodedudika from kuota WHERE kodejurusan=:jurusan1";
		$query1 = $this->db->query($query);
		$this->db->bind('jurusan1', $jurusan1);
		return $this->db->resultSet($query1);
	}

	public function ambilsisakuota($jurusan1, $dudika)
	{
		$query = "SELECT kuota.sisa_kuota,datadudika.ket from kuota INNER JOIN datadudika on kuota.kodedudika=datadudika.no Where kuota.kodejurusan=:jurusan1 AND kuota.kodedudika=:dudika";
		$query1 = $this->db->query($query);
		$this->db->bind('jurusan1', $jurusan1);
		$this->db->bind('dudika', $dudika);
		return $this->db->resultSet($query1);
	}

	public function ambildatapembimbing()
	{
		$query = "SELECT pembimbing.id_pembimbing,pembimbing.namapembimbing,jurusan.namajurusan from pembimbing INNER JOIN jurusan on jurusan.no=pembimbing.kodejurusan ORDER by jurusan.namajurusan ASC";
		$query1 = $this->db->query($query);
		return $this->db->resultSet($query1);
	}

	public function ambilnamapembimbing($jurusan1)
	{
		$query = "SELECT pembimbing.namapembimbing,pembimbing.id_pembimbing FROM pembimbing INNER JOIN jurusan on jurusan.no=pembimbing.kodejurusan WHERE jurusan.no=:jurusan1";
		$query1 = $this->db->query($query);
		$this->db->bind('jurusan1', $jurusan1);
		return $this->db->resultSet($query1);
	}

	public function ambilkuotajurusan($idjur)
	{
		$query = "SELECT jurusan.namajurusan,kuota.kuota,datadudika.nama,kuota.sisa_kuota from jurusan JOIN kuota on jurusan.no=kuota.kodejurusan  JOIN datadudika on kuota.kodedudika=datadudika.no WHERE jurusan.no=:idjur AND kuota.kuota<>0";
		$query1 = $this->db->query($query);
		$this->db->bind('idjur', $idjur);
		return $this->db->resultSet($query1);
	}

	public function tambahpembimbing($nama, $jur)
	{
		$query = "INSERT INTO pembimbing(namapembimbing,kodejurusan) VALUES (:nama,:jur)";
		$query1 = $this->db->query($query);
		$this->db->bind('nama', $nama);
		$this->db->bind('jur', $jur);
		$this->db->execute($query1);
	}

	public function hapuspembimbing($idjur)
	{
		$query = "DELETE FROM pembimbing WHERE id_pembimbing=:idjur";
		$query1 = $this->db->query($query);
		$this->db->bind('idjur', $idjur);
		$this->db->execute($query1);
	}

	public function ambildatasiswa($nis)
	{

		$query = "SELECT * FROM datasiswa WHERE nis=:nis";
		$query1 = $this->db->query($query);
		$this->db->bind('nis', $nis);
		return $this->db->resultSet($query1);
	}

	public function validasidatasiswa($idsiswa)
	{
		$query = "SELECT * FROM penempatan WHERE id_siswa=:idsiswa";
		$query1 = $this->db->query($query);
		$this->db->bind('idsiswa', $idsiswa);
		return $this->db->resultSet($query1);
	}
	public function inputpenempatan($idjur, $nosiswa, $iddudika, $idpembimbing)
	{
		$query = "INSERT INTO penempatan(id_siswa,id_jurusan,id_dudika,id_pembimbing) VALUES(:nosiswa,:idjur,:iddudika,:idpembimbing)";
		$query1 = $this->db->query($query);
		$this->db->bind('idjur', $idjur);
		$this->db->bind('nosiswa', $nosiswa);
		$this->db->bind('iddudika', $iddudika);
		$this->db->bind('idpembimbing', $idpembimbing);
		$this->db->execute($query1);

		$query = "UPDATE kuota set kuota.sisa_kuota=(kuota.kuota-(SELECT COUNT(penempatan.no) FROM penempatan WHERE penempatan.id_jurusan=:idjur AND penempatan.id_dudika=:iddudika)) WHERE kuota.kodejurusan=:idjur AND kuota.kodedudika=:iddudika";
		$query1 = $this->db->query($query);
		$this->db->bind('idjur', $idjur);
		$this->db->bind('nosiswa', $nosiswa);
		$this->db->bind('iddudika', $iddudika);
		$this->db->bind('idpembimbing', $idpembimbing);
		$this->db->execute($query1);
	}

	public function ambilrekappenempatan($idjur)
	{
		//$query = "SELECT penempatan.no,datasiswa.nis,datasiswa.nama,jurusan.namajurusan,dudika.nama,pembimbing.nama FROM penempatan JOIN datasiswa on penempatan.id_siswa=datasiswa.no JOIN jurusan on jurusan.no=penempatan.id_jurusan JOIN dudika on dudika.no=penempatan.id_dudika JOIN pembimbing on penempatan.id_pembimbing=pembimbing.id_pembimbing WHERE id_jurusan=:idjur";
		$query = "SELECT penempatan.no,datasiswa.nis,datasiswa.namasiswa,jurusan.namajurusan,datadudika.nama,pembimbing.namapembimbing FROM penempatan JOIN datasiswa on penempatan.id_siswa=datasiswa.no JOIN jurusan on penempatan.id_jurusan=jurusan.no JOIN datadudika on penempatan.id_dudika=datadudika.no JOIN pembimbing on penempatan.id_pembimbing=pembimbing.id_pembimbing  WHERE penempatan.id_jurusan=:idjur";
		$query1 = $this->db->query($query);
		$this->db->bind('idjur', $idjur);
		return $this->db->resultSet($query1);
	}

	public function hapuspenempatan($id)
	{
		$query12 = "SELECT * from penempatan WHERE no=:id";
		$query22 = $this->db->query($query12);
		$this->db->bind('id', $id);
		$hasil = $this->db->resultSet($query22);
		foreach ($hasil as $hsl) {
			$idjur = $hsl['id_jurusan'];
			$iddudika = $hsl['id_dudika'];
		}
		$query33 = "UPDATE kuota set sisa_kuota=sisa_kuota+1 WHERE kodejurusan=:idjur AND kodedudika=:iddudika";
		$query34 = $this->db->query($query33);
		$this->db->bind('idjur', $idjur);
		$this->db->bind('iddudika', $iddudika);
		$this->db->execute($query34);

		$query = "DELETE from penempatan WHERE no=:id";
		$query1 = $this->db->query($query);
		$this->db->bind('id', $id);
		$this->db->execute($query1);
	}

	public function downloadpenempatan()
	{
		$query = "SELECT penempatan.no,datasiswa.nis,datasiswa.namasiswa,datasiswa.kelas,jurusan.namajurusan,datadudika.nama,pembimbing.namapembimbing FROM penempatan JOIN datasiswa on penempatan.id_siswa=datasiswa.no JOIN jurusan on penempatan.id_jurusan=jurusan.no JOIN datadudika on penempatan.id_dudika=datadudika.no JOIN pembimbing on penempatan.id_pembimbing=pembimbing.id_pembimbing ";
		$query1 = $this->db->query($query);
		return $this->db->resultSet($query1);
	}

	public function ceklogin($nis, $pass)
	{
		$query = "SELECT * from user where login=:nis AND pass=:pass ";
		$query1 = $this->db->query($query);
		$this->db->bind('nis', $nis);
		$this->db->bind('pass', $pass);
		return $this->db->resultSet($query1);
	}

	public function inputbahanajar()
	{
		$mapel = $_POST['mapel'];
		$kelas = $_POST['kelas'];
		$link = $_POST['link'];
		$materike = $_POST['materike'];
		$tipe = $_POST['tipe'];
		$queri = "INSERT INTO bahanajar(id_mapel,kelas,link,materike,tipe) VALUES(:mapel,:kelas,:link,:materike,:tipe)";
		$query1 = $this->db->query($queri);
		$this->db->bind('mapel', $mapel);
		$this->db->bind('kelas', $kelas);
		$this->db->bind('link', $link);
		$this->db->bind('materike', $materike);
		$this->db->bind('tipe', $tipe);
		$this->db->execute($query1);
	}

	public function ambilrekapbahanajar($mapel)
	{
		$query = "SELECT * from bahanajar where id_mapel=:mapel ";
		$query1 = $this->db->query($query);
		$this->db->bind('mapel', $mapel);
		return $this->db->resultSet($query1);
	}

	public function hapusbahanajar($id)
	{
		$query = "DELETE from bahanajar where id_materi=:id ";
		$query1 = $this->db->query($query);
		$this->db->bind('id', $id);
		$this->db->execute($query1);
	}
}
