<?php

class model_user
{

    private $db;

    public function __construct()
    {
        $this->db = new Database;
    }
    public function ceklogin($nis, $pass)
    {
        $query = "SELECT * from datasiswa where nis=:nis AND pass=:pass ";
        $query1 = $this->db->query($query);
        $this->db->bind('nis', $nis);
        $this->db->bind('pass', $pass);
        return $this->db->resultSet($query1);
    }

    public function datalogin($nis, $pass)
    {
        $query = "SELECT datasiswa.no,datasiswa.nis,datasiswa.namasiswa,datasiswa.kelas,penempatan.id_dudika,datadudika.nama from datasiswa JOIN penempatan on penempatan.id_siswa=datasiswa.no JOIN datadudika on penempatan.id_dudika=datadudika.no  where datasiswa.nis=:nis AND datasiswa.pass=:pass ";
        $query1 = $this->db->query($query);
        $this->db->bind('nis', $nis);
        $this->db->bind('pass', $pass);
        return $this->db->resultSet($query1);
    }

    public function inputabsen($status1, $gambar, $lat, $lng)
    {
        date_default_timezone_set("Asia/Makassar");
        $nama = $_SESSION['namasiswa'];
        $nis = $_SESSION['nissiswa'];
        $kantor = $_SESSION['kantor'];
        $kelas = $_SESSION['kelassiswa'];
        $tanggal = date('l') . "," . date('d-m-y');
        $waktu = date("H:i:s");
        $query22 = "SELECT * from absensi WHERE nis=:nis AND tanggal=:tanggal";
        $query23 = $this->db->query($query22);
        $this->db->bind('nis', $nis);
        $this->db->bind('tanggal', $tanggal);
        $hasil = $this->db->resultSet($query23);
        $cekhasil = count($hasil);
        if ($cekhasil > 0) {
            $_SESSION['pesanabsensi'] = "ANDA SUDAH PERNAH ABSEN";
        } else {
            $query = "INSERT INTO absensi(tanggal,waktu,nis,nama,kelas,lokasi,lat,lng,foto,aktivasi) VALUES(:tanggal,:waktu,:nis,:nama,:kelas,:kantor,:lat,:lng,:gambar,:status1)";
            $query1 = $this->db->query($query);
            $this->db->bind('nama', $nama);
            $this->db->bind('nis', $nis);
            $this->db->bind('kantor', $kantor);
            $this->db->bind('kelas', $kelas);
            $this->db->bind('tanggal', $tanggal);
            $this->db->bind('waktu', $waktu);
            $this->db->bind('status1', $status1);
            $this->db->bind('gambar', $gambar);
            $this->db->bind('lat', $lat);
            $this->db->bind('lng', $lng);
            $this->db->execute($query1);
            $_SESSION['pesanabsensi'] = "DATA ABSENSI ANDA TELAH TERCATAT";
        }
    }

    public function gantipass($passlama, $passbaru)
    {

        $nis = $_SESSION['nissiswa'];
        $query = "SELECT * from datasiswa WHERE nis=:nis AND pass=:passlama ";
        $query1 = $this->db->query($query);
        $this->db->bind('nis', $nis);
        $this->db->bind('passlama', $passlama);
        $hasil =  $this->db->resultSet($query1);
        $cekhasil = count($hasil);
        if ($cekhasil > 0) {
            $query22 = "UPDATE datasiswa set pass=:passbaru WHERE nis=:nis";
            $query33 = $this->db->query($query22);
            $this->db->bind('passbaru', $passbaru);
            $this->db->bind('nis', $nis);
            $this->db->execute($query33);
            $_SESSION['pesanabsensi'] = "PASSWORD Atas Nama " . $_SESSION['namasiswa'] . " TELAH DIGANTI ";
        } else {
            $_SESSION['pesanabsensi'] = "PASSWORD LAMA Atas Nama " . $_SESSION['namasiswa'] . " SALAH ";
        }
    }

    public function mediapembelajaran()
    {
        $query = "SELECT * from mapel ";
        $query1 = $this->db->query($query);
        return $this->db->resultSet($query1);
    }
    public function ambilbahanajar($idmapel)
    {
        $query = "SELECT * from bahanajar WHERE id_mapel=:idmapel ORDER BY materike ASC";
        $query1 = $this->db->query($query);
        $this->db->bind('idmapel', $idmapel);
        return $this->db->resultSet($query1);
    }
}
