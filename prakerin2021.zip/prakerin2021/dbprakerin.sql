-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Waktu pembuatan: 19 Sep 2021 pada 12.08
-- Versi server: 10.4.21-MariaDB
-- Versi PHP: 8.0.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `dbprakerin`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `datadudika`
--

CREATE TABLE `datadudika` (
  `no` int(11) NOT NULL,
  `nama` text NOT NULL,
  `alamat` text NOT NULL,
  `pimpinan` varchar(128) NOT NULL,
  `ket` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Struktur dari tabel `datasiswa`
--

CREATE TABLE `datasiswa` (
  `no` int(11) NOT NULL,
  `nis` int(10) NOT NULL,
  `namasiswa` varchar(128) NOT NULL,
  `tempat_lahir` varchar(128) NOT NULL,
  `tanggal` varchar(3) NOT NULL,
  `bulan_lahir` varchar(128) NOT NULL,
  `tahun` varchar(128) NOT NULL,
  `kelas` varchar(128) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `datasiswa`
--

INSERT INTO `datasiswa` (`no`, `nis`, `namasiswa`, `tempat_lahir`, `tanggal`, `bulan_lahir`, `tahun`, `kelas`) VALUES
(2, 20303, 'Abdul Gouwi Attamimi', 'KOTAMOBAGU', '8', 'FEBRUARI', '2006', ' XI AKL 1'),
(3, 20308, 'Alfiani Mokodompit', 'TANOYAN UTARA', '3', 'DESEMBER', '2004', ' XI AKL 1'),
(4, 20313, 'ANASTASYA JESICA KUMBEA', 'KOTAMOBAGU', '19', 'JULI', '2005', ' XI AKL 1'),
(5, 20318, 'Apriyani Dongkilat', 'Kopandakan 1', '8', 'APRIL', '2005', ' XI AKL 1'),
(6, 20323, 'Budi Wijaya Mokodompit', 'MATALI', '19', 'NOVEMBER', '2005', ' XI AKL 1'),
(7, 20328, 'Cyntia Dwi Hapsari Mamonto', 'Kotamobagu', '4', 'MEI', '2005', ' XI AKL 1'),
(8, 20333, 'ECCLESIA DELLA TAMPI', 'MANADO', '2', 'DESEMBER', '2005', ' XI AKL 1'),
(9, 20338, 'FALENTIN TAHIR', 'GOGAGOMAN', '14', 'FEBRUARI', '2005', ' XI AKL 1'),
(10, 20343, 'FEBRIANTI WULANDARI SAIDI', 'IKHWAN', '14', 'FEBRUARI', '2006', ' XI AKL 1'),
(11, 20348, 'GITRI BRIGITA KA\'U', 'KOPANDAKAN 2', '21', 'JUNI', '2005', ' XI AKL 1'),
(12, 20352, 'Innaalzana tilkawati Kumangki', 'Bakan', '10', 'JANUARI', '2006', ' XI AKL 1'),
(13, 20358, 'JULFIKAR TAMPOI', 'Kopandakan', '11', 'JULI', '2005', ' XI AKL 1'),
(14, 20363, 'KHICA V. DADUNGKAT', 'MOLINOW', '10', 'MEI', '2005', ' XI AKL 1'),
(15, 20368, 'Marsyah Badu', 'PIDUNG', '26', 'MARET', '2006', ' XI AKL 1'),
(16, 20374, 'MOH. HIDAYAT MOKOAGOW', 'GUNGGULANG', '20', 'DESEMBER', '2005', ' XI AKL 1'),
(17, 20379, 'Mutiara Arini Mokodongan', 'Bintau', '7', 'NOVEMBER', '2005', ' XI AKL 1'),
(18, 20384, 'NADIA PRASETIA ASIKING', 'POYOWA KECIL', '27', 'MEI', '2005', ' XI AKL 1'),
(19, 20389, 'Natasya Pioh', 'Bulud', '15', 'JUNI', '2004', ' XI AKL 1'),
(20, 20394, 'Nesi Rumoroy', 'Kobo Kecil', '30', 'DESEMBER', '2004', ' XI AKL 1'),
(21, 20398, 'NOVELIRA LOBATA', 'KOTAMOBAGU', '22 ', 'NOVEMBER', '2004', ' XI AKL 1'),
(22, 20405, 'Puan Maharani Monoarfa', 'KOTAMOBAGU', '26', 'JULI', '2005', ' XI AKL 1'),
(23, 20410, 'Rayhan Prasetya Mamonto', 'ABAK', '9', 'OKTOBER', '2005', ' XI AKL 1'),
(24, 20415, 'Rivana Mangga', 'Toruakat', '2', 'APRIL', '2005', ' XI AKL 1'),
(25, 20420, 'Sarwedi Datunsolang', 'BAKAN', '19', 'SEPTEMBER', '2005', ' XI AKL 1'),
(26, 20425, 'Siti Amelia Mokoagow', 'POBUNDAYAN', '17', 'SEPTEMBER', '2005', ' XI AKL 1'),
(27, 20431, 'SRI UTAMI POTABUGA', 'Kotamobagu', '28', 'MARET', '2004', ' XI AKL 1'),
(28, 20436, 'Tasya Modeong', 'Idumun', '26', 'MARET', '2005', ' XI AKL 1'),
(29, 20441, 'Vanesa virtita toha', 'POYUYANAN', '20', 'MEI', '2005', ' XI AKL 1'),
(30, 20446, 'Vini Almi Ashila Toligaga', 'KOPANDAKAN', '6', 'FEBRUARI', '2005', ' XI AKL 1'),
(31, 20451, 'YUNDARI MUNGGOL', 'Mongondow', '11', 'JANUARI', '2005', ' XI AKL 1'),
(32, 20304, 'Adelia Olii', 'Pobundayan', '12', 'MEI', '2005', ' XI AKL 2'),
(33, 20307, 'Ahmad Sondok', 'TUNGOI 1', '29', 'APRIL', '2005', ' XI AKL 2'),
(34, 20319, 'ARDIANSYAH MOLANTONG', 'Tungoi II', '4', 'MARET', '2005', ' XI AKL 2'),
(35, 20329, 'DEA INKA DATUNDUGON', 'Tungoi', '4', 'APRIL', '2004', ' XI AKL 2'),
(36, 20334, 'Elsa Putri Linu', 'Kopandakan I', '16', 'DESEMBER', '2004', ' XI AKL 2'),
(37, 20342, 'Febriansyah Bandahari', 'Matali', '8', 'FEBRUARI', '2006', ' XI AKL 2'),
(38, 20344, 'FELIGA ELLYYANTI UMBOLA', 'Bulud', '10', 'APRIL', '2006', ' XI AKL 2'),
(39, 20359, 'JULIYA OLII', 'GOGAGOMAN', '7', 'JULI', '2004', ' XI AKL 2'),
(40, 20364, 'Lela Aprilia Ampel', 'POYOWA KECIL', '12', 'APRIL', '2005', ' XI AKL 2'),
(41, 20369, 'Martesya Sumendap', 'Kotobangun', '19', 'FEBRUARI', '2005', ' XI AKL 2'),
(42, 20370, 'MEYLANI DOMU ', 'KOTAMOBAGU', '16', 'MEI ', '2005', ' XI AKL 2'),
(43, 20375, 'MONALISA', 'Mogolaing', '11', 'JULI', '2004', ' XI AKL 2'),
(44, 20380, 'MUTIARA MOKOGINTA', 'Kotamobagu', '18', 'MARET', '2006', ' XI AKL 2'),
(45, 20385, 'Nahdana Aulia Mamonto', 'Mongkonai', '21', 'DESEMBER', '2005', ' XI AKL 2'),
(46, 20390, 'NAYA WULAN ANANDA ILAM', 'Mopait', '7', 'MARET', '2005', ' XI AKL 2'),
(47, 20395, 'Nica Nurcaya Mokodompit', 'TANOYAN', '28', 'FEBRUARI', '2005', ' XI AKL 2'),
(48, 20401, 'OLIVIA PUTRI APANDE', 'KOTAMOBAGU', '19', 'JUNI', '2005', ' XI AKL 2'),
(49, 20406, 'Putri Alyssya Mokodompit', 'Kotamobagu', '29', 'APRIL', '2005', ' XI AKL 2'),
(50, 20411, 'REGINA PUTRI MASLOMAN', 'Manado', '13', 'JUNI', '2005', ' XI AKL 2'),
(51, 20416, 'ROFKA MALE', 'KOTAMOBAGU', '16', 'JULI', '2006', ' XI AKL 2'),
(52, 20421, 'Sesilia Mamonto', 'Idumun', '2', 'SEPTEMBER', '2005', ' XI AKL 2'),
(53, 20424, 'SITA SENGGIGILANG', 'Pindol', '9', 'NOVEMBER', '2004', ' XI AKL 2'),
(54, 20426, 'Siti Destari Lii', 'Poyowa Besar', '7', 'DESEMBER', '2005', ' XI AKL 2'),
(55, 20430, 'SONIA FLORENCITHA MANDEY', 'MOGOLAING', '14', 'OKTOBER', '2005', ' XI AKL 2'),
(56, 20437, 'Tilawati Paputungan', 'POBUNDAYAN', '25', 'DESEMBER', '2004', ' XI AKL 2'),
(57, 20442, 'Verizkha Febrianty Laiya', 'Bulud', '22', 'MARET', '2006', ' XI AKL 2'),
(58, 20447, 'VIRNA BILATULA', 'Siniung', '19', 'JANUARI', '2005', ' XI AKL 2'),
(59, 20452, 'Yunita Aulia Tongkasi', 'KOTAMOBAGU', '14', 'JUNI', '2005', ' XI AKL 2'),
(60, 20305, 'Aditio Saputra Ondoling', 'KOPANDAKAN II', '25', 'MEI', '2005', ' XI AKL 3'),
(61, 20310, 'alifa safitri mashanafi', 'Ikhwan', '30', 'AGUSTUS', '2005', ' XI AKL 3'),
(62, 20315, 'ANDIKA REVALDI PAPUTUNGAN', 'Mongkonai Barat', '1', 'AGUSTUS', '2005', ' XI AKL 3'),
(63, 20320, 'ARGA HERDIANSYAH LAODE', 'MATALI', '16', 'DESEMBER', '2002', ' XI AKL 3'),
(64, 20325, 'Cahyani Natasya Paputungan', 'Poyowa Kecil', '15', 'APRIL', '2006', ' XI AKL 3'),
(65, 20335, 'Ergia Safitri Lambe', 'Kotamobagu', '17', 'SEPTEMBER', '2005', ' XI AKL 3'),
(66, 20340, 'Fatriyah Damopolii', 'Pobundayan', '23', 'NOVEMBER', '2005', ' XI AKL 3'),
(67, 20345, 'Fidi Bulow', 'Kotamobagu', '10', 'NOVEMBER', '2005', ' XI AKL 3'),
(68, 20349, 'HELSINDA PAPUTUNGAN', 'MOPUSI', '5', 'MEI', '2005', ' XI AKL 3'),
(69, 20354, 'Jelsika Audia Paputungan', 'TANOYAN', '16', 'AGUSTUS', '2005', ' XI AKL 3'),
(70, 20357, 'JOVITA SARI LAMBAIANG', 'Mogolaing', '9', 'JANUARI', '2005', ' XI AKL 3'),
(71, 20360, 'Juwita Pricilia Potabuga', 'IMANDI', '10', 'JUNI', '2005', ' XI AKL 3'),
(72, 20365, 'Livia Putri Passi', 'KOPANDAKAN 1', '3', 'MEI', '2005', ' XI AKL 3'),
(73, 20371, 'Miranda Makalalag', 'MONGONDOW', '9', 'NOVEMBER', '2004', ' XI AKL 3'),
(74, 20376, 'MUHAMAD NUR PAUZAN GUMALANGIT', 'MATALI', '20', 'DESEMBER', '2005', ' XI AKL 3'),
(75, 20381, 'Nabil Firmansya Bonde', 'Motoboi Kecil', '16', 'DESEMBER', '2005', ' XI AKL 3'),
(76, 20386, 'Najlah Fakhirah Mokoginta', 'KOPANDAKAN 1', '24', 'JUNI', '2005', ' XI AKL 3'),
(77, 20391, 'Nayla Letisia Mamonto', 'Kotamobagu', '2', 'JULI', '2005', ' XI AKL 3'),
(78, 20402, 'ORINTESA SROYER', 'Kotamobagu', '12', 'MARET', '2005', ' XI AKL 3'),
(79, 20407, 'Rafliansyah potabuga', 'MONGKONAI', '24', 'DESEMBER', '2005', ' XI AKL 3'),
(80, 20412, 'Regita Potabuga', 'MONGKONAI', '3', 'JUNI', '2005', ' XI AKL 3'),
(81, 20417, 'SALSA NABILA BAKS', 'KOTAMOBAGU', '18', 'AGUSTUS', '2005', ' XI AKL 3'),
(82, 20422, 'SHERLY SRI MAHARANI', 'PANGKAJENE', '3', 'DESEMBER', '2004', ' XI AKL 3'),
(83, 20428, 'SITTI NABILLAH', 'Molinow', '8', 'JULI', '2005', ' XI AKL 3'),
(84, 20433, 'Suci Meysica Palakum', 'Motoboi Kecil', '28', 'MEI', '2005', ' XI AKL 3'),
(85, 20438, 'Tri Aulia Putri Montol', 'Nuangan', '30', 'JULI', '2005', ' XI AKL 3'),
(86, 20443, 'Victor Wongkar', 'Mariri Lama', '10', 'OKTOBER', '2004', ' XI AKL 3'),
(87, 20448, 'VISI YULISTI MANANGIN', 'Mopait', '17', 'OKTOBER', '2003', ' XI AKL 3'),
(88, 20453, 'YUNITA JAISAN', 'Siniyung', '26', 'JUNI', '2004', ' XI AKL 3'),
(89, 20306, 'Agusri Ahiya', 'POYOWA BESAR I', '30', 'AGUSTUS', '2005', ' XI AKL 4'),
(90, 20311, 'ALIFA SALSABILLAH DAUD', 'MOGOLAING', '28', 'DESEMBER', '2005', ' XI AKL 4'),
(91, 20316, 'Anggio Tambun', 'MARIRI LAMA', '15', 'AGUSTUS', '2004', ' XI AKL 4'),
(92, 20321, 'Aulia Kurniati Detu', 'TANOYAN UTARA', '18', 'FEBRUARI', '2005', ' XI AKL 4'),
(93, 20326, 'CITA ALISIA KARTINI TABIMAN', 'Lolayan', '21', 'APRIL', '2005', ' XI AKL 4'),
(94, 20331, 'Dwi Renita Mokodompit', 'BAKAN', '14', 'DESEMBER', '2004', ' XI AKL 4'),
(95, 20336, 'Esti Dilapanga', 'BAI', '15', 'MARET', '2005', ' XI AKL 4'),
(96, 20341, 'FAUZAN MONOARFA', 'KOTAMOBAGU', '29', 'OKTOBER', '2005', ' XI AKL 4'),
(97, 20346, 'Fitri Nayla Mokolintad', 'Kopandakan 1', '19', 'NOVEMBER', '2004', ' XI AKL 4'),
(98, 20350, 'INDI ANGGRAINI LAPIAN', 'Toraut', '15', 'SEPTEMBER', '2005', ' XI AKL 4'),
(99, 20355, 'Jesika Anatasya Dibo', 'KOTAMOBAGU', '19', 'APRIL', '2005', ' XI AKL 4'),
(100, 20361, 'Karla Balansa', 'Kotamobagu', '15', 'DESEMBER', '2004', ' XI AKL 4'),
(101, 20366, 'Lutfiah Mokodongan', 'MUNTOI', '27', 'FEBRUARI', '2005', ' XI AKL 4'),
(102, 20372, 'Mirna Ekawati Kawulusan', 'Kotamobagu', '12', 'MEI', '2004', ' XI AKL 4'),
(103, 20377, 'Muhammad Musli Saputra Paputungan', 'KOPANDAKAN', '15', 'AGUSTUS', '2005', ' XI AKL 4'),
(104, 20382, 'Nabila Anastasya Elly', 'Kotamobagu', '21', 'AGUSTUS', '2005', ' XI AKL 4'),
(105, 20387, 'Nanggita Putri Mokoginta', 'MOGOLAING', '24', 'NOVEMBER', '2005', ' XI AKL 4'),
(106, 20392, 'NAZWA CANON', 'KOTOBANGON', '10', 'DESEMBER', '2006', ' XI AKL 4'),
(107, 20397, 'Ninda Dinata Mokodongan', 'KOTAMOBAGU', '13', 'JUNI', '2005', ' XI AKL 4'),
(108, 20403, 'POPPI PUTRI PAPENE', 'KONAROM', '3', 'JULI', '2005', ' XI AKL 4'),
(109, 20408, 'Rahmah Wati Aminullah', 'GOGAGOMAN', '1', 'MEI', '2005', ' XI AKL 4'),
(110, 20413, 'REGITA SALEH', 'Gogagoman', '29', 'OKTOBER', '2005', ' XI AKL 4'),
(111, 20418, 'SALSABILA HANATASYAH MALETENG', 'Molinow', '13', 'MEI', '2005', ' XI AKL 4'),
(112, 20423, 'Siska Ibrahim', 'Pontodon', '5', 'JULI', '2005', ' XI AKL 4'),
(113, 20429, 'SITTI SHARA SIMBALA', 'MOLINOW', '20', 'MEI', '2005', ' XI AKL 4'),
(114, 20434, 'Sukma Mamonto', 'Buyandi', '3', 'AGUSTUS', '2004', ' XI AKL 4'),
(115, 20439, 'Tri Sucita Agantu', 'Kopandakan I', '27', 'DESEMBER', '2005', ' XI AKL 4'),
(116, 20444, 'Vina Taria', 'BELANTI', '18', 'JUNI', '2006', ' XI AKL 4'),
(117, 20449, 'Vitta Magfirah Kaunang', 'Matali', '18', 'NOVEMBER', '2005', ' XI AKL 4'),
(118, 20454, 'Zain Rahmat Makalalag', 'TORUAKAT', '7', 'NOVEMBER', '2004', ' XI AKL 4'),
(119, 20309, 'ALIA AHMAD', 'Kotamobagu', '3', 'JANUARI', '2005', ' XI AKL 5'),
(120, 20312, 'ANA NURIYANA ADJIDJI', 'GOGAGOMAN', '2', 'MARET', '2005', ' XI AKL 5'),
(121, 20317, 'ANNISA SUKMA BELENEHU', 'MUNTOI', '9', 'JANUARI', '2006', ' XI AKL 5'),
(122, 20322, 'AYU ASTUTI PAPUTUNGAN', 'POBUNDAYAN', '13', 'MEI', '2003', ' XI AKL 5'),
(123, 20324, 'Cahya Nifa Mokodompit', 'KOTAMOBAGU', '28', 'JULI', '2005', ' XI AKL 5'),
(124, 20327, 'CLARA APRILIA LOMOTU', 'Gorontalo', '14', 'AGUSTUS', '2004', ' XI AKL 5'),
(125, 20330, 'Dina Safira Simbala', 'MATALI', '29', 'SEPTEMBER', '2004', ' XI AKL 5'),
(126, 20332, 'Dwiyan Arsito Lumintang', 'KOPANDAKAN', '21', 'DESEMBER', '2004', ' XI AKL 5'),
(127, 20337, 'FADILAH LAHABI', 'KOTAMOBAGU', '1', 'JULI', '2005', ' XI AKL 5'),
(128, 20339, 'Fatiah Daeng Pontoh', 'MOTOBOI BESAR', '20', 'MARET', '2005', ' XI AKL 5'),
(129, 20351, 'Indi Febrianingsi Manggo', 'MOTOBOI KECIL', '2', 'FEBRUARI', '2006', ' XI AKL 5'),
(130, 20356, 'JEYDI ZAKARDI', 'TAPA AOG', '14', 'SEPTEMBER', '2004', ' XI AKL 5'),
(131, 20362, 'Keni Aksal Yasin', 'TOROSIK', '11', 'APRIL', '2005', ' XI AKL 5'),
(132, 20367, 'Luthfia Maura Humu', 'Kopandakan 1', '8', 'NOVEMBER', '2005', ' XI AKL 5'),
(133, 20378, 'Mutia Bumulo', 'Idumun', '5', 'AGUSTUS', '2005', ' XI AKL 5'),
(134, 20383, 'NABILA SALSABILAH SIMBALA', 'KOTAMOBAGU', '16', 'JANUARI', '2006', ' XI AKL 5'),
(135, 20388, 'NATASYA MOKOAGOW', 'Pangi', '5', 'AGUSTUS', '2004', ' XI AKL 5'),
(136, 20393, 'NENI EVRIANA', 'GOGAGOMAN', '30', 'JULI', '2004', ' XI AKL 5'),
(137, 20399, 'NURAINI MAMONTO', 'MOTOBOI KECIL', '12', 'FEBRUARI', '2005', ' XI AKL 5'),
(138, 20404, 'PRAISI ERIKA BALANSA', 'TUNGOI I', '18', 'APRIL', '2005', ' XI AKL 5'),
(139, 20409, 'Rahmat Cendeni Olola', 'Motoboi Kecil', '17', 'MEI', '2005', ' XI AKL 5'),
(140, 20414, 'REZKI ILHAMZAH PURNOMO', 'Kotamobagu', '2', 'MARET', '2005', ' XI AKL 5'),
(141, 20419, 'SANDI SEPTIAN PRATAMA', 'BREBES', '12', 'MEI', '2005', ' XI AKL 5'),
(142, 20427, 'SITI WINDARI PUTRI CAHYANI PERMATASARI', 'SURABAYA ', '27', 'DESEMBER', '2005', ' XI AKL 5'),
(143, 20432, 'Suci Indah Sari Makalalag', 'Kotamobagu', '9', 'APRIL', '2005', ' XI AKL 5'),
(144, 20435, 'SYANTIYA DAMO', 'KOPANDAKAN', '6', 'JUNI', '2005', ' XI AKL 5'),
(145, 20440, 'TRIA RAMADHANI PAPUTUNGAN', 'Inobonto I', '28', 'OKTOBER', '2004', ' XI AKL 5'),
(146, 20445, 'Vini Aflionita Mamonto', 'Moyongkota', '19', 'AGUSTUS', '2005', ' XI AKL 5'),
(147, 20450, 'Yolanda Mamonto', 'BULUD', '11', 'APRIL', '2005', ' XI AKL 5'),
(148, 20494, 'NAJWA FADILA AULIA MOKODOMPIT', 'GOGAGOMAN', '11', 'MEI', '2005', 'XI ASKEP 1'),
(149, 20845, 'ADELANI TATA DILIKA MAMONTO', 'KOTOBANGON', '12', 'APRIL', '2006', 'XI ASKEP 1'),
(150, 20851, 'Alya Salsabila Mamonto', 'Ayong', '7', 'MARET', '2005', 'XI ASKEP 1'),
(151, 20854, 'AQILAH FACHREZI PAPUTUNGAN', 'Motoboi Kecil', '1', 'OKTOBER', '2006', 'XI ASKEP 1'),
(152, 20857, 'AVITRA AFFANDI BONDE', 'KOTAMOBAGU', '24', 'APRIL', '2006', 'XI ASKEP 1'),
(153, 20860, 'Bulan Wahyudia Mokodongan', 'SOLIMANDUNGAN II', '28', 'SEPTEMBER', '2005', 'XI ASKEP 1'),
(154, 20863, 'Citra Purnama Mamonto', 'Lolayan', '18', 'SEPTEMBER', '2005', 'XI ASKEP 1'),
(155, 20866, 'Dwie Adelia Mamonto', 'POBUNDAYAN', '9', 'DESEMBER', '2005', 'XI ASKEP 1'),
(156, 20870, 'Fatur Rahman Labadjuana', 'Manado', '4', 'APRIL', '2006', 'XI ASKEP 1'),
(157, 20873, 'HEIN STEVANI WAANI', 'Kombot', '15', 'APRIL', '2005', 'XI ASKEP 1'),
(158, 20876, 'Hikmawati Makadomo', 'Kotamobagu', '21', 'JANUARI', '2006', 'XI ASKEP 1'),
(159, 20879, 'Indriyani Bahrul Bambang', 'UJUNG PANDANG', '15', 'NOVEMBER', '2005', 'XI ASKEP 1'),
(160, 20882, 'JULIA CITRA PAPUTUNGAN', 'Kotamobagu', '6', 'JULI', '2005', 'XI ASKEP 1'),
(161, 20885, 'LINDRI RASYA MAMUAYA', 'Kotobangon', '3', 'SEPTEMBER', '2005', 'XI ASKEP 1'),
(162, 20888, 'MAWADAH WAROHMA MOKODOMPIT', 'DOLODUO', '13', 'NOVEMBER', '2003', 'XI ASKEP 1'),
(163, 20890, 'MEYTISA DAMOPOLII', 'MONGKONAI', '28', 'MEI', '2005', 'XI ASKEP 1'),
(164, 20894, 'MOHAMMAD FAIZ ALFARIZY ISMAIL', 'Motoboi Kecil', '27', 'OKTOBER', '2005', 'XI ASKEP 1'),
(165, 20897, 'NABILA MUTIARA PADJA', 'GOGAGOMAN', '2', 'SEPTEMBER', '2005', 'XI ASKEP 1'),
(166, 20900, 'Nasya Fabillah Paputungan', 'MOTOBOI KECIL', '22', 'AGUSTUS', '2005', 'XI ASKEP 1'),
(167, 20903, 'NAYSILA SALSABILA TAYABU', 'GOGAGOMAN', '13', 'DESEMBER', '2005', 'XI ASKEP 1'),
(168, 20906, 'NURHIKMAWATI PIKOLI', 'Kotamobagu', '9', 'JUNI', '2005', 'XI ASKEP 1'),
(169, 20909, 'PRILY AZIZAH HUMU', 'Tungoi 1', '20', 'NOVEMBER', '2005', 'XI ASKEP 1'),
(170, 20912, 'PUTRI TIARA PONTOH', 'KOTAMOBAGU', '3', 'MARET', '2005', 'XI ASKEP 1'),
(171, 20915, 'Regian Simbala', 'POYOWA BESAR 2', '24', 'JANUARI', '2006', 'XI ASKEP 1'),
(172, 20918, 'RIANTY IDRIS', 'KOTAMOBAGU', '24', 'JULI', '2005', 'XI ASKEP 1'),
(173, 20921, 'Siti Aiva Onu', 'KOTAMOBAGU', '5', 'MARET', '2005', 'XI ASKEP 1'),
(174, 20924, 'SITTI KHORIFA ANWAR', 'MONGONDOW', '20', 'MARET', '2006', 'XI ASKEP 1'),
(175, 20927, 'Sumira Ginoga', 'SOLIMANDUNGAN I', '27', 'SEPTEMBER', '2005', 'XI ASKEP 1'),
(176, 20930, 'Trinilia Tasya Paputungan', 'Pusian', '21', 'MARET', '2005', 'XI ASKEP 1'),
(177, 20933, 'Vhaldo Ridho Firmansyah Surentu', 'KOPANDAKAN', '13', 'OKTOBER', '2004', 'XI ASKEP 1'),
(178, 20936, 'WULANDARI MAMONTO', 'Kobo Kecil', '8', 'FEBRUARI', '2005', 'XI ASKEP 1'),
(179, 20846, 'Adelia Salsa Babo', 'MATALI', '24', 'AGUSTUS', '2006', 'XI ASKEP 2'),
(180, 20849, 'ALIN A. TONUKO', 'GORONTALO', '15', 'OKTOBER', '2004', 'XI ASKEP 2'),
(181, 20852, 'AMELIA SYAHRANI YUSUP', 'KOTAMOBAGU', '27', 'JUNI', '2005', 'XI ASKEP 2'),
(182, 20855, 'ARUM ANUGRA PIDARA', 'MANADO', '23', 'DESEMBER', '2005', 'XI ASKEP 2'),
(183, 20858, 'Azra Alqadri Pontoh', 'MATALI', '1', 'NOVEMBER', '2005', 'XI ASKEP 2'),
(184, 20861, 'Cheripurwati Mamonto', 'KOTAMOBAGU', '30', 'OKTOBER', '2005', 'XI ASKEP 2'),
(185, 20868, 'Fallerina Tanggulu', 'IBOLIAN', '20', 'DESEMBER', '2004', 'XI ASKEP 2'),
(186, 20871, 'Fidia Diva Lengkung', 'Kotamobagu', '28', 'OKTOBER', '2004', 'XI ASKEP 2'),
(187, 20874, 'Herawati Mokodongan', 'IBOLIAN', '9', 'JANUARI', '2005', 'XI ASKEP 2'),
(188, 20877, 'Ilham Mamonto', 'BAI', '12', 'MEI', '2004', 'XI ASKEP 2'),
(189, 20880, 'Jihan Nurmifta Muaya', 'KOTOBANGON', '13', 'SEPTEMBER', '2005', 'XI ASKEP 2'),
(190, 20883, 'Juwita Prastika Lumangkun', 'Komangaan', '11', 'JUNI', '2005', 'XI ASKEP 2'),
(191, 20886, 'MARSELINO BONDE', 'DUMOGA', '22', 'MARET', '2004', 'XI ASKEP 2'),
(192, 20889, 'Meygi Wowiling', 'KOTAMOBAGU', '15', 'MEI', '2005', 'XI ASKEP 2'),
(193, 20892, 'MOH. FAHRI WALANGADI', 'KOTAMOBAGU', '5', 'JANUARI', '2006', 'XI ASKEP 2'),
(194, 20895, 'Muhammad Ricat Simbala', 'Poyowa Besar 2', '11', 'NOVEMBER', '2005', 'XI ASKEP 2'),
(195, 20898, 'NADIA AZ-ZAHRA PUTRI KAMU', 'SININDIAN', '7', 'APRIL', '2006', 'XI ASKEP 2'),
(196, 20901, 'Natasya Cindi A. Toloy', 'TANOYAN', '29', 'JANUARI', '2005', 'XI ASKEP 2'),
(197, 20904, 'NELPI YUNUS HAMID', 'KOTAMOBAGU', '6', 'JULI', '2004', 'XI ASKEP 2'),
(198, 20907, 'NURUL ASYARI ANASTASYA R', 'MOLINOW', '12', 'MEI', '2005', 'XI ASKEP 2'),
(199, 20910, 'PRISITA DITA LII', 'Kopandakan', '1', 'JULI', '2004', 'XI ASKEP 2'),
(200, 20913, 'Rahmania Jake', 'Tombolango', '31', 'OKTOBER', '2005', 'XI ASKEP 2'),
(201, 20916, 'Reva Agisty Hulukati', 'POYOWA KECIL', '15', 'MARET', '2005', 'XI ASKEP 2'),
(202, 20919, 'SEPTIANA GILALOM', 'POYOWA BESAR 1', '7', 'SEPTEMBER', '2005', 'XI ASKEP 2'),
(203, 20922, 'SITI NABILA MOKOGINTA', 'MOLINOW', '24', 'FEBRUARI', '2006', 'XI ASKEP 2'),
(204, 20928, 'Tarwia Pato', 'GOGAGOMAN', '11', 'JUNI', '2003', 'XI ASKEP 2'),
(205, 20931, 'Veranesya Mohune', 'Iyok', '14', 'AGUSTUS', '2005', 'XI ASKEP 2'),
(206, 20934, 'VINI VANESA VEREN MOMINTAN', 'Kotamobagu', '10', 'JUNI', '2005', 'XI ASKEP 2'),
(207, 20937, 'Yesa Ananda Putri Paputungan', 'TANOYAN SELATAN', '18', 'AGUSTUS', '2004', 'XI ASKEP 2'),
(208, 20847, 'ADINDA NASYILLA ROMPAH', 'KOTAMOBAGU', '9', 'SEPTEMBER', '2005', 'XI ASKEP 3'),
(209, 20850, 'Almas Azatil Ismah Baksh', 'KOTAMOBAGU', '6', 'MARET', '2006', 'XI ASKEP 3'),
(210, 20853, 'Annisa Huri', 'JAYAPURA', '18', 'NOVEMBER', '2005', 'XI ASKEP 3'),
(211, 20856, 'ASTRIBBY REVALINA LAURES', 'SINIUNG', '13', 'AGUSTUS', '2005', 'XI ASKEP 3'),
(212, 20859, 'BERBINA MOKOAGOW', 'DOLODUO', '10', 'APRIL', '2005', 'XI ASKEP 3'),
(213, 20862, 'CINTA LUTVIA PUTRI', 'MATALI ', '24', 'DESEMBER', '2006', 'XI ASKEP 3'),
(214, 20865, 'DWI AYU LESTARI MOKOAGOW', 'MATALI', '22', 'DESEMBER', '2005', 'XI ASKEP 3'),
(215, 20867, 'Enjelilka Datundugon', 'TUNGOI', '28', 'JUNI', '2004', 'XI ASKEP 3'),
(216, 20869, 'FATIMAH NURISILAH KOROMPOT', 'Kotamobagu', '7', 'AGUSTUS', '2005', 'XI ASKEP 3'),
(217, 20872, 'Friska Adelia Citra Mokoagow', 'Mataindo', '18', 'JUNI', '2004', 'XI ASKEP 3'),
(218, 20875, 'HESTIN LAGANI', 'Wonggarasi Timur', '23', 'DESEMBER', '2003', 'XI ASKEP 3'),
(219, 20878, 'INDIRA GANDHI', 'KOTAMOBAGU', '30', 'AGUSTUS', '2005', 'XI ASKEP 3'),
(220, 20881, 'Jingga Larasati Mondo', 'TANOYAN UTARA', '4', 'MARET', '2005', 'XI ASKEP 3'),
(221, 20884, 'Kurniawan Paputungan', 'KOTAMOBAGU', '29', 'JULI', '2005', 'XI ASKEP 3'),
(222, 20887, 'Marsya Papene', 'Pusian', '2', 'AGUSTUS', '2005', 'XI ASKEP 3'),
(223, 20893, 'Mohamad Mahfudin Mokoagow', 'TABANG', '5', 'MARET', '2005', 'XI ASKEP 3'),
(224, 20896, 'MUTIA NURAINI LINDAM', 'Gogagoman', '6', 'OKTOBER', '2004', 'XI ASKEP 3'),
(225, 20899, 'NADIA MAMONTO', 'Bakan', '2', 'MARET', '2005', 'XI ASKEP 3'),
(226, 20902, 'Natasya Claudia Iman', 'TANOYAN SELATAN', '8', 'JUNI', '2005', 'XI ASKEP 3'),
(227, 20905, 'NINDY ANASTASYA POBELA', 'TOROSIK', '15', 'MEI', '2005', 'XI ASKEP 3'),
(228, 20908, 'Olifia Bumulo', 'NUANGAN', '14', 'DESEMBER', '2005', 'XI ASKEP 3'),
(229, 20914, 'RAHUL WAANI', 'KOMBOT', '23', 'DESEMBER', '2002', 'XI ASKEP 3'),
(230, 20917, 'Revalina Mokoginta', 'Rusdin Mokoginta', '7', 'NOVEMBER', '2006', 'XI ASKEP 3'),
(231, 20920, 'SINTIA MOKODOMPIT', 'TABANG', '8', 'FEBRUARI', '2005', 'XI ASKEP 3'),
(232, 20923, 'Siti Nandya Dwi Mokodompit', 'KOTAMOBAGU', '18', 'JUNI', '2006', 'XI ASKEP 3'),
(233, 20926, 'SRY ANGGRAINI MOKODONGAN', 'MANADO', '5', 'AGUSTUS', '2005', 'XI ASKEP 3'),
(234, 20929, 'TESALONIKA KAAT', 'BUNGKO', '26', 'SEPTEMBER', '2005', 'XI ASKEP 3'),
(235, 20932, 'Vetra Christein Talungke', 'Dumoga', '8', 'DESEMBER', '2005', 'XI ASKEP 3'),
(236, 20935, 'VIVI ENDAWATI PUTRI KOLOPITA', 'KOTAMOBAGU', '13', 'DESEMBER', '2004', 'XI ASKEP 3'),
(237, 20938, 'Zara Azalia Tahir', 'Mongkonai', '5', 'DESEMBER', '2005', 'XI ASKEP 3'),
(238, 20618, 'A. NUR HIKMAH BADERAN', 'KOTOBANGON', '21', 'APRIL', '2005', 'XI MM 1'),
(239, 20622, 'AGRILIA MEIVITA KANDOLO', 'INOBONTO', '1', 'APRIL', '2005', 'XI MM 1'),
(240, 20626, 'AMANAH MAKALUNSENGE', 'KOTAMOBAGU', '6', 'MARET', '2005', 'XI MM 1'),
(241, 20630, 'Atmajaya Tri Saputra Apande', 'KOTAMOBAGU', '1', 'MARET', '2006', 'XI MM 1'),
(242, 20634, 'Canni Azahra Olii', 'Kopandakan II', '3', 'AGUSTUS', '2005', 'XI MM 1'),
(243, 20638, 'CHRISTABELLA SOPHIE KAENG', 'MANADO', '12', 'JANUARI', '2006', 'XI MM 1'),
(244, 20640, 'Damayanti Asiaw', 'Motoboi Kecil', '15', 'AGUSTUS', '2005', 'XI MM 1'),
(245, 20646, 'Elsaday Maharani Limbanadi', 'Pusian', '14', 'JUNI', '2005', 'XI MM 1'),
(246, 20650, 'Fadly Tampongangoy', 'DUMOGA', '17', 'FEBRUARI', '2005', 'XI MM 1'),
(247, 20654, 'Fajri Hakim', 'POBUNDAYAN', '27', 'AGUSTUS', '2004', 'XI MM 1'),
(248, 20658, 'FEBRAN FRIZZY GINOGA', 'OTAM', '15', 'FEBRUARI', '2005', 'XI MM 1'),
(249, 20662, 'Firman Dali Poga', 'GOGAGOMAN', '16', 'MARET', '2005', 'XI MM 1'),
(250, 20666, 'Gazalli Fatur Rahman Salote', 'Motoboi Besar', '16', 'AGUSTUS', '2005', 'XI MM 1'),
(251, 20671, 'Hardiansyah Lantong', 'Mongondow', '12', 'JUNI', '2006', 'XI MM 1'),
(252, 20675, 'Ince Mutiara Jamaludin', 'GOGAGOMAN', '1', 'FEBRUARI', '2005', 'XI MM 1'),
(253, 20679, 'Jerlina Siska Pobela', 'Inuai', '20', 'OKTOBER', '2005', 'XI MM 1'),
(254, 20683, 'KARLI BALANSA', 'KOTAMOBAGU', '4', 'JANUARI', '2003', 'XI MM 1'),
(255, 20687, 'KARTIKA MANGGOPA', 'MONGONDOW', '13', 'AGUSTUS', '2005', 'XI MM 1'),
(256, 20691, 'liana giu', 'Pobundayan', '19', 'DESEMBER', '2004', 'XI MM 1'),
(257, 20695, 'MOH. FAJRI POMALANGO', 'KOTAMOBAGU', '18', 'FEBRUARI', '2005', 'XI MM 1'),
(258, 20699, 'Moh. Ragil Ibrahim', 'KOTOBANGON', '10', 'JANUARI', '2006', 'XI MM 1'),
(259, 20703, 'Mohamad Ikram Paputungan', 'POBUNDAYAN', '23', 'JULI', '2005', 'XI MM 1'),
(260, 20707, 'MOHAMMAD RIDHO PAPUTUNGAN', 'MOGOLAING', '13', 'APRIL', '2004', 'XI MM 1'),
(261, 20711, 'Muhamad Algifari Tunggali', 'KOTAMOBAGU', '26', 'JUNI', '2006', 'XI MM 1'),
(262, 20715, 'NABILA SRI RAHAYU GONIBALA', 'Muntoi', '14', 'SEPTEMBER', '2005', 'XI MM 1'),
(263, 20719, 'NANDITO DILIVIO MOONIK', 'TUNGOI 1', '19', 'NOVEMBER', '2004', 'XI MM 1'),
(264, 20723, 'NOR FAZRI DAMOPOLII', 'Pobundayan', '7', 'FEBRUARI', '2005', 'XI MM 1'),
(265, 20727, 'Puja Wati Mokoagow', 'Matali', '1', 'FEBRUARI', '2005', 'XI MM 1'),
(266, 20731, 'QAFKA NICKY DAMOLAI', 'KOPANDAKAN I', '23', 'AGUSTUS', '2004', 'XI MM 1'),
(267, 20735, 'Razky Pratama Gonggalang', 'KOPANDAKAN', '6', 'JUNI', '2005', 'XI MM 1'),
(268, 20739, 'Ridho Frizee Ibrahim', 'Kotobangon', '26', 'OKTOBER', '2004', 'XI MM 1'),
(269, 20745, 'Riski Mokoagow', 'KOTAMOBAGU', '21', 'AGUSTUS', '2005', 'XI MM 1'),
(270, 20747, 'Rosdiana Bangki', 'POYOWA KECIL', '15', 'JUNI', '2005', 'XI MM 1'),
(271, 20751, 'SUTINA TUNGGALI', 'MONGONDOW', '19', 'SEPTEMBER', '2005', 'XI MM 1'),
(272, 20756, 'Wisnu Saputra Londa', 'Kobo Besar', '1', 'MEI', '2005', 'XI MM 1'),
(273, 20760, 'ZIBBY T MOKODONGAN', 'KOTAMOBAGU', '1', 'JUNI', '2004', 'XI MM 1'),
(274, 20619, 'Aditia Parijo', 'Poyowa Kecil', '13', 'FEBRUARI', '2005', 'XI MM 2'),
(275, 20623, 'AISYAH DAMOPOLII', 'Motandoi', '25', 'AGUSTUS', '2005', 'XI MM 2'),
(276, 20627, 'Ananda Putri Zanista Gonibala', 'Sonuo', '3', 'JANUARI', '2006', 'XI MM 2'),
(277, 20631, 'Beny Gunadi Djumaat', 'Motoboi Kecil', '3', 'SEPTEMBER', '2005', 'XI MM 2'),
(278, 20635, 'CECEN PRATAMA DUGIAN', 'POYOWA KECIL', '3', 'DESEMBER', '2005', 'XI MM 2'),
(279, 20639, 'Citra Yuliana Daun', 'POYOWA KECIL', '1', 'JULI', '2005', 'XI MM 2'),
(280, 20643, 'Diva Makalalag', 'KOTAMOBAGU', '3', 'FEBRUARI', '2005', 'XI MM 2'),
(281, 20644, 'Donna safitri Bandahari', 'Motoboi Kecil', '17', 'AGUSTUS', '2005', 'XI MM 2'),
(282, 20647, 'Elsha Devika Mokodongan', 'TAPA AOG', '10', 'JUNI', '2005', 'XI MM 2'),
(283, 20651, 'Fahrezi Paputungan', 'Poyowa Kecil', '30', 'JULI', '2005', 'XI MM 2'),
(284, 20655, 'FARIDA MOKOGINTA', 'Muntoi', '13', 'NOVEMBER', '2005', 'XI MM 2'),
(285, 20659, 'Fernando Umbola', 'Poyowa Kecil', '2', 'DESEMBER', '2004', 'XI MM 2'),
(286, 20667, 'GIANDRI BOYOD', 'MOPAIT', '18', 'OKTOBER', '2003', 'XI MM 2'),
(287, 20672, 'Herliyana Tubuon', 'Kopandakan II', '14', 'MEI', '2005', 'XI MM 2'),
(288, 20676, 'IRENE TRIVENA LALUYAN', 'POYOWA KECIL', '18', 'APRIL', '2006', 'XI MM 2'),
(289, 20684, 'Karmawan Rompis', 'Dayow', '14', 'DESEMBER', '2003', 'XI MM 2'),
(290, 20688, 'KHOLIL ABDULHALIM', 'POYOWA KECIL', '15', 'NOVEMBER', '2005', 'XI MM 2'),
(291, 20692, 'MARLINA AHMAD', 'KOTAMOBAGU', '21', 'MARET', '2006', 'XI MM 2'),
(292, 20696, 'Moh. Fatur Rahman Cardin', 'LEMBAH SUMARA KAB. MOROWALI', '11', 'MEI', '2006', 'XI MM 2'),
(293, 20700, 'Mohamad Alfayen Ondoling', 'KOTAMOBAGU', '5', 'APRIL', '2005', 'XI MM 2'),
(294, 20704, 'MOHAMAD RIDHO MONOARFA', 'Mogolaing', '13', 'JANUARI', '2006', 'XI MM 2'),
(295, 20708, 'MUH TAUFIQ RADJAB', 'MAKASSAR', '25', 'APRIL', '2004', 'XI MM 2'),
(296, 20712, 'MUHAMAD RAFLI MOKODOMPIT', 'Gogagoman', '27', 'SEPTEMBER', '2004', 'XI MM 2'),
(297, 20716, 'Nabila Syakila Abug', 'Motoboi Besar', '5', 'MEI', '2004', 'XI MM 2'),
(298, 20728, 'Putra Pratama Djenaan', 'POYOWA KECIL', '1', 'APRIL', '2005', 'XI MM 2'),
(299, 20732, 'RADITH ARDIANSYAH TANIB', 'KOPANDAKAN I', '21', 'JANUARI', '2006', 'XI MM 2'),
(300, 20734, 'Rahmat Susilo Sugeha', 'POBUNDAYAN', '10', 'APRIL', '2005', 'XI MM 2'),
(301, 20736, 'Rendi Praseteo', 'MONGONDOW', '5', 'OKTOBER', '2005', 'XI MM 2'),
(302, 20740, 'RIDO ALFAREZAL MOKODONGAN', 'GOGAGOMAN', '14', 'MEI', '2005', 'XI MM 2'),
(303, 20742, 'RILLY WALANGADI', 'MONGONDOW', '27', 'MARET', '2004', 'XI MM 2'),
(304, 20746, 'RIVAL ADRIAN DOTULUNG', 'Gorontalo', '18', 'AGUSTUS', '2005', 'XI MM 2'),
(305, 20752, 'TEGU ARDRIANSA MUTU', 'MOTOBOI BESAR', '26', 'DESEMBER', '2005', 'XI MM 2'),
(306, 20753, 'Tristan Hardinata Maleteng', 'Matali', '8', 'DESEMBER', '2004', 'XI MM 2'),
(307, 20757, 'YANA YONAS', 'KOTAMOBAGU', '6', 'MARET', '2005', 'XI MM 2'),
(308, 20759, 'ZAYYAN IZZAH ALFLIANSYAH', 'Kotamobagu', '28', 'JUNI', '2005', 'XI MM 2'),
(309, 20620, 'Adriansyah Mokodompit', 'TABANG', '29', 'DESEMBER', '2005', 'XI MM 3'),
(310, 20624, 'Alfajri Firmansyah Mokolintad', 'KOPANDAKAN I', '14', 'DESEMBER', '2004', 'XI MM 3'),
(311, 20628, 'AREL SYAHWIN MOPOBELA', 'Kotamobagu', '31', 'OKTOBER', '2005', 'XI MM 3'),
(312, 20632, 'CAHYA NAFISA PARANSI', 'Tanoyan', '16', 'MARET', '2005', 'XI MM 3'),
(313, 20636, 'CHECNYA ARAFFA DAMOPOLII', 'Kotamobagu', '2', 'APRIL', '2005', 'XI MM 3'),
(314, 20642, 'Dista Paputungan', 'Motoboi Kecil', '7', 'MARET', '2005', 'XI MM 3'),
(315, 20649, 'Fadila Aprilia Hamenda', 'KOTAMOBAGU', '24', 'APRIL', '2005', 'XI MM 3'),
(316, 20652, 'Fahril Alghiffari Djaman', 'KOTAMOBAGU', '20', 'APRIL', '2006', 'XI MM 3'),
(317, 20656, 'Fatmawati Baat', 'LOLAN', '30', 'APRIL', '2005', 'XI MM 3'),
(318, 20660, 'FIKRI FARHAN POTABUGA', 'WANGA', '19', 'NOVEMBER', '2005', 'XI MM 3'),
(319, 20663, 'Firna Argiyenda Paputungan', 'Motoboi Kecil', '8', 'MEI', '2005', 'XI MM 3'),
(320, 20664, 'GALANG PUTRA WIDJAYA MOKODONGAN', 'Kotamobagu', '8', 'MEI', '2006', 'XI MM 3'),
(321, 20668, 'GIOVVANI TOWOLIU', 'KOTAMOBAGU', '4', 'MEI', '2005', 'XI MM 3'),
(322, 20673, 'IHSAN LASABUDA', 'POBUNDAYAN', '29', 'NOVEMBER', '2004', 'XI MM 3'),
(323, 20677, 'Irsat Ganggai', 'Motoboi Besar', '4', 'MARET', '2004', 'XI MM 3'),
(324, 20681, 'JONATHAN HENDRIK KUMENDONG', 'Kotamobagu', '22', 'MEI', '2005', 'XI MM 3'),
(325, 20685, 'KARTIKA BUNTUAN', 'MOPUSI', '30', 'JUNI', '2005', 'XI MM 3'),
(326, 20689, 'KIANJIE THALIB', 'KOPANDAKAN I', '16', 'JULI', '2005', 'XI MM 3'),
(327, 20693, 'Moh. Alfa Rezal Detu', 'Kotamobagu', '18', 'NOVEMBER', '2005', 'XI MM 3'),
(328, 20697, 'MOH. NABIL SAPUTRA HARUN', 'KOTAMOBAGU', '19', 'JANUARI', '2006', 'XI MM 3'),
(329, 20701, 'MOHAMAD ARYO LAIYA', 'Gorontalo', '10', 'DESEMBER', '2004', 'XI MM 3'),
(330, 20705, 'MOHAMMAD ALDAN FAKHRIZAN MAKALALAG', 'Pobundayan', '29', 'JANUARI', '2005', 'XI MM 3'),
(331, 20709, 'MUH. BAGAS DWIPUTRA SABUNGE', 'Kotamobagu', '22', 'APRIL', '2006', 'XI MM 3'),
(332, 20713, 'MUHAMMAD NABIL MANGGO', 'MONGKONAI', '6', 'FEBRUARI', '2006', 'XI MM 3'),
(333, 20717, 'NAFISA FEBRIANTI ALIM', 'Kotamobagu', '21', 'FEBRUARI', '2006', 'XI MM 3'),
(334, 20721, 'NAZLA ZUBAIDA TURANG', 'KOTAMOBAGU', '6', 'OKTOBER', '2005', 'XI MM 3'),
(335, 20725, 'OKTA RAMADHANI M. KOBANDAHA', 'TUNGOI', '22', 'OKTOBER', '2005', 'XI MM 3'),
(336, 20729, 'Putri Nazmi Mokodompit', 'PASSI', '12', 'OKTOBER', '2005', 'XI MM 3'),
(337, 20733, 'Rahmat Persali Pasi', 'MOTOBOI KECIL', '28', 'FEBRUARI', '2006', 'XI MM 3'),
(338, 20737, 'Reska Mokoagow', 'KOTAMOBAGU', '21', 'AGUSTUS', '2005', 'XI MM 3'),
(339, 20741, 'Rifki Albuhori', 'BEKASI', '2', 'MEI', '2005', 'XI MM 3'),
(340, 20743, 'Ririn Angraini Paputungan', 'MATALI', '14', 'DESEMBER', '2003', 'XI MM 3'),
(341, 20749, 'Srininka Tulong', 'POYOWA KECIL', '17', 'JULI', '2005', 'XI MM 3'),
(342, 20754, 'Vanessa Ringkuangan', 'Inuai', '7', 'MARET', '2005', 'XI MM 3'),
(343, 20758, 'Yella Marizka Ololah', 'MATALI', '2', 'AGUSTUS', '2005', 'XI MM 3'),
(344, 20621, 'Agim Mokolintad', 'Kopandakan I', '16', 'FEBRUARI', '2005', 'XI MM 4'),
(345, 20625, 'Alfarizi Anda', 'KOTAMOBAGU', '4', 'JULI', '2005', 'XI MM 4'),
(346, 20629, 'ASWAR POTABUGA', 'WANGGA', '1', 'JUNI', '2005', 'XI MM 4'),
(347, 20633, 'CANDRA BUYA HERMAWAN', 'MOGOLAING', '22', 'JULI', '2003', 'XI MM 4'),
(348, 20637, 'CHEPY PASYA RABBANY AKUB', 'KOTAMOBAGU', '17', 'MEI', '2006', 'XI MM 4'),
(349, 20641, 'DIO PUTRA PRATAMA KOLOPITA', 'POBUNDAYAN', '23', 'FEBRUARI', '2005', 'XI MM 4'),
(350, 20645, 'DWI JAYANTO ANDUP', 'KOTAMOBAGU', '1', 'DESEMBER', '2004', 'XI MM 4'),
(351, 20648, 'Endang Sri Wahyuni Muntahir', 'MOLINOW', '18', 'MARET', '2005', 'XI MM 4'),
(352, 20653, 'FAHRU ROZY LENSUN', 'Poyowa Kecil', '17', 'JULI', '2005', 'XI MM 4'),
(353, 20657, 'Fauziyyah Ponamon', 'Poyowa Kecil', '15', 'FEBRUARI', '2005', 'XI MM 4'),
(354, 20661, 'Firgi Paresgi Lamuhu', 'Motoboi Kecil', '18', 'FEBRUARI', '2005', 'XI MM 4'),
(355, 20665, 'GATTAN FAIRYANSYAH MANOPPO', 'KOTOBANGON', '28', 'MEI', '2005', 'XI MM 4'),
(356, 20669, 'GLEND PUTRA PRATAMA SAMBUAGA', 'KOTAMOBAGU', '19', 'APRIL', '2005', 'XI MM 4'),
(357, 20670, 'GREYFANCA GHERAL H. ASSI', 'KOTAMOBAGU', '18', 'JANUARI', '2005', 'XI MM 4'),
(358, 20674, 'ILHAM GUNARSO', 'Bongkudai', '17', 'MEI', '2005', 'XI MM 4'),
(359, 20678, 'Jelita Asiking', 'POYOWA KECIL', '4', 'JULI', '2005', 'XI MM 4'),
(360, 20682, 'KAILLAH MAZAYAH MOKODONGAN', 'Genggulang', '14', 'AGUSTUS', '2005', 'XI MM 4'),
(361, 20686, 'Kartika Karim', 'MAKASSAR', '4', 'DESEMBER', '2004', 'XI MM 4'),
(362, 20690, 'Kurniawan Basuki', 'Poyowa Kecil', '11', 'OKTOBER', '2004', 'XI MM 4'),
(363, 20694, 'MOH. ARIL PAPUTUNGAN', 'KOTAMOBAGU', '29', 'SEPTEMBER', '2005', 'XI MM 4'),
(364, 20698, 'MOH. NADZMI AKBAR PONDAAG', 'KOTAMOBAGU', '27', 'JULI', '2005', 'XI MM 4'),
(365, 20702, 'MOHAMAD FAJRIL ANTU', 'GOGAGOMAN', '23', 'MEI', '2005', 'XI MM 4'),
(366, 20706, 'MOHAMMAD RAFLI HILOHAPA', 'KOTAMOBAGU', '11', 'SEPTEMBER', '2005', 'XI MM 4'),
(367, 20710, 'MUHAMAD AL-GHADAFI KOLOPITA', 'POBUNDAYAN', '3', 'FEBRUARI', '2005', 'XI MM 4'),
(368, 20714, 'MUHAMMAD RAFLI', 'Mogolaing', '28', 'NOVEMBER', '2005', 'XI MM 4'),
(369, 20718, 'NAISILA BUTU', 'TOMPASO BARU', '22', 'JULI', '2005', 'XI MM 4'),
(370, 20720, 'NAYLHA TIARA WUISAN', 'KOTAMOBAGU', '16', 'JANUARI', '2006', 'XI MM 4'),
(371, 20722, 'NICKSTEL JERMIAS ASSA', 'TUNGOI', '9', 'DESEMBER', '2005', 'XI MM 4'),
(372, 20724, 'Nur  Aini  Yuniarti Abdullah', 'Kotamobagu', '5', 'APRIL', '2005', 'XI MM 4'),
(373, 20726, 'Prilin Cicilia Toligaga', 'Kopandakan 2', '9', 'MARET', '2005', 'XI MM 4'),
(374, 20730, 'PUTRI RAJANEPA', 'Kopandakan 1', '25', 'OKTOBER', '2004', 'XI MM 4'),
(375, 20738, 'Revalina Damopolii', 'KOTAMOBAGU', '20', 'MARET', '2005', 'XI MM 4'),
(376, 20744, 'Ririn auliya mamangkai', 'Poyuyanan', '26', 'DESEMBER', '2004', 'XI MM 4'),
(377, 20748, 'SINTIA B. IGIRISA', 'GOGAGOMAN', '20', 'JUNI', '2005', 'XI MM 4'),
(378, 20750, 'STIVALDO IMMANUEL SEPANG', 'Poyowa Kecil', '12', 'OKTOBER', '2004', 'XI MM 4'),
(379, 20755, 'VIONA APRILIA PAPUTUNGAN', 'KOTAMOBAGU', '12', 'APRIL ', '2005', 'XI MM 4'),
(380, 20022, 'CANDRA DALI', 'POBUNDAYAN', '7', 'JUNI', '2004', 'XI MM 2'),
(381, 20524, 'ABD. RAHMAT ISMAIL', 'Kotamobagu', '27', 'OKTOBER', '2003', 'XI OTKP 1'),
(382, 20527, 'ALFARIZI MAMONTO', 'Poyowa Besar 1', '19', 'AGUSTUS', '2005', 'XI OTKP 1'),
(383, 20530, 'Ananda Kabonte', 'KOTAMOBAGU', '17', 'SEPTEMBER', '2005', 'XI OTKP 1'),
(384, 20533, 'ANTONI SUPAYO', 'Poyowa Kecil', '22', 'OKTOBER', '2002', 'XI OTKP 1'),
(385, 20536, 'AURELLY VANIA WALEWANGKO', 'Kotamobagu', '17', 'DESEMBER', '2005', 'XI OTKP 1'),
(386, 20539, 'CENNY JANUARTI PAPUTUNGAN', 'KOTAMOBAGU', '10', 'JANUARI', '2006', 'XI OTKP 1'),
(387, 20542, 'Desya Tongkad', 'POYOWA KECIL', '23', 'DESEMBER', '2004', 'XI OTKP 1'),
(388, 20545, 'Dwiagustina Iyeng Dandong', 'Kotamobagu', '12', 'AGUSTUS', '2005', 'XI OTKP 1'),
(389, 20548, 'FAHREZA AZAHRA MAKALALAG', 'GOGAGOMAN', '29', 'APRIL', '2005', 'XI OTKP 1'),
(390, 20551, 'FARAH NABILA MAHARANI LAKORO', 'KOTAMOBAGU', '12', 'NOVEMBER', '2005', 'XI OTKP 1'),
(391, 20554, 'Fidyah Ramadhani Mokoginta', 'MANADO', '29', 'SEPTEMBER', '2005', 'XI OTKP 1'),
(392, 20557, 'Girlanda Mokoginta', 'Motoboi Kecil', '28', 'NOVEMBER', '2006', 'XI OTKP 1'),
(393, 20560, 'Harianti Dewinta Mokoagow', 'MONGONDOW', '10', 'JULI', '2004', 'XI OTKP 1'),
(394, 20563, 'KANIA KHUMAIRAH LUN', 'MANADO', '31', 'MEI', '2006', 'XI OTKP 1'),
(395, 20566, 'Lilianti buntuan', 'MOTOBOI KECIL', '15', 'MARET', '2006', 'XI OTKP 1'),
(396, 20569, 'MEIGI ANANTA MAKALALAG', 'Kotamobagu', '8', 'MEI', '2005', 'XI OTKP 1'),
(397, 20572, 'Mohamat Rifki Mokodompit', 'KOTAMOBAGU', '29', 'JULI', '2005', 'XI OTKP 1'),
(398, 20574, 'MUH. FARHAN TRIWIDODO ABBAS', 'Kobo Besar', '5', 'JUNI', '2005', 'XI OTKP 1'),
(399, 20577, 'Nada Aulia Makalalag', 'Pobundayan', '21', 'SEPTEMBER', '2005', 'XI OTKP 1'),
(400, 20580, 'NATASYA REVALINA GAIB', 'KOTAMOBAGU', '16', 'JUNI', '2006', 'XI OTKP 1'),
(401, 20583, 'NESI ASTUTI ANDALE', 'TAPA AOG', '20', 'FEBRUARI', '2005', 'XI OTKP 1'),
(402, 20586, 'Nurpilda Makalalag', 'TAPA AOG', '21', 'MARET', '2006', 'XI OTKP 1'),
(403, 20589, 'PUJA RAMADANI SAFITRI TUNGGALI', 'GOGAGOMAN', '3', 'NOVEMBER', '2004', 'XI OTKP 1'),
(404, 20592, 'Razkia Nabila Putri Lasaka', 'Kotamobagu', '11', 'JULI', '2006', 'XI OTKP 1'),
(405, 20595, 'REVALINA ABANTO', 'Poyowa Besar 1', '18', 'MARET', '2006', 'XI OTKP 1'),
(406, 20598, 'RINI WAHYUNI MOKOAGOW', 'POYOWA BESAR I', '19', 'APRIL', '2005', 'XI OTKP 1'),
(407, 20604, 'Sri Wulandari Potabuga', 'Mongkonai', '25', 'JANUARI', '2005', 'XI OTKP 1'),
(408, 20607, 'SUCI ADELIA MAMONTO', 'POYOWA BESAR', '6', 'JANUARI', '2005', 'XI OTKP 1'),
(409, 20610, 'Witi Abanto', 'Kotamobagu', '17', 'NOVEMBER', '2005', 'XI OTKP 1'),
(410, 20613, 'YOLAN PAPENE', 'Poyowa Besar Satu', '8', 'SEPTEMBER', '2005', 'XI OTKP 1'),
(411, 20616, 'ZAHRANI DWI ANGGRAINI SURONOTO', 'POBUNDAYAN', '24', 'MARET', '2005', 'XI OTKP 1'),
(412, 20528, 'Alffel Saputra Mamonto', 'PUSIAN', '18', 'MEI', '2005', 'XI OTKP 2'),
(413, 20531, 'Anisa Hibo', 'POYOWA KECIL', '25', 'FEBRUARI', '2005', 'XI OTKP 2'),
(414, 20534, 'Aprilia Andup', 'Kotamobagu', '3', 'APRIL', '2006', 'XI OTKP 2'),
(415, 20537, 'Berlian Mokoagow', 'NUANGAN', '26', 'OKTOBER', '2005', 'XI OTKP 2'),
(416, 20540, 'Dea Triana Djumaat', 'MOTOBOI KECIL', '9', 'FEBRUARI', '2004', 'XI OTKP 2'),
(417, 20543, 'Dwi Friska Olola', 'Motoboi Kecil', '28', 'JANUARI', '2006', 'XI OTKP 2'),
(418, 20546, 'EIVIL NISKHA KOLOPITA', 'SINIYUNG', '6', 'JULI', '2005', 'XI OTKP 2'),
(419, 20549, 'Fahril Oga', 'KOPANDAKAN', '18', 'NOVEMBER', '2005', 'XI OTKP 2'),
(420, 20552, 'Febby Aulia Pitoy', 'KOPANDAKAN 1', '26', 'FEBRUARI', '2005', 'XI OTKP 2'),
(421, 20555, 'Fina Bonok', 'POYOWA KECIL', '8', 'NOVEMBER', '2004', 'XI OTKP 2'),
(422, 20558, 'GLADISTA PAPUTUNGAN', 'POYOWA BESAR', '3', 'JANUARI', '2006', 'XI OTKP 2'),
(423, 20561, 'Hendrawan Sulaeman', 'MONGKONAI', '5', 'JUNI', '2005', 'XI OTKP 2'),
(424, 20567, 'M.Cakra Ardiansyah Mokoginta', 'Kotamobagu', '6', 'MARET', '2006', 'XI OTKP 2'),
(425, 20573, 'Mohammad Iskandar Hatam', 'Motoboi Kecil', '18', 'DESEMBER', '2004', 'XI OTKP 2'),
(426, 20575, 'MUHAMMAD TIRTA WIJAYA MOKODOMPIT', 'GOGAGOMAN', '13', 'FEBRUARI', '2005', 'XI OTKP 2'),
(427, 20578, 'Nadia Aulia Abdul Halid', 'KOTAMOBAGU', '8', 'AGUSTUS', '2005', 'XI OTKP 2'),
(428, 20581, 'NAZAHRA FADILAH MOKODOMPIT', 'Kotamobagu', '25', 'DESEMBER', '2005', 'XI OTKP 2'),
(429, 20584, 'Nurani Mamonto', 'Pobundayan', '24', 'DESEMBER', '2005', 'XI OTKP 2'),
(430, 20587, 'Nurwilda Pokoba', 'BONAWANG', '25', 'JANUARI', '2005', 'XI OTKP 2'),
(431, 20590, 'Rani Panai', 'Matali', '29', 'JULI', '2004', 'XI OTKP 2'),
(432, 20593, 'Renaldi Tompig', 'KOBO BESAR', '5', 'OKTOBER', '2005', 'XI OTKP 2'),
(433, 20596, 'Rien Dontili', 'KOTAMOBAGU', '1', 'MEI', '2005', 'XI OTKP 2'),
(434, 20599, 'RIZKY RAHMAN MOKOAGOW', 'Poyowa Besar Satu', '22', 'DESEMBER', '2004', 'XI OTKP 2'),
(435, 20602, 'SITI SNOVIA SALSABILA MOKOAGOW', 'TORAUT', '11', 'DESEMBER', '2005', 'XI OTKP 2'),
(436, 20605, 'SRIANI LAPOLO', 'KOTAMOBAGU', '15', 'AGUSTUS', '2005', 'XI OTKP 2'),
(437, 20608, 'TERESA TIWA', 'GOGAGOMAN', '12', 'MARET', '2004', 'XI OTKP 2'),
(438, 20611, 'WULANDARI TULONG', 'POYOWA KECIL', '6', 'MARET', '2005', 'XI OTKP 2'),
(439, 20614, 'Yusmadi Goan Damopolii', 'Kopandakan 1', '7', 'JULI', '2004', 'XI OTKP 2'),
(440, 20617, 'Zilfa Adelia Lokiman', 'POYOWA KECIL', '16', 'NOVEMBER', '2005', 'XI OTKP 2'),
(441, 20526, 'Ajifa Arini Singosari', 'Motoboi Besar', '5', 'JANUARI', '2005', 'XI OTKP 3'),
(442, 20529, 'ALIFKA ADELIA SIMBALA', 'AMBANG I', '9', 'AGUSTUS', '2005', 'XI OTKP 3'),
(443, 20532, 'ANNISA OKTAVIA NINGSI BATANDIGO', 'POYOWA KECIL', '11', 'OKTOBER', '2005', 'XI OTKP 3'),
(444, 20535, 'ASTIANA MAULINA MAMONTO', 'KOTOBANGON', '17', 'APRIL', '2005', 'XI OTKP 3'),
(445, 20538, 'Cahya Djilita Potabuga', 'MOTOBOI BESAR', '11', 'MEI', '2005', 'XI OTKP 3'),
(446, 20541, 'Denada Putri Podomi', 'DEAGA', '26', 'FEBRUARI', '2005', 'XI OTKP 3'),
(447, 20550, 'FARADIASASTI DAUMPUNG', 'POYOWA BESAR', '24', 'JULI', '2004', 'XI OTKP 3'),
(448, 20553, 'Fegi Fatima Matropin', 'Pobundayan', '15', 'JULI', '2005', 'XI OTKP 3'),
(449, 20556, 'FIRMANSYAH AMBA', 'Kotamobagu', '26', 'OKTOBER', '2004', 'XI OTKP 3'),
(450, 20559, 'Hanjien Marsela Mamonto', 'MOYAG', '31', 'MARET', '2006', 'XI OTKP 3'),
(451, 20562, 'Jeydi Jiqrula Ampel', 'KOTAMOBAGU', '16', 'SEPTEMBER', '2005', 'XI OTKP 3'),
(452, 20565, 'LEONARDO GERALDI PATAYANG', 'MARIRI 2', '22', 'APRIL', '2005', 'XI OTKP 3'),
(453, 20576, 'Nabila Paputungan', 'Motoboi Kecil', '18', 'NOVEMBER', '2006', 'XI OTKP 3'),
(454, 20582, 'Nesa Nabila Mokoginta', 'Kotamobagu', '27', 'NOVEMBER', '2005', 'XI OTKP 3'),
(455, 20585, 'NURHAFSAH SARI KOBANDAHA', 'MOPAIT', '12', 'DESEMBER', '2005', 'XI OTKP 3'),
(456, 20588, 'PRETI SHINTA MAHMUD', 'KOTAMOBAGU', '23', 'MARET', '2005', 'XI OTKP 3'),
(457, 20591, 'RAYAN DOIDI', 'KOPANDAKAN', '22', 'FEBRUARI', '2004', 'XI OTKP 3'),
(458, 20594, 'RENISA TONGKAD', 'Mopait', '5', 'JULI', '2004', 'XI OTKP 3'),
(459, 20597, 'RIFLAN MOLANTONG', 'Poyowa besar Dua', '5', 'APRIL', '2005', 'XI OTKP 3'),
(460, 20600, 'Siti Fauzia Hamenda', 'KOTAMOBAGU', '9', 'MARET', '2005', 'XI OTKP 3'),
(461, 20603, 'Sity Alia Nabila Mokoagow', 'Sinindian', '18', 'NOVEMBER', '2004', 'XI OTKP 3'),
(462, 20606, 'SRY SUSANTI DAMOPOLII', 'MOTOBOI KECIL', '14', 'JUNI', '2005', 'XI OTKP 3'),
(463, 20609, 'Viola Paputungan', 'Pobundayan', '20', 'DESEMBER', '2003', 'XI OTKP 3'),
(464, 20612, 'Yeni Rahmawati Paputungan', 'POYOWA KECIL', '16', 'MARET', '2006', 'XI OTKP 3'),
(465, 20615, 'ZAHRA KENZA AGISYA', 'KOTAMOBAGU', '5', 'SEPTEMBER', '2006', 'XI OTKP 3'),
(466, 19954, 'SAPRINTO TAMPOY', 'POYOWA KECIL', '4', 'AGUSTUS', '2004', 'XI OTKP 3'),
(467, 20455, 'Abd. Jafar Tatoya', 'Poyowa Besar', '16', 'JANUARI', '2004', 'XI PKM 1'),
(468, 20457, 'Airin R Mamonto', 'BONGKUDAI', '6', 'MARET', '2006', 'XI PKM 1'),
(469, 20459, 'ALFINA DAMAYANTI IGIRISA', 'GOGAGOMAN', '8', 'DESEMBER', '2004', 'XI PKM 1'),
(470, 20461, 'BIMA CHANDRAWINATA MOKOBOMBANG', 'Kotamobagu', '3', 'JULI', '2005', 'XI PKM 1'),
(471, 20463, 'Claudia Sintya Bella Modeong', 'Abak', '11', 'AGUSTUS', '2005', 'XI PKM 1'),
(472, 20465, 'DIKI WAHYUDI DAENG MATAJANG', 'Molinow', '2', 'APRIL', '2005', 'XI PKM 1'),
(473, 20467, 'DINDA ADELIA DUGIAN', 'Kotamobagu', '17', 'JUNI', '2005', 'XI PKM 1'),
(474, 20469, 'DIVA H. GANI', 'Gogagoman', '30', 'DESEMBER', '2006', 'XI PKM 1'),
(475, 20471, 'Elsa Alfira Agansi', 'Kotamobagu', '29', 'JANUARI', '2005', 'XI PKM 1'),
(476, 20473, 'FAJAR GIVO ADITYA MOKODOMPIT', 'Poyowa Besar 1', '8', 'OKTOBER', '2003', 'XI PKM 1'),
(477, 20475, 'FIDIA FITRAINI MOKODONGAN', 'Kotamobagu', '29', 'MEI', '2005', 'XI PKM 1'),
(478, 20477, 'KARINA MARATING', 'MOGOLAING', '5', 'OKTOBER', '2004', 'XI PKM 1'),
(479, 20479, 'Lira Makalalag', 'IDUMUN', '1', 'SEPTEMBER', '2004', 'XI PKM 1'),
(480, 20481, 'MARYAM KANI', 'GORONTALO', '15', 'JANUARI', '2005', 'XI PKM 1'),
(481, 20483, 'MAYA RONDONUWU', 'KOTAMOBAGU', '31', 'MEI', '2006', 'XI PKM 1'),
(482, 20487, 'Muhammad Farhan Firmansyah', 'TIMIKA', '10', 'MARET', '2005', 'XI PKM 1'),
(483, 20489, 'Nabila mamonto', 'Kobo Besar', '30', 'OKTOBER', '2005', 'XI PKM 1'),
(484, 20491, 'NADIA PERMATA PUTRI POTABUGA', 'KOTAMOBAGU', '11', 'JULI', '2005', 'XI PKM 1'),
(485, 20493, 'NAILA AULIA PUTRI RAMBING', 'KOTAMOBAGU', '10', 'SEPTEMBER', '2005', 'XI PKM 1'),
(486, 20495, 'Nanda Paputungan', 'POYOWA BESAR 2', '5', 'MEI', '2005', 'XI PKM 1'),
(487, 20497, 'NUR AFIFAH PAPUTUNGAN', 'MONGONDOW', '18', 'MEI', '2005', 'XI PKM 1'),
(488, 20499, 'REGINA FEBIOLA KUMENDONG', 'TOLI-TOLI', '20', 'FEBRUARI', '2005', 'XI PKM 1'),
(489, 20501, 'REVA NAZWA PAPUTUNGAN', 'MOPAIT', '13', 'MARET', '2006', 'XI PKM 1'),
(490, 20503, 'REVALINA TRAWIH', 'GENGGULANG', '14', 'OKTOBER', '2004', 'XI PKM 1'),
(491, 20505, 'RISKA DUGIAN', 'Poyowa Kecil', '31', 'JULI', '2005', 'XI PKM 1'),
(492, 20507, 'RIZA RIANDA MOKOGINTA', 'ABAK', '9', 'JULI', '2005', 'XI PKM 1'),
(493, 20509, 'SESILIA YASIN', 'DUMINANGA', '17', 'MEI', '2005', 'XI PKM 1'),
(494, 20513, 'SITI FADILLA IKLIMA HASAN', 'MOGOLAING', '30', 'JANUARI', '2007', 'XI PKM 1'),
(495, 20515, 'Sri Devi Mokoginta', 'MOPAIT', '12', 'DESEMBER', '2002', 'XI PKM 1'),
(496, 20517, 'SUCI LESTARI POTABUGA', 'WANGGA', '12', 'MARET', '2006', 'XI PKM 1'),
(497, 20519, 'SUSANTI SUGEHA', 'KOTAMOBAGU', '4', 'JUNI', '2005', 'XI PKM 1'),
(498, 20521, 'Tia Rauda Turzana Mongilong', 'MOGOLAING', '9', 'FEBRUARI', '2006', 'XI PKM 1'),
(499, 20523, 'Villa Delia Mokoginta', 'KOPANDAKAN 1', '1', 'FEBRUARI', '2005', 'XI PKM 1'),
(500, 20456, 'ADINDA DJAFAR', 'Gogagoman', '12', 'OKTOBER', '2004', 'XI PKM 2'),
(501, 20458, 'ALFIKAR MOKOGINTA', 'MONGKONAI', '5', 'APRIL', '2005', 'XI PKM 2'),
(502, 20460, 'Apriyandi Tungkagi', 'KOPANDAKAN 1', '27', 'FEBRUARI', '2004', 'XI PKM 2'),
(503, 20462, 'Bunga Berliana', 'SININDIAN', '28', 'MARET', '2005', 'XI PKM 2'),
(504, 20464, 'DELON DANUARTA KANDOLI', 'MOTOBOI KECIL', '24', 'DESEMBER', '2004', 'XI PKM 2'),
(505, 20468, 'Dinda Paputungan', 'KOTAMOBAGU', '12', 'SEPTEMBER', '2004', 'XI PKM 2'),
(506, 20470, 'ELNIS EGO', 'POYOWA BESAR 2', '19', 'JULI', '2005', 'XI PKM 2'),
(507, 20472, 'Fadillah sopan potabuga', 'MONGKONAI', '16', 'SEPTEMBER', '2005', 'XI PKM 2'),
(508, 20474, 'Fardhan M. Mongilong', 'TORUAKAT', '26', 'DESEMBER', '2004', 'XI PKM 2'),
(509, 20476, 'FIKA SARI PAPUTUNGAN', 'DUMARA', '24', 'MARET', '2006', 'XI PKM 2'),
(510, 20478, 'KEZIA VRILY MUAT', 'Poyowa Kecil', '19', 'JULI', '2005', 'XI PKM 2'),
(511, 20480, 'LIRA NAZWA BANGKI', 'KOPANDAKAN', '21', 'APRIL', '2005', 'XI PKM 2'),
(512, 20482, 'Mawar Simbala', 'Mopusi', '9', 'MARET', '2006', 'XI PKM 2'),
(513, 20484, 'Meylana Domu', 'Kotamobagu', '16', 'MEI', '2005', 'XI PKM 2'),
(514, 20486, 'MOH. REALDI SAPUTRA YUNUS', 'GOGAGOMAN', '20', 'AGUSTUS', '2004', 'XI PKM 2'),
(515, 20488, 'NABILA ANDUP', 'Mopusi', '7', 'JULI', '2005', 'XI PKM 2'),
(516, 20490, 'NABILA RAODAH PUTRI MAHULETTE', 'Kotamobagu', '16', 'SEPTEMBER', '2005', 'XI PKM 2'),
(517, 20492, 'NADIA SARI LAKISA', 'Kotamobagu', '3', 'MEI', '2005', 'XI PKM 2'),
(518, 20496, 'Novita Nur Hippy', 'KOTAMOBAGU', '19', 'FEBRUARI', '2006', 'XI PKM 2'),
(519, 20498, 'Raisyah Ramanda Mokodompit', 'Gogagoman', '1', 'OKTOBER', '2005', 'XI PKM 2'),
(520, 20500, 'Reino S Mokodongan', 'TORUAKAT', '14', 'MEI', '2005', 'XI PKM 2'),
(521, 20502, 'Revalina Tanda', 'KOPANDAKAN', '12', 'MARET', '2004', 'XI PKM 2'),
(522, 20504, 'Rianti Julita Mokodompit', 'DAYOU', '24', 'AGUSTUS', '2005', 'XI PKM 2'),
(523, 20506, 'RIVAL PESIK', 'Kotobangon', '16', 'MEI', '2005', 'XI PKM 2'),
(524, 20508, 'Salsa Adelfia Manggo', 'Tanoyan Utara', '13', 'APRIL', '2005', 'XI PKM 2'),
(525, 20510, 'SHE PUTRI CHELONITA DJEMAN', 'POYOWA KECIL', '21', 'NOVEMBER', '2004', 'XI PKM 2'),
(526, 20512, 'Siti Anisa Mokodompit', 'Bulud', '30', 'SEPTEMBER', '2005', 'XI PKM 2'),
(527, 20514, 'SITTI FADIAH LAMAMA', 'KOTAMOBAGU', '26', 'APRIL', '2005', 'XI PKM 2'),
(528, 20516, 'Sri Fidya Makalalag', 'TAPA AOG', '2', 'JULI', '2006', 'XI PKM 2'),
(529, 20518, 'Suryanto Saputro', 'MOGOLAING', '17', 'FEBRUARI', '2005', 'XI PKM 2'),
(530, 20520, 'Switli Angraini Eddi Luli', 'POYOWA KECIL', '1', 'AGUSTUS', '2005', 'XI PKM 2'),
(531, 20522, 'Ummu Jihada Anggol', 'TORUAKAT', '8', 'JUNI', '2004', 'XI PKM 2'),
(532, 20761, 'Ahmad Afreji Damopolii', 'Gogagoman', '3', 'APRIL', '2005', 'RPL'),
(533, 20762, 'ARFA ANUGRAH MOKODONGAN', 'MONGKONAI', '11', 'AGUSTUS', '2005', 'RPL'),
(534, 20763, 'Arif Zulkifli Rachman', 'MOGOLAING', '1', 'JANUARI', '2006', 'RPL'),
(535, 20764, 'ASLAM ALFATI MAKALALAG', 'MATALI', '23', 'AGUSTUS', '2005', 'RPL'),
(536, 20765, 'ASWAR BIAHIMO', 'KOTAMOBAGU', '8', 'SEPTEMBER', '2005', 'RPL'),
(537, 20766, 'CARLI MAMONTO', 'KOTAMOBAGU', '15', 'JUNI', '2005', 'RPL'),
(538, 20767, 'Cinda Ade Liyanti Lenda', 'Bolmong', '15', 'MEI', '2005', 'RPL'),
(539, 20768, 'DODO PRASETIO KANDOLI', 'POYOWA BESAR 1', '26', 'OKTOBER', '2005', 'RPL'),
(540, 20769, 'INAYAH TUMANGKEN', 'KOTAMOBAGU', '2', 'OKTOBER', '2005', 'RPL'),
(541, 20770, 'LIVARDI PERDANA DIDIMUS', 'KOTAMOBAGU', '28', 'JUNI', '2005', 'RPL'),
(542, 20771, 'MIKHAEL GEOVANI SONDAKH', 'Poyowa Kecil', '2', 'JUNI', '2005', 'RPL'),
(543, 20772, 'MOHAMAD FARID KANDOLI', 'KOTAMOBAGU', '20', 'SEPTEMBER', '2005', 'RPL'),
(544, 20773, 'Mohamad Resdiyanto Bulow', 'Motoboi Kecil', '27', 'MEI', '2005', 'RPL'),
(545, 20774, 'MOHAMMAD DHIVO MOKODOMPIT', 'MOGOLAING', '15', 'FEBRUARI', '2006', 'RPL'),
(546, 20775, 'NADA LUTFIA MOKOAGOW', 'BAKAN', '7', 'SEPTEMBER', '2005', 'RPL'),
(547, 20776, 'NAZWA ADILLA KARINDA', 'KOTAMOBAGU', '13', 'JULI', '2006', 'RPL'),
(548, 20777, 'Neyila Cahaya Putri Podomi', 'Bakan', '6', 'SEPTEMBER', '2005', 'RPL'),
(549, 20778, 'NEZA PANGAU', 'TABANG', '3', 'MARET', '2005', 'RPL'),
(550, 20779, 'Nur Indah Eka Putri Paputungan', 'POYOWA KECIL', '25', 'NOVEMBER', '2005', 'RPL'),
(551, 20780, 'OPHI PAPUTUNGAN', 'MONGKONAI', '12', 'NOVEMBER', '2004', 'RPL'),
(552, 20781, 'RESKA RAUPU', 'MOPUSI', '3', 'MARET', '2006', 'RPL'),
(553, 20782, 'ROSTINI MOKODOMPIT', 'TABANG', '31', 'JULI', '2005', 'RPL'),
(554, 20783, 'Siti Wahyunda Dolot', 'Totabuan', '30', 'OKTOBER', '2005', 'RPL'),
(555, 20784, 'Velicia Tesalonika Tumbelaka', 'KOTAMOBAGU', '2', 'NOVEMBER', '2005', 'RPL'),
(556, 20939, 'Aditya Julian Saputra Binol', 'MATALI', '20', 'MEI', '2005', 'XI TEB'),
(557, 20940, 'Ardian Syahputra Damopolii', 'POYOWA KECIL', '9', 'SEPTEMBER', '2004', 'XI TEB'),
(558, 20941, 'BAGAS PRAYUDA SIDAMPOI', 'ABAK', '10', 'MARET', '2005', 'XI TEB'),
(559, 20942, 'BENI MAKALALAG', 'MOTOBOI KECIL', '18', 'MARET', '2005', 'XI TEB'),
(560, 20943, 'DICKYI DAUD', 'GOGAGOMAN', '7', 'JUNI', '2004', 'XI TEB'),
(561, 20944, 'DIMAS ALMOUZHAR LAKAJO', 'Gogagoman', '19', 'DESEMBER', '2005', 'XI TEB'),
(562, 20946, 'FAHREZA MUTU', 'KOTAMOBAGU', '6', 'FEBRUARI', '2005', 'XI TEB'),
(563, 20947, 'Fergiawan Dotulong', 'GOGAGOMAN', '11', 'MARET', '2005', 'XI TEB'),
(564, 20948, 'HIZRIYANI GONIBALA', 'Domisil Moonow', '19', 'JANUARI', '2005', 'XI TEB'),
(565, 20949, 'MOH. DARWIS MAMING', 'MOTOBOI KECIL', '08', 'AGUSTUS', '2004', 'XI TEB'),
(566, 20950, 'MOH.ALFARIZI HUDJU', 'Palu', '20', 'SEPTEMBER', '2005', 'XI TEB'),
(567, 20951, 'MOHAMAD MARDAN PAULU', 'KOTAMOBAGU', '3', 'OKTOBER', '2005', 'XI TEB'),
(568, 20952, 'Mohammad Irfandi Makalalag', 'MATALI', '15', 'DESEMBER', '2004', 'XI TEB'),
(569, 20953, 'Mohammad Raditya Fachrezi Ololah', 'KOTAMOBAGU', '1', 'MEI', '2005', 'XI TEB'),
(570, 20954, 'NAUFAL NADIM MAILAKAY', 'GOGAGOMAN', '28', 'NOVEMBER', '2005', 'XI TEB'),
(571, 20956, 'Rismawati Ointu', 'Toruakat', '25', 'MARET', '2005', 'XI TEB'),
(572, 20957, 'SALSABILA MAMONTO', 'MOGOLAING', '19', 'DESEMBER', '2005', 'XI TEB'),
(573, 20958, 'SYALSABILA FARID MINABARI', 'Mogolaing', '23', 'JULI', '2005', 'XI TEB'),
(574, 20959, 'Wahyudi Damo', 'MOTOBOI KECIL', '28', 'NOVEMBER', '2004', 'XI TEB'),
(575, 20960, 'WAHYUDIN MIDU', 'Gogagoman', '24', 'JUNI', '2003', 'XI TEB'),
(576, 20787, 'ADITIA PUTRA PRATAMA ZAKARIA', 'MOTOBOI KECIL', '14', 'OKTOBER', '2004', 'XI TKJ 1'),
(577, 20789, 'Ahmad Nadzril Gulama', 'MOGOLAING', '11', 'APRIL', '2005', 'XI TKJ 1'),
(578, 20791, 'AMALIA AMANDA POHAN', 'MANADO', '12', 'JUNI', '2005', 'XI TKJ 1'),
(579, 20793, 'ANHAR KARNAIN MIMA', 'KOTAMOBAGU', '17', 'OKTOBER', '2004', 'XI TKJ 1'),
(580, 20794, 'Arditha Aulia Anggana Lolung', 'Tungoi 1', '27', 'NOVEMBER', '2005', 'XI TKJ 1'),
(581, 20795, 'Ariel Saputra Yusup', 'TOBONGON', '2', 'FEBRUARI', '2005', 'XI TKJ 1'),
(582, 20797, 'BOJES PASAMBUNA', 'UPAI', '31', 'AGUSTUS', '2005', 'XI TKJ 1'),
(583, 20799, 'DESWYTA MUSTAPA', 'GORONTALO', '1', 'DESEMBER', '2005', 'XI TKJ 1'),
(584, 20801, 'Dio Alief Saputra Paputungan', 'Kotamobagu', '23', 'FEBRUARI', '2005', 'XI TKJ 1'),
(585, 20803, 'FANIA AULYA MIDU', 'KOTAMOBAGU', '11', 'OKTOBER', '2005', 'XI TKJ 1'),
(586, 20805, 'GILANG RAMADAN SUMIANTO', 'MOGOLAING', '30', 'MEI', '2005', 'XI TKJ 1'),
(587, 20806, 'GILANG RAMADHAN BONUOT', 'BIGA', '22', 'OKTOBER', '2005', 'XI TKJ 1'),
(588, 20808, 'Jihan Dani Bahansubu', 'Kobo Besar', '7', 'JANUARI', '2005', 'XI TKJ 1'),
(589, 20810, 'Lasya Aulia Mamonto', 'Kotamobagu', '30', 'APRIL', '2005', 'XI TKJ 1');
INSERT INTO `datasiswa` (`no`, `nis`, `namasiswa`, `tempat_lahir`, `tanggal`, `bulan_lahir`, `tahun`, `kelas`) VALUES
(590, 20812, 'MARLINA POBELA', 'Pontodon', '20', 'NOVEMBER', '2005', 'XI TKJ 1'),
(591, 20814, 'MEILAN BONENEHU', 'AMBANG', '29', 'MEI', '2005', 'XI TKJ 1'),
(592, 20816, 'Moh. Abdul Asraf Makalalag', 'MATALI', '6', 'MEI', '2005', 'XI TKJ 1'),
(593, 20818, 'Moh. Setiawan Jodi Mokoagow', 'POBUNDAYAN', '23', 'DESEMBER', '2003', 'XI TKJ 1'),
(594, 20820, 'Mohamad Ilham makalalag', 'Matali', '23', 'MARET', '2006', 'XI TKJ 1'),
(595, 20822, 'MOHAMAD WAHYU KOROMPOT', 'GOGAGOMAN', '3', 'JUNI', '2005', 'XI TKJ 1'),
(596, 20824, 'MOHAMMAD FIRLI RADITIA MOKODOMPIT', 'Kotobangon', '6', 'SEPTEMBER', '2005', 'XI TKJ 1'),
(597, 20826, 'Muhamad Al Fakri Yambat', 'ABAK', '9', 'NOVEMBER', '2005', 'XI TKJ 1'),
(598, 20828, 'MUHAMMAD SYUKRON KOROMPOT', 'KOTAMOBAGU', '22', 'OKTOBER', '2005', 'XI TKJ 1'),
(599, 20830, 'NAZA ADHIPUTRA BANGKI', 'BIGA', '27', 'FEBRUARI', '2005', 'XI TKJ 1'),
(600, 20832, 'Orlanda Pratama Laloman', 'BUNGKO', '5', 'APRIL', '2003', 'XI TKJ 1'),
(601, 20834, 'rafli muhammad', 'MOGOLAING', '26', 'SEPTEMBER', '2005', 'XI TKJ 1'),
(602, 20836, 'Rehan paputungan', 'MOTOBOI KECIL', '10', 'APRIL', '2005', 'XI TKJ 1'),
(603, 20838, 'REVA AULIA MOKODOMPIT', 'Bakan', '7', 'FEBRUARI', '2005', 'XI TKJ 1'),
(604, 20840, 'RIDONAL TONGKAD', 'TAPA AOG', '30', 'DESEMBER', '2004', 'XI TKJ 1'),
(605, 20842, 'STELA INDRIANI PAPUTUNGAN', 'Motoboi Kecil', '3', 'JUNI', '2005', 'XI TKJ 1'),
(606, 20844, 'Yuda Lambekan', 'KONAROM', '1', 'JANUARI', '2004', 'XI TKJ 1'),
(607, 20785, 'Aco Labedu', 'KOPANDAKAN 1', '29', 'JULI', '2004', 'XI TKJ 2'),
(608, 20786, 'ADHITIA FREEZY KOROMPOT', 'MONGKONAI', '15', 'JULI', '2005', 'XI TKJ 2'),
(609, 20788, 'AGIL SAHRIAL DATALAMON', 'POBUNDAYAN', '21', 'OKTOBER', '2003', 'XI TKJ 2'),
(610, 20790, 'AHMAD VIKRAM MOKODOMPIT', 'KOTAMOBAGU', '2', 'MEI', '2006', 'XI TKJ 2'),
(611, 20792, 'Angella Ginoga', 'BANGO MOLUNOW', '23', 'MEI', '2004', 'XI TKJ 2'),
(612, 20796, 'Ayu Dinda Lakana', 'IMANDI', '14', 'FEBRUARI', '2005', 'XI TKJ 2'),
(613, 20798, 'Bonit Pramudi Lababu', 'Matali', '31', 'MEI', '2005', 'XI TKJ 2'),
(614, 20800, 'Diaz Saputra Daun', 'Kopandakan', '8', 'FEBRUARI', '2005', 'XI TKJ 2'),
(615, 20802, 'dwiki Setiawan Laode', 'KOTAMOBAGU', '24', 'DESEMBER', '2005', 'XI TKJ 2'),
(616, 20804, 'Farhan Muhamat', 'BINTAU', '21', 'JANUARI', '2006', 'XI TKJ 2'),
(617, 20807, 'HARTI PAPUTUNGAN', 'MOTANDOI', '19', 'JANUARI', '2005', 'XI TKJ 2'),
(618, 20809, 'KHURAYRA PANGAU', 'INOBONTO', '27', 'JULI', '2005', 'XI TKJ 2'),
(619, 20811, 'LAUDIA ASHARA MANGGO', 'Tanoyan Utara', '25', 'DESEMBER', '2005', 'XI TKJ 2'),
(620, 20813, 'MAYADA POTABUGA', 'Mongkonai', '30', 'SEPTEMBER', '2005', 'XI TKJ 2'),
(621, 20817, 'Moh. Dimas Aditya mamonto', 'BOLANGITANG', '28', 'JANUARI', '2006', 'XI TKJ 2'),
(622, 20819, 'Moh. Sultan Makalalag', 'NUANGAN', '18', 'OKTOBER', '2005', 'XI TKJ 2'),
(623, 20821, 'Mohamad Irfan Simbala', 'Kotamobagu', '3', 'JANUARI', '2006', 'XI TKJ 2'),
(624, 20823, 'Mohammad Alqifhari Ano', 'LOLAN', '24', 'JULI', '2005', 'XI TKJ 2'),
(625, 20825, 'MUH. FIRMANSYAH LOMBU', 'KOTAMOBAGU', '08', 'JUNI', '2005', 'XI TKJ 2'),
(626, 20827, 'Muhammad Fajri Buntuan', 'MOTOBOI KECIL', '4', 'JUNI', '2005', 'XI TKJ 2'),
(627, 20829, 'Nabila ulod', 'Lobong', '12', 'OKTOBER', '2005', 'XI TKJ 2'),
(628, 20831, 'Nazwa Ibrahim', 'IBOLIAN', '31', 'MARET', '2005', 'XI TKJ 2'),
(629, 20833, 'PUTRI MAKALALAG', 'KOTAMOBAGU', '24', 'OKTOBER', '2006', 'XI TKJ 2'),
(630, 20835, 'RAHMAN FAUZAN SURATINOJO', 'Kotamobagu', '18', 'NOVEMBER', '2005', 'XI TKJ 2'),
(631, 20837, 'Resia Makalalag', 'POBUNDAYAN', '17', 'NOVEMBER', '2004', 'XI TKJ 2'),
(632, 20839, 'Ridho Aulia Nugraha', 'BITUNG', '29', 'MARET', '2004', 'XI TKJ 2'),
(633, 20841, 'SRI MELI MOKODOMPIT', 'PONTODON', '12', 'JANUARI', '2006', 'XI TKJ 2'),
(634, 20843, 'TRIA ANANDA PAPUTUNGAN', 'AMBANG I', '3', 'SEPTEMBER', '2004', 'XI TKJ 2'),
(635, 20002, 'ABDUL AMAL PAPUTUNGAN', 'POBUNDAYAN', '25', 'JULI', '2004', 'XI TKJ 1');

-- --------------------------------------------------------

--
-- Struktur dari tabel `jurusan`
--

CREATE TABLE `jurusan` (
  `no` int(11) NOT NULL,
  `namajurusan` varchar(128) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `jurusan`
--

INSERT INTO `jurusan` (`no`, `namajurusan`) VALUES
(1, 'Akuntansi dan Keuangan Lembaga'),
(2, 'Perbankan dan Keuangan Mikro'),
(3, 'Otomatisasi dan Tata Kelola Perkantoran'),
(4, 'Asisten Keperawatan'),
(5, 'Multimedia'),
(6, 'Rekayasa Perangkat Lunak'),
(7, 'Teknik Komputer dan Jaringan'),
(8, 'Teknik Energi Biomassa');

-- --------------------------------------------------------

--
-- Struktur dari tabel `kuota`
--

CREATE TABLE `kuota` (
  `no` int(11) NOT NULL,
  `kodejurusan` int(128) NOT NULL,
  `kodedudika` int(128) NOT NULL,
  `kuota` int(128) NOT NULL,
  `sisa_kuota` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Struktur dari tabel `pembimbing`
--

CREATE TABLE `pembimbing` (
  `id_pembimbing` int(11) NOT NULL,
  `namapembimbing` varchar(128) NOT NULL,
  `kodejurusan` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Struktur dari tabel `penempatan`
--

CREATE TABLE `penempatan` (
  `no` int(11) NOT NULL,
  `id_siswa` int(11) NOT NULL,
  `id_jurusan` int(11) NOT NULL,
  `id_dudika` int(11) NOT NULL,
  `id_pembimbing` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Struktur dari tabel `user`
--

CREATE TABLE `user` (
  `login` int(11) NOT NULL,
  `namauser` varchar(128) NOT NULL,
  `pass` varchar(128) NOT NULL,
  `akses` int(11) NOT NULL,
  `waktu` varchar(128) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `user`
--

INSERT INTO `user` (`login`, `namauser`, `pass`, `akses`, `waktu`) VALUES
(12345, 'SAPI KUDA', '12345', 1, '');

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `datadudika`
--
ALTER TABLE `datadudika`
  ADD PRIMARY KEY (`no`);

--
-- Indeks untuk tabel `datasiswa`
--
ALTER TABLE `datasiswa`
  ADD PRIMARY KEY (`no`);

--
-- Indeks untuk tabel `jurusan`
--
ALTER TABLE `jurusan`
  ADD PRIMARY KEY (`no`);

--
-- Indeks untuk tabel `kuota`
--
ALTER TABLE `kuota`
  ADD PRIMARY KEY (`no`),
  ADD KEY `kodejurusan` (`kodejurusan`),
  ADD KEY `kodedudika` (`kodedudika`);

--
-- Indeks untuk tabel `pembimbing`
--
ALTER TABLE `pembimbing`
  ADD PRIMARY KEY (`id_pembimbing`);

--
-- Indeks untuk tabel `penempatan`
--
ALTER TABLE `penempatan`
  ADD PRIMARY KEY (`no`);

--
-- Indeks untuk tabel `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`login`);

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `datadudika`
--
ALTER TABLE `datadudika`
  MODIFY `no` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=74;

--
-- AUTO_INCREMENT untuk tabel `datasiswa`
--
ALTER TABLE `datasiswa`
  MODIFY `no` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=636;

--
-- AUTO_INCREMENT untuk tabel `jurusan`
--
ALTER TABLE `jurusan`
  MODIFY `no` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT untuk tabel `kuota`
--
ALTER TABLE `kuota`
  MODIFY `no` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=168;

--
-- AUTO_INCREMENT untuk tabel `pembimbing`
--
ALTER TABLE `pembimbing`
  MODIFY `id_pembimbing` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=40;

--
-- AUTO_INCREMENT untuk tabel `penempatan`
--
ALTER TABLE `penempatan`
  MODIFY `no` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
